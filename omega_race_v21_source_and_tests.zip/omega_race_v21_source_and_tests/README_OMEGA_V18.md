# Omega Race Version 18

Version 18 branches from confirmed Version 17B.

- Repairs the title-screen colon with a dedicated verified `$8A` glyph.
- Select cycles starting lives through THREE, FIVE, and SEVEN only.
- Adds a second independent gameplay pulse-SFX voice.
- New effects select a free pulse channel first and alternate when both are
  available.
- When both voices are occupied, the priority system can replace only the
  lower-priority effect while preserving the other voice.
- Existing shield and stop-super cues reserve Pulse 2 while active.
- Player One death and the two-voice level-clear song retain exclusive audio
  ownership.
- Triangle music, noise effects, thrust, and gameplay mechanics are unchanged.

Build and test from `prototype`:

```sh
python3 build_omega_base_v18.py
python3 test_omega_v18.py
```
