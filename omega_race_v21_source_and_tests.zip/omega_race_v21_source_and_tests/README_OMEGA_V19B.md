# Omega Race NES — Version 19B

This update fixes a fresh game started from the title after returning there from Game Over. Previously, that path reused the land mines from the finished game. Every new game now clears all 16 mine records, whether started from the title or through Game Over → Start.

Ordinary level changes still preserve existing mines except those close to Player One's new spawn point. The Version 19A title placement, logo palette, victory music release, and Game Over rules are unchanged.

ROM: `prototype/omega_race_v19b.nes`. From `prototype/`, run `python build_omega_base_v19b.py` to build and `python test_omega_v19b.py` to check the three mine-transition paths. Python requires `py65` and Pillow for the complete build.
