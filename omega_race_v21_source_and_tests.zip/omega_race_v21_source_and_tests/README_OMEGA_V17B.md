# Omega Race Version 17B

Version 17B corrects the two title-screen defects visible in the Version 17A
playtest screenshot.

- Forces all NES universal and mirrored startup palette entries to true black
  (`$0F`), preventing sprite-palette initialization from restoring `$08`.
- Removes the inherited Asteroids title-sprite renderer, leaving all 64 sprite
  entries hidden while the title screen is displayed.
- Preserves the logo, title text, lives selector, Start transition, and normal
  gameplay palettes.

Build and test from `prototype`:

```sh
python3 build_omega_base_v17b.py
python3 test_omega_v17b.py
```
