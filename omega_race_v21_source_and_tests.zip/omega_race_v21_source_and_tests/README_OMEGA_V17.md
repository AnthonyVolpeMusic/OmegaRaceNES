# Omega Race Version 17

Version 17 adds the first native Omega Race title screen while preserving the
confirmed Version 16 gameplay and audio behavior.

- The supplied 192x48 Omega Race logo is centered in the upper third as a
  24x6 background-tile graphic.
- `PRESS SELECT TO CHOOSE` and `STARTING LIVES: THREE` are centered beneath it.
- `PRESS START TO BEGIN` is centered four blank tile rows below the lives line.
- Select cycles starting lives through ONE, TWO, THREE, FOUR, and FIVE.
- Start creates a fresh Level 1 using the selected lives value and three supers.
- Title mode freezes gameplay simulation and contains no sprite actors.

Build and test from `prototype`:

```sh
python3 build_omega_base_v17.py
python3 test_omega_v17.py
```

Dependencies: Python 3, Pillow, and py65. The source package includes the
uploaded logo and all inherited source assets required by the build chain.
