# Omega Race Player Base V1

This is a separate branch from the confirmed Asteroids V36 final candidate.
It boots directly into an empty black Bouncy arena.

Active gameplay systems:

- Player One ship, centered and facing up
- V36 rotation, thrust, inertia and maximum velocity
- Down: instant 180-degree flip
- A: fire, four projectile slots, inherited lifetime and shot-speed upgrade hook
- B: one-second shield
- B+Up or B+Down: instantaneous brake
- Ship and shots reflect from all four V36 Bouncy boundaries
- Existing ship, shot, shield, thrust, flip/brake audio behavior

The title, HUD, starfield, asteroids, Murderoids, UFOs, pickups, scoring, waves,
player collisions, deaths, results screen, object-counter display and adaptive
dispatcher are not executed. The inherited project source remains available so
future Omega Race systems can be added incrementally.

Build: `python3 prototype/build_omega_base_v1.py`

Verify: `python3 prototype/test_omega_base_v1.py`
