"""Omega Race V20A: keep the third attract page selected during its flash."""

# A palette address selects nametable 3 in the PPU scroll latch. Restore
# nametable 0 before rendering the story and logo again.
code = '\n'.join(lines)
old = '''LDA $06BC
STA $2007
omega_attract_flush_done20:
RTS'''
new = '''LDA $06BC
STA $2007
BIT $2002
LDA #$20
STA $2006
LDA #$00
STA $2006
omega_attract_flush_done20:
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)
lines = [line.strip() for line in code.splitlines() if line.strip()]

assert 'SUCCESSFUL. IT' in third
third = third.replace('SUCCESSFUL. IT', 'SUCCESSFUL, IT')
third_lines = textwrap.wrap(third, 28)
assert len(third_lines) == 5
data['omega_attract_story_three_text20'] = script(third_lines)
