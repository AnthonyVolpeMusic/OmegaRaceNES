# Omega Race NES – Version 5 center-HUD test build

- Preserves Version 4B as the completed Version 4 gameplay baseline.
- Centers `SCORE:000000`, `SUPERS:5`, and `LIVES LEFT:3` inside the 14x10
  middle box.
- Updates all six score digits, supers, and remaining lives dynamically during
  vertical blank.
- Keeps labels and borders static, limiting each frame to eight tile writes.
- All Version 4B arena geometry, handling, projectile behavior, controls,
  graphics, palettes, and sounds remain unchanged.
