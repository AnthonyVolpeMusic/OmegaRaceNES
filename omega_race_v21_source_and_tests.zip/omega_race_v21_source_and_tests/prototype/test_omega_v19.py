"""Execute Version 19 screens and ranking on the assembled 6502 ROM."""
from pathlib import Path
import json

P = Path(__file__).parent
source = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
source = source.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v19.nes')
source = source.replace('symbols_omega_base_v1.json', 'symbols_omega_v19.json')
source = source.replace('range(400000)', 'range(900000)')
env = {'__file__': str(P / 'test_omega_v19.py')}
exec(compile(source, 'v19 machine harness', 'exec'), env)
BaseMemory, boot, call = env['Memory'], env['boot'], env['call']

class TrackedMemory(BaseMemory):
    def __init__(self):
        super().__init__()
        self.name = {}
        self.ppu_addr = 0
        self.ppu_first = True
    def __getitem__(self, addr):
        if addr == 0x2002:
            self.ppu_first = True
        return super().__getitem__(addr)
    def __setitem__(self, addr, value):
        if addr == 0x2006:
            if self.ppu_first:
                self.ppu_addr = (value & 0x3F) << 8
            else:
                self.ppu_addr = (self.ppu_addr & 0x3F00) | value
            self.ppu_first = not self.ppu_first
        if addr == 0x2007:
            self.name[self.ppu_addr] = value
            self.ppu_addr = (self.ppu_addr + 1) & 0x3FFF
        super().__setitem__(addr, value)

env['Memory'] = TrackedMemory
symbols = json.loads((P / 'symbols_omega_v19.json').read_text())
rom = (P / 'omega_race_v19.nes').read_bytes()
prg = rom[16:32784]

def glyph(ch):
    if ch == ' ': return 0
    if ch == ':': return 0x8A
    if ch.isdigit(): return 0x7B + int(ch)
    return 0x61 + ord(ch) - ord('A')

def assert_line(mm, row, string):
    col = (32 - len(string)) // 2
    actual = [mm.name.get(0x2000 + row * 32 + col + x) for x in range(len(string))]
    assert actual == list(map(glyph, string)), (row, string, actual)

# The actual first vblank must preserve the colon after flushing pending HUD.
m,c = boot()
assert m.name[0x21D3] == 0x8A
m[0] = 1
c.pc = 0x7fff
c.sp = 255
c.nmi()
for _ in range(25000):
    c.step()
    if c.pc == 0x7fff:
        break
else:
    raise AssertionError('NMI timeout')
assert m.name[0x21D3] == 0x8A
assert_line(m, 14, 'STARTING LIVES: THREE')
print('PASS title colon remains a colon after the first NMI HUD update')

ranks = (
    (0, 'JANITOR'), (1000, 'CONCESSIONS CLERK'),
    (2000, 'HOT DOG VENDOR'), (3000, 'PIT CREW'),
    (4000, 'PACE CAR'), (6000, 'LEAD FOOT'),
    (8000, 'TOUGH CUSTOMER'), (10000, 'ROAD WARRIOR'),
    (12500, 'INTIMIDATOR'), (15000, 'FRONT ROW JOE'),
    (20000, 'ROCKET MAN'), (25000, 'IRON MAN'),
    (30000, 'OMEGA RACER'),
)
for lives in (3, 5, 7):
    m,c = boot()
    m[0x9A] = lives
    for rank, (limit, name) in enumerate(ranks):
        for score, expected in ((limit * lives, rank),
                                (limit * lives - 1, rank - 1)) if rank else ((0, 0),):
            m[0x30:0x33] = [score & 0xff, (score >> 8) & 0xff, score >> 16]
            call(m,c,'omega_rank19')
            assert c.a == expected, (lives, score, name, c.a, expected)
    score = 76500
    call(m,c,'omega_start_game17')
    m[0x9A] = lives
    m[0x30:0x33] = [score & 255, (score >> 8) & 255, score >> 16]
    m[0x33:0x39] = [int(x) for x in '076500']
    call(m,c,'omega_gameover_enter19')
    assert m[0x677] == 3 and m[0x06] == 1
    assert_line(m, 4, 'GAME OVER')
    assert_line(m, 7, 'FINAL SCORE:')
    assert_line(m, 9, '076500')
    assert_line(m, 12, 'YOUR RANK:')
    assert_line(m, 14, next(name for threshold,name in reversed(ranks) if threshold * lives <= score))
    assert_line(m, 19, 'PRESS START TO PLAY AGAIN')
    assert_line(m, 23, 'PRESS SELECT TO GO')
    assert_line(m, 24, 'TO THE MAIN SCREEN')
    assert all(m[0x200+i*4] == 0xF8 for i in range(64))
    assert m.name[0x3F00] == 0x0F
    assert all(m.name[0x2000 + i] == 0 for i in range(32))
print('PASS all 3/5/7 rank boundaries, centered Game Over copy, final score, black screen, and hidden sprites')

m,c = boot()
call(m,c,'omega_start_game17')
m[0x3D] = 0
m[0x677] = 1
m[0x678] = 1
call(m,c,'omega_death_tick9')
assert m[0x677] == 3
print('PASS final death enters Game Over after its existing shot-and-timer continuation')

m,c = boot()
m[0x9A] = 5
call(m,c,'omega_start_game17')
call(m,c,'omega_gameover_enter19')
m[1],m[2] = 0x10,0
call(m,c,'game_controls')
assert m[6] == 1 and m[0xC0] == 1 and m[0x3D] == 5
assert m[0x677] == 4 and m[0x30:0x39] == [0]*9
assert not any(m[0x580:0x640]) and not any(m[0x700:0x800])

m,c = boot()
m[0x9A] = 7
call(m,c,'omega_start_game17')
call(m,c,'omega_gameover_enter19')
m[1],m[2] = 0x20,0
call(m,c,'game_controls')
assert m[6] == 0 and m[0x9A] == 7 and m[0x677] == 0
call(m,c,'omega_title_flush17')
assert_line(m,14,'STARTING LIVES: SEVEN')
assert m.name[0x3F00] == 0x0F
print('PASS Start starts fresh with selected lives; Select restores a clean title and selected choice')
