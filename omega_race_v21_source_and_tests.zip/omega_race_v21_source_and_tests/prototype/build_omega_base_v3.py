"""Omega Race V3: bordered playfield, central box, and solid box physics."""
from pathlib import Path

P = Path(__file__).parent
exec(compile((P / 'build_omega_base_v1.py').read_text(),
             str(P / 'build_omega_base_v1.py'), 'exec'))

marker = 'asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker) == 1
source = source.replace(
    marker,
    "exec(compile((P/'patch_omega_base_v3.py').read_text(),"
    "str(P/'patch_omega_base_v3.py'),'exec'))\n" + marker)

# Install the approved Omega Race character and border drawings at the final
# CHR stage.  This must occur after inherited V35 writes its obsolete star
# tiles into $90-$99, otherwise those one-pixel patterns overwrite the walls.
output_marker = "output=P/'omega_race_player_base_v2_palette_test.nes'"
assert source.count(output_marker) == 1
source = source.replace(
    output_marker,
    "exec(compile((P/'patch_omega_chr_v3.py').read_text(),"
    "str(P/'patch_omega_chr_v3.py'),'exec'))\n" + output_marker)
source = source.replace(output_marker,
                        "output=P/'omega_race_v3_bordered_arena_test.nes'")
source = source.replace('symbols_omega_base_v1.json', 'symbols_omega_v3.json')
source = source.replace('prototype_omega_base_v1.asm', 'prototype_omega_v3.asm')
exec(compile(source, str(P / 'build_v15.py'), 'exec'))
