"""Machine-code checks for the empty Omega Race player foundation."""
import json,os
from pathlib import Path
from py65.devices.mpu6502 import MPU
P=Path(__file__).parent
S=json.loads((P/'symbols_omega_base_v1.json').read_text())
IMAGE=(P/'omega_race_player_base_v2_palette_test.nes').read_bytes()
ROM=IMAGE[16:32784]
CHR=IMAGE[32784:]
class Memory(list):
    def __init__(self):
        super().__init__([0]*65536);self.ppu=[];self.dmas=0;self.pad=0;self.index=0
    def __getitem__(self,k):
        if k==0x2002:return 0x80
        if k==0x4016:
            v=(self.pad>>(7-self.index))&1 if self.index<8 else 1;self.index+=1;return v
        return super().__getitem__(k)
    def __setitem__(self,k,v):
        if k==0x4016:self.index=0
        if k==0x2007:self.ppu.append(v)
        if k==0x4014:self.dmas+=1
        super().__setitem__(k,v)
def boot():
    m=Memory();m[0x8000:]=ROM;c=MPU(memory=m,pc=S['reset'])
    for _ in range(400000):
        c.step()
        if c.pc==S['main']:return m,c
    raise AssertionError('boot timeout')
def call(m,c,name):
    c.pc=S[name];c.sp=255;c.stPushWord(0x7ffe)
    for _ in range(200000):
        c.step()
        if c.pc==0x7fff:return
    raise AssertionError(name+' timeout')
m,c=boot()
assert m[6]==1 and m[0x8e]==1 and m[0x11]==128 and m[0x13]==120
assert not any(m[0x300:0x800])
assert m[7]==5 and m[0x3d]==3
print('PASS direct boot: centered ship, Bouncy mode, all gameplay pools empty')

# Omega Race colour pass: Player One uses $38/$18, shots use $28-centre and
# $38-outer, and palette 3 is reserved as the default enemy/tile gold set.
assert m.ppu[-32:] == [
    0x08,0x18,0x28,0x38, 0x0f,0x16,0x28,0x08,
    0x0f,0x0f,0x0f,0x0f, 0x0f,0x0f,0x0f,0x0f,
    0x08,0x38,0x18,0x28, 0x0f,0x37,0x27,0x17,
    0x08,0x28,0x38,0x18, 0x08,0x18,0x28,0x38]
def chr_pixel(tile,x,y):
    base=(0x100+tile)*16
    return ((CHR[base+y]>>(7-x))&1) | (((CHR[base+8+y]>>(7-x))&1)<<1)
assert all(chr_pixel(0x11,x,y)==1 for y in (3,4) for x in (3,4))
assert all(chr_pixel(0x11,x,y)==2 for x,y in
           ((3,2),(4,2),(2,3),(5,3),(2,4),(5,4),(3,5),(4,5)))
print('PASS Omega Race gold palettes: P1 $38/$18; shots $28-centre/$38-outer')

# Existing V36 controls: rotate, thrust, flip, fire, shield and either brake.
for pad in (0x44,0x48):
    m,c=boot();m[0x14:0x18]=[51,1,205,255];m[1]=pad;m[2]=0
    call(m,c,'game_controls')
    assert m[7]==4 and m[0x14:0x18]==[0,0,0,0]
m,c=boot();m[3]=9;m[1]=4;m[2]=0;call(m,c,'game_controls');assert m[3]==33
m,c=boot();m[1]=0x80;m[2]=0;call(m,c,'game_controls')
assert sum(m[a]!=0 for a in range(0x600,0x640,16))==1
m,c=boot();m[1]=0x40;m[2]=0;call(m,c,'game_controls');assert m[7]==4 and m[8]==60
print('PASS exact V36 flip, fire, shield, B+Up brake and B+Down brake controls')

# Ship and shots reflect from all Bouncy boundaries using their actual routines.
m,c=boot();m[0x11]=248;m[0x14]=0;m[0x15]=1;call(m,c,'physics');assert m[0x15]&0x80
m[0x11]=0;m[0x14]=0;m[0x15]=0xff;call(m,c,'physics');assert not m[0x15]&0x80
m[0x13]=222;m[0x16]=0;m[0x17]=1;call(m,c,'physics');assert m[0x17]&0x80
m[0x13]=16;m[0x16]=0;m[0x17]=0xff;call(m,c,'physics');assert not m[0x17]&0x80
for axis,pos,vel in ((2,252,1),(2,0,0xff),(4,226,1),(4,16,0xff)):
    m,c=boot();m[0x600]=48;m[0x600+axis]=pos;m[0x606 if axis==2 else 0x608]=vel
    call(m,c,'bullets')
    assert bool(m[0x606 if axis==2 else 0x608]&0x80)==(vel==1)
print('PASS ship and projectile reflection at all four walls')

# Rendering exposes only ship and the live shot. NMI never writes background.
m,c=boot();m[0x600]=48;m[0x602]=80;m[0x604]=90;call(m,c,'render')
visible=[a for a in range(0x200,0x300,4) if m[a]!=0xf8]
assert visible==[0x200,0x204],visible
assert m[0x202]==0 and m[0x206]==2
m.ppu=[];m[0]=1;m[0xa2]=0;c.pc=0x7fff;c.sp=255;c.nmi()
for _ in range(20000):
    c.step()
    if c.pc==0x7fff:break
if os.environ.get('OMEGA_DYNAMIC_HUD'):
    assert m.ppu==[0x7b]*6+[0x80,0x7e] and m.dmas==1
else:
    assert not m.ppu and m.dmas==1
print('PASS OAM contains only ship/shot; Vblank performs no tile updates')

# Run the real main/NMI handshake for two seconds with no input. No inherited
# actor, wave, pickup, score or background path may wake up on its own.
m,c=boot();m.ppu=[];c.pc=S['main'];c.sp=255
next_nmi=c.processorCycles
for refresh in range(120):
    target=next_nmi+29781
    while c.processorCycles<target:
        if c.processorCycles>=next_nmi:
            c.nmi();next_nmi+=29781
        c.step()
assert not any(m[0x300:0x600]) and not any(m[0x640:0x800])
if os.environ.get('OMEGA_DYNAMIC_HUD'):
    assert len(m.ppu)==m.dmas*8 and m.ppu==([0x7b]*6+[0x80,0x7e])*m.dmas
else:
    assert not m.ppu
assert 118<=m.dmas<=120
assert m[0x11]==128 and m[0x13]==120
print('PASS two seconds of real main/NMI execution remain an empty stable arena')
