"""Four 8x8 Shooting Star frames at sprite tiles $E8-$EB."""

# 0 transparent, 1 red body ($16), 2 yellow propeller ($27).
shooting_star_frames = [
 ['00021000','00021000','00121100','00122222','22222110','01112110','11112111','11112111'],
 ['00211000','00211000','00121122','00122200','01222110','22112110','11111211','11111211'],
 ['00011000','02011020','00211200','00122100','01122110','01211210','12111121','11111111'],
]
shooting_star_frames.append([row[::-1] for row in shooting_star_frames[1]])
for i, rows in enumerate(shooting_star_frames):
    assert len(rows) == 8 and all(len(r) == 8 for r in rows)
    tile(0x1E8 + i, [[int(c) for c in row] for row in rows])
