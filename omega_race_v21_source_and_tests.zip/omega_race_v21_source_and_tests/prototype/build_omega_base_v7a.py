"""Layer Version 7A's mirrored spawn setup onto the unchanged V5A build."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v5a.py').read_text()
needle = "exec(compile(source, str(P / 'build_v15.py'), 'exec'))"
assert recipe.count(needle) == 1
recipe = recipe.replace(needle, '''
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v6.py').read_text(),str(P/'patch_omega_base_v6.py'),'exec'))\\n" + marker)
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v7a.py').read_text(),str(P/'patch_omega_base_v7a.py'),'exec'))\\n" + marker)
out = "output=P/'omega_race_v5a_event_hud_test.nes'"
source = source.replace(out, "exec(compile((P/'patch_omega_chr_v6.py').read_text(),str(P/'patch_omega_chr_v6.py'),'exec'))\\noutput=P/'omega_race_v7a.nes'")
source = source.replace('symbols_omega_v5a.json', 'symbols_omega_v7a.json')
source = source.replace('prototype_omega_v5a.asm', 'prototype_omega_v7a.asm')
exec(compile(source, str(P / 'build_v15.py'), 'exec'))
''')
exec(compile(recipe, str(P / 'build_omega_base_v5a.py'), 'exec'))
