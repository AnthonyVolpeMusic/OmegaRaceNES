"""Version 8: Commander enemy, promotion, scoring, LOS fire, four enemy shots."""

code = '\n'.join(lines)

# Enemy bullets advance before player-bullet/enemy collision resolution.
old = 'JSR bullets\nJSR drone_collision7b\nJSR drone_tick6'
new = 'JSR bullets\nJSR enemy_shots_tick8\nJSR drone_collision7b\nJSR drone_tick6'
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Initialize type/timer fields for every record. Record zero is Level 1's
# starting Commander. Clear the independent four-shot pool.
old = '''LDA #$01
STA $0305,X
JSR drone_assign6'''
new = '''LDA #$01
STA $0305,X
LDA #$00
STA $0306,X
LDA #$78
STA $0307,X
JSR drone_assign6'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''CPX #$70
BNE drone_spawn6
RTS'''
new = '''CPX #$70
BNE drone_spawn6
LDA #$01
STA $0306
LDX #$3F
LDA #$00
drone_clear_shots8:
STA $0480,X
DEX
BPL drone_clear_shots8
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Commander movement is exactly twice the basic-drone rate, including the
# diagonal compensation (cardinal $80 vs $40, diagonal $5A vs $2D).
old = '''drone_step6:
LDA #$40
STA $AA'''
new = '''drone_step6:
LDA $0306,X
BEQ drone_speed_basic8
LDA #$80
BNE drone_speed_store8
drone_speed_basic8:
LDA #$40
drone_speed_store8:
STA $AA'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''LDA #$2D
STA $AA
drone_fraction6:'''
new = '''LDA $0306,X
BEQ drone_diag_basic8
LDA #$5A
BNE drone_diag_store8
drone_diag_basic8:
LDA #$2D
drone_diag_store8:
STA $AA
drone_fraction6:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Service each Commander's two-second fire timer once per simulation frame.
old = '''LDA $0305,X
BEQ drone_tick_next7b
JSR drone_move6'''
new = '''LDA $0305,X
BEQ drone_tick_next7b
LDA $0306,X
BEQ drone_tick_move8
DEC $0307,X
BNE drone_tick_move8
LDA #$78
STA $0307,X
JSR commander_try_fire8
drone_tick_move8:
JSR drone_move6'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Select Commander art from $E4-$E7; drones remain at $E0-$E3.
old = '''LDA $A8
CLC
ADC #$E0
STA $0201,Y'''
new = '''LDA $0306,X
BEQ drone_render_basic8
LDA #$E4
BNE drone_render_base8
drone_render_basic8:
LDA #$E0
drone_render_base8:
CLC
ADC $A8
STA $0201,Y'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Enemy projectiles use OAM $30-$3F, immediately after seven enemy sprites.
old = '''CPX #$70
BNE drone_render_loop6
RTS'''
new = '''CPX #$70
BNE drone_render_loop6
JSR enemy_shots_render8
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Replace 7B's collision routine so scoring depends on enemy type and a dead
# Commander immediately promotes a randomly selected surviving basic drone.
start = code.index('drone_collision7b:')
end = code.index('\nRTS', start) + len('\nRTS')
collision = '''drone_collision7b:
LDY #$00
drone_bullet_loop8:
LDA $0600,Y
BNE drone_bullet_active8
JMP drone_next_bullet8
drone_bullet_active8:
LDA $0609,Y
BEQ drone_bullet_flying8
JMP drone_next_bullet8
drone_bullet_flying8:
STY $B0
LDX #$00
drone_hit_loop8:
LDA $0305,X
BNE drone_hit_live8
JMP drone_hit_next8
drone_hit_live8:
LDY $B0
LDA $0602,Y
CLC
ADC #$03
CMP $0300,X
BCS drone_hit_left_ok8
JMP drone_hit_next8
drone_hit_left_ok8:
LDA $0300,X
CLC
ADC #$08
CMP $0602,Y
BCS drone_hit_right_ge8
JMP drone_hit_next8
drone_hit_right_ge8:
BNE drone_hit_x_ok8
JMP drone_hit_next8
drone_hit_x_ok8:
LDA $0604,Y
CLC
ADC #$03
CMP $0301,X
BCS drone_hit_top_ok8
JMP drone_hit_next8
drone_hit_top_ok8:
LDA $0301,X
CLC
ADC #$08
CMP $0604,Y
BCS drone_hit_bottom_ge8
JMP drone_hit_next8
drone_hit_bottom_ge8:
BNE drone_hit_y_ok8
JMP drone_hit_next8
drone_hit_y_ok8:
LDA $0306,X
STA $B1
LDA #$00
STA $0305,X
LDA $0300,X
STA $0602,Y
LDA $0301,X
STA $0604,Y
LDA #$0F
STA $0600,Y
LDA #$01
STA $0609,Y
LDA #$00
STA $0605,Y
STA $0606,Y
STA $0607,Y
STA $0608,Y
LDA $B1
BEQ drone_score_1000_8
LDX #$06
drone_score_1500_loop8:
LDA #$FA
JSR score_add
DEX
BNE drone_score_1500_loop8
JSR commander_promote8
JMP drone_score_done8
drone_score_1000_8:
LDX #$05
drone_score_1000_loop8:
LDA #$C8
JSR score_add
DEX
BNE drone_score_1000_loop8
drone_score_done8:
JSR omega_hud_request_score_v5a
LDY $B0
JMP drone_next_bullet8
drone_hit_next8:
TXA
CLC
ADC #$10
TAX
CPX #$70
BEQ drone_hit_scan_done8
JMP drone_hit_loop8
drone_hit_scan_done8:
LDY $B0
drone_next_bullet8:
TYA
CLC
ADC #$10
TAY
CPY #$40
BEQ drone_collision_done8
JMP drone_bullet_loop8
drone_collision_done8:
RTS'''
code = code[:start] + collision + code[end:]

code += r'''
commander_promote8:
LDX #$00
commander_find_any8:
LDA $0305,X
BEQ commander_find_next8
LDA $0306,X
BEQ commander_choose8
commander_find_next8:
TXA
CLC
ADC #$10
TAX
CPX #$70
BNE commander_find_any8
RTS
commander_choose8:
JSR random
commander_reduce7_8:
CMP #$07
BCC commander_index8
SEC
SBC #$07
JMP commander_reduce7_8
commander_index8:
ASL A
ASL A
ASL A
ASL A
TAX
LDA #$07
STA $B2
commander_scan8:
LDA $0305,X
BEQ commander_scan_next8
LDA $0306,X
BEQ commander_promote_here8
commander_scan_next8:
TXA
CLC
ADC #$10
CMP #$70
BCC commander_scan_store8
LDA #$00
commander_scan_store8:
TAX
DEC $B2
BNE commander_scan8
RTS
commander_promote_here8:
LDA #$01
STA $0306,X
LDA #$78
STA $0307,X
RTS

commander_try_fire8:
STX $B1
JSR commander_heading8
STA $B2
JSR commander_los8
BEQ commander_fire_done8
LDY #$00
commander_find_shot8:
LDA $0480,Y
BEQ commander_spawn_shot8
TYA
CLC
ADC #$10
TAY
CPY #$40
BNE commander_find_shot8
JMP commander_fire_done8
commander_spawn_shot8:
LDX $B1
LDA #$FF
STA $0480,Y
LDA #$00
STA $0481,Y
STA $0483,Y
STA $0489,Y
LDA $0300,X
CLC
ADC #$02
STA $0482,Y
LDA $0301,X
CLC
ADC #$02
STA $0484,Y
LDX $B2
LDA ufo_xlo,X
STA $0485,Y
LDA ufo_xhi,X
STA $0486,Y
LDA ufo_ylo,X
STA $0487,Y
LDA ufo_yhi,X
STA $0488,Y
commander_fire_done8:
LDX $B1
RTS

commander_heading8:
LDA #$00
STA $54
STA $55
LDA $11
CMP $0300,X
BCS commander_dx_positive8
INC $54
LDA $0300,X
SEC
SBC $11
JMP commander_dx_ready8
commander_dx_positive8:
SEC
SBC $0300,X
commander_dx_ready8:
STA $52
LDA $13
CMP $0301,X
BCS commander_dy_positive8
INC $55
LDA $0301,X
SEC
SBC $13
JMP commander_dy_ready8
commander_dy_positive8:
SEC
SBC $0301,X
commander_dy_ready8:
STA $53
commander_aim_scale8:
LDA $52
ORA $53
CMP #$10
BCC commander_aim_lookup8
LSR $52
LSR $53
JMP commander_aim_scale8
commander_aim_lookup8:
LDA $53
ASL A
ASL A
ASL A
ASL A
ORA $52
TAX
LDA ufo_aim,X
LDX $55
BEQ commander_aim_xsign8
STA $52
LDA #$18
SEC
SBC $52
commander_aim_xsign8:
LDX $54
BEQ commander_aim_normalize8
STA $52
LDA #$30
SEC
SBC $52
commander_aim_normalize8:
JSR normalize_heading
LDX $B1
RTS

commander_los8:
LDX $B1
LDA #$00
STA $B3
STA $B5
LDA $0300,X
CLC
ADC #$02
STA $B4
LDA $0301,X
CLC
ADC #$02
STA $B6
LDX $B2
LDA ufo_xlo,X
STA $B7
LDA ufo_xhi,X
STA $B8
LDA ufo_ylo,X
STA $B9
LDA ufo_yhi,X
STA $BA
LDA #$60
STA $BB
commander_los_step8:
CLC
LDA $B3
ADC $B7
STA $B3
LDA $B4
ADC $B8
STA $B4
CLC
LDA $B5
ADC $B9
STA $B5
LDA $B6
ADC $BA
STA $B6
LDA $B4
CMP #$04
BCC commander_los_blocked8
CMP #$F8
BCS commander_los_blocked8
LDA $B6
CMP #$0A
BCC commander_los_blocked8
CMP #$E0
BCS commander_los_blocked8
LDA $B4
CMP #$44
BCC commander_los_player8
CMP #$B9
BCS commander_los_player8
LDA $B6
CMP #$4C
BCC commander_los_player8
CMP #$A1
BCC commander_los_blocked8
commander_los_player8:
LDA $B4
SEC
SBC $11
BCS commander_los_absx8
EOR #$FF
CLC
ADC #$01
commander_los_absx8:
CMP #$08
BCS commander_los_continue8
LDA $B6
SEC
SBC $13
BCS commander_los_absy8
EOR #$FF
CLC
ADC #$01
commander_los_absy8:
CMP #$08
BCC commander_los_clear8
commander_los_continue8:
DEC $BB
BNE commander_los_step8
commander_los_blocked8:
LDA #$00
RTS
commander_los_clear8:
LDA #$01
RTS

enemy_shots_tick8:
LDX #$00
enemy_shot_loop8:
LDA $0480,X
BEQ enemy_shot_next8
LDA $0489,X
BEQ enemy_shot_move8
DEC $0480,X
JMP enemy_shot_next8
enemy_shot_move8:
CLC
LDA $0481,X
ADC $0485,X
STA $0481,X
LDA $0482,X
ADC $0486,X
STA $0482,X
CLC
LDA $0483,X
ADC $0487,X
STA $0483,X
LDA $0484,X
ADC $0488,X
STA $0484,X
LDA $0482,X
CMP #$04
BCC enemy_shot_explode8
CMP #$F8
BCS enemy_shot_explode8
LDA $0484,X
CMP #$0A
BCC enemy_shot_explode8
CMP #$E0
BCS enemy_shot_explode8
LDA $0482,X
CMP #$44
BCC enemy_shot_next8
CMP #$B9
BCS enemy_shot_next8
LDA $0484,X
CMP #$4C
BCC enemy_shot_next8
CMP #$A1
BCS enemy_shot_next8
enemy_shot_explode8:
LDA #$0F
STA $0480,X
LDA #$01
STA $0489,X
LDA #$00
STA $0485,X
STA $0486,X
STA $0487,X
STA $0488,X
enemy_shot_next8:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE enemy_shot_loop_jump8
RTS
enemy_shot_loop_jump8:
JMP enemy_shot_loop8

enemy_shots_render8:
LDX #$00
LDY #$30
enemy_shot_render_loop8:
LDA $0480,X
BEQ enemy_shot_hide8
LDA $0489,X
BEQ enemy_shot_normal8
STX $20
LDA $0480,X
SEC
SBC #$01
TAX
LDA explosion_drawing,X
LDX $20
JMP enemy_shot_tile_ready8
enemy_shot_normal8:
LDA #$11
enemy_shot_tile_ready8:
STA $0201,Y
LDA $0484,X
SEC
SBC #$01
STA $0200,Y
LDA #$03
STA $0202,Y
LDA $0482,X
STA $0203,Y
JMP enemy_shot_render_next8
enemy_shot_hide8:
LDA #$F8
STA $0200,Y
enemy_shot_render_next8:
INY
INY
INY
INY
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE enemy_shot_render_loop8
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]
