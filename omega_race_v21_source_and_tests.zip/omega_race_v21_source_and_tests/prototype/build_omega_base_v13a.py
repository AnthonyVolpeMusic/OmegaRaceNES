"""Build Omega Race Version 13A with final-life continuation timing."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v13.py').read_text()

base_v13 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v13.py').read_text(),str(P/'patch_omega_base_v13.py'),'exec'))\\n" + marker)'''
base_v13a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v13a.py').read_text(),str(P/'patch_omega_base_v13a.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v13) == 1
recipe = recipe.replace(base_v13, base_v13 + '\n' + base_v13a, 1)

recipe = recipe.replace('omega_race_v13.nes', 'omega_race_v13a.nes')
recipe = recipe.replace('symbols_omega_v13.json', 'symbols_omega_v13a.json')
recipe = recipe.replace('prototype_omega_v13.asm', 'prototype_omega_v13a.asm')
exec(compile(recipe, str(P / 'build_omega_base_v13.py'), 'exec'))
