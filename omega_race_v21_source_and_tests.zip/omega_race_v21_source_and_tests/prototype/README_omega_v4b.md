# Omega Race NES – Version 4B test build

- Preserves Version 4A as the previous stable checkpoint.
- Reduces Player One's thrust acceleration to 60% of Version 4A.
- Reduces Player One's component top speed from 2.0 to 1.2 pixels per frame.
- Reduces projectile launch speed to 70% while retaining inherited ship
  momentum.
- All Version 4A borders, collision behavior, unlimited projectile range,
  impact animation, controls, graphics, palettes, and sounds remain unchanged.
