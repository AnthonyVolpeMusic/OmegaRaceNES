"""Omega Race V4A top-boundary refinement layered on V4."""

code = '\n'.join(lines)

# The generic Bouncy mover identifies Player One by $0010 and player missiles
# by their $06x1 position records.  Move only those two top limits to $0A;
# every inherited actor retains the original $10 limit.
old = '''LDA #$10
LDY $90
BNE omega_y_low_ready_v3
LDY $8F
CPY #$10
BNE omega_y_low_ready_v3
LDA #$0C
omega_y_low_ready_v3:
STA $91'''
new = '''LDA #$10
LDY $90
BEQ omega_y_check_ship_v4a
CPY #$06
BNE omega_y_low_ready_v4a
LDA #$0A
JMP omega_y_low_ready_v4a
omega_y_check_ship_v4a:
LDY $8F
CPY #$10
BNE omega_y_low_ready_v4a
LDA #$0A
omega_y_low_ready_v4a:
STA $91'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]
