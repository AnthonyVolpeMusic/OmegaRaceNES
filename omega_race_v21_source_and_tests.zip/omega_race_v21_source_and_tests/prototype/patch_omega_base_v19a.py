"""Omega Race 19A: complete wave-song release and relocated title art."""

code = '\n'.join(lines)

# Moving the title text from row 14 to row 17 moves its selectable word from
# $21D5 to $2235; the title-mode HUD is already excluded in Version 19.
old = '''omega_title_flush17:
LDA $06
BNE omega_title_flush_done17
LDA $A7
AND #$80
BEQ omega_title_flush_done17
LDA #$21
STA $2006
LDA #$D5
STA $2006'''
new = '''omega_title_flush17:
LDA $06
BNE omega_title_flush_done17
LDA $A7
AND #$80
BEQ omega_title_flush_done17
LDA #$22
STA $2006
LDA #$35
STA $2006'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# If an effect delayed the song's start, do not rebuild the next wave while
# the tune still owns Pulse 1 and Pulse 2.  Its ordinary end can now release
# the channels before any new-wave sound starts.
old = '''omega_wave_advance9:
INC $C0
JSR omega_level_setup9'''
new = '''omega_wave_advance9:
LDA $D7
BEQ omega_wave_song_finished19a
JMP omega_wave_delay_done9
omega_wave_song_finished19a:
INC $C0
JSR omega_level_setup9'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Stop both hardware pulse channels and zero their output/sequence state at
# the end of the 288-frame song.  The old stop used $B0 (zero-volume pulse)
# and $4015, but did not explicitly clear the two note timers.
old = '''omega_level_song_stop15:
LDA #$00
STA $D7
LDA #$B0
STA $4000
STA $4004
LDA $86
AND #$FC
STA $86
STA $4015
RTS'''
new = '''omega_level_song_stop15:
LDA #$00
STA $D7
STA $DA
STA $DC
STA $82
STA $06A0
STA $89
STA $87
LDA #$30
STA $4000
STA $4004
LDA $86
AND #$FC
STA $86
STA $4015
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)
lines = [s.strip() for s in code.splitlines() if s.strip()]

# Palette 1 is used only by the logo: source brown/transitional pixels are
# color index 1, source yellow index 2, and source red index 3.
data['palette'][4:8] = [0x0F, 0x07, 0x28, 0x16]

old_title = bytes().join(bytes(data[f'title_nt{i}']) for i in range(4))
assert len(old_title) == 1024
new_title = bytearray(1024)
for row in range(27):
    start = row * 32
    new_title[(row + 3) * 32:(row + 4) * 32] = old_title[start:start + 32]

# Regenerate attribute bytes for the logo's new 24x6-tile rectangle.
for ty in range(6, 12):
    for tx in range(4, 28):
        attr = 960 + (ty // 4) * 8 + (tx // 4)
        shift = ((ty // 2) % 2) * 4 + ((tx // 2) % 2) * 2
        new_title[attr] |= 1 << shift

for part in range(4):
    data[f'title_nt{part}'] = list(new_title[part * 256:(part + 1) * 256])
