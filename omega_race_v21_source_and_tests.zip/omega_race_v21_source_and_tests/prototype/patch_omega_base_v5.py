"""Omega Race V5 live center-box HUD."""

code = '\n'.join(lines)

# The 14x10 middle box has twelve interior columns.  The two twelve-character
# lines fill them exactly; SUPERS:5 is padded by two columns on each side.
omega_nt_v5 = bytearray(
    data['omega_nt0_v3'] + data['omega_nt1_v3'] +
    data['omega_nt2_v3'] + data['omega_nt3_v3'])

def omega_hud_text_v5(row, column, text):
    for offset, ch in enumerate(text):
        omega_nt_v5[row * 32 + column + offset] = title_glyph(ch)

omega_hud_text_v5(12, 10, 'SCORE:000000')
omega_hud_text_v5(14, 12, 'SUPERS:5')
omega_hud_text_v5(16, 10, 'LIVES LEFT:3')
data['omega_nt0_v3'] = omega_nt_v5[:256]
data['omega_nt1_v3'] = omega_nt_v5[256:512]
data['omega_nt2_v3'] = omega_nt_v5[512:768]
data['omega_nt3_v3'] = omega_nt_v5[768:]

# Publish only the changing values during vblank.  Score digits already live
# in $33..$38, supers in $07, and remaining lives in $3D.  Numeric glyph zero
# starts at tile $7B.
old = '''LDA #$02
STA $4014
LDA #$00
STA $2005'''
new = '''LDA #$02
STA $4014
JSR omega_hud_update_v5
LDA #$00
STA $2005'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

hud_code = '''omega_hud_update_v5:
LDA #$21
STA $2006
LDA #$90
STA $2006
LDX #$00
omega_hud_score_v5:
LDA $33,X
CLC
ADC #$7B
STA $2007
INX
CPX #$06
BNE omega_hud_score_v5
LDA #$21
STA $2006
LDA #$D3
STA $2006
LDA $07
CLC
ADC #$7B
STA $2007
LDA #$22
STA $2006
LDA #$15
STA $2006
LDA $3D
CLC
ADC #$7B
STA $2007
RTS
'''
assert code.count('irq:\nRTI\n') == 1
code = code.replace('irq:\nRTI\n', 'irq:\nRTI\n' + hud_code, 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]
