"""Version 13: three supers and arcade-style round/life timing."""

code = '\n'.join(lines)

# Dispatch the two non-playing Omega states explicitly: state 1 lets the world
# continue after death, while state 4 is the frozen two-second spawn flash.
old = '''omega_frame9:
JSR controls
LDA $0677
BEQ omega_frame_alive9
CMP #$01
BNE omega_frame_finish9
JSR death_explosion_tick22
JSR omega_death_tick9
JMP omega_frame_finish9
omega_frame_alive9:'''
new = '''omega_frame9:
JSR controls
LDA $0677
BEQ omega_frame_alive9
CMP #$01
BEQ omega_frame_death13
CMP #$04
BNE omega_frame_finish9
JSR omega_spawn_tick13
BCC omega_frame_finish9
JMP omega_frame_alive9
omega_frame_death13:
JSR death_explosion_tick22
JSR bullets
JSR enemy_shots_tick8
JSR omega_mine_bullet_collision12
JSR drone_collision7b
JSR drone_tick6
JSR omega_death_tick9
JMP omega_frame_finish9
omega_frame_alive9:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# A new board begins frozen in state 4. $0678 is the exact 120-frame timer;
# $D1 is a dedicated 0..19 flash phase that does not conflict with the death
# burst timer in $067D.
old = '''LDA #$00
STA $0677
STA $0678
STA $067D'''
new = '''LDA #$04
STA $0677
LDA #$78
STA $0678
LDA #$FF
STA $D1
LDA #$00
STA $067D'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Three supers are issued on every complete board setup.
assert code.count('LDA #$05\nSTA $07\nJSR omega_hud_request_supers_v5a') == 1
code = code.replace('LDA #$05\nSTA $07\nJSR omega_hud_request_supers_v5a',
                    'LDA #$03\nSTA $07\nJSR omega_hud_request_supers_v5a', 1)

# Do not erase either side's projectiles at the instant Player One dies, and
# do not enter the frozen game-over state until Player One's shots finish.
old = '''LDA #$01
STA $0677
LDA #$B4
STA $0678
LDA #$00
STA $08
STA $14
STA $15
STA $16
STA $17
LDX #$3F
omega_death_clear_player_shots9:
STA $0600,X
DEX
BPL omega_death_clear_player_shots9
LDX #$5F
omega_death_clear_enemy_shots9:
STA $0580,X
DEX
BPL omega_death_clear_enemy_shots9
LDA $3D
BEQ omega_player_no_life9
DEC $3D
JSR omega_hud_request_lives_v5a
LDA $3D
BNE omega_player_kill_done9
omega_player_no_life9:
LDA #$02
STA $0677
omega_player_kill_done9:'''
new = '''LDA #$01
STA $0677
LDA #$00
STA $0678
STA $08
STA $14
STA $15
STA $16
STA $17
LDA $3D
BEQ omega_player_kill_done9
DEC $3D
JSR omega_hud_request_lives_v5a
omega_player_kill_done9:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Wait for every live/impact Player One shot record to disappear. Then either
# freeze immediately on zero lives or run a full 120-frame delay before the
# same level is rebuilt and enters its own 120-frame spawn flash.
old = '''omega_death_tick9:
LDA $0678
BEQ omega_death_expired9
DEC $0678
BNE omega_death_done9
omega_death_expired9:
LDA $3D
BEQ omega_death_done9
JSR omega_level_setup9
omega_death_done9:
RTS'''
new = '''omega_death_tick9:
LDX #$00
omega_death_shot_scan13:
LDA $0600,X
BNE omega_death_done9
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE omega_death_shot_scan13
LDA $3D
BNE omega_death_life_wait13
LDA #$02
STA $0677
RTS
omega_death_life_wait13:
LDA $0678
BNE omega_death_count13
LDA #$78
STA $0678
RTS
omega_death_count13:
DEC $0678
BNE omega_death_done9
JSR omega_level_setup9
omega_death_done9:
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Render Player One during the visible half of the spawn flash. All other
# states continue to hide the ship while leaving the world visible.
old = '''LDA $0677
BEQ render_alive21
JMP render_player_bullets21
render_alive21:'''
new = '''LDA $0677
BEQ render_alive21
CMP #$04
BNE render_player_bullets21
LDA $D1
CMP #$0A
BCS render_player_bullets21
JMP render_alive21
render_alive21:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += '''
omega_spawn_tick13:
LDA $0678
BEQ omega_spawn_ready13
DEC $0678
INC $D1
LDA $D1
CMP #$14
BCC omega_spawn_wait13
LDA #$00
STA $D1
omega_spawn_wait13:
CLC
RTS
omega_spawn_ready13:
LDA #$00
STA $0677
SEC
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]

# Keep both static HUD sources consistent with the live counter.
data['omega_nt1_v3'][14 * 32 + 19 - 256] = 0x7E
if 'hud_line' in data:
    assert data['hud_line'][21] == 0x80
    data['hud_line'][21] = 0x7E
