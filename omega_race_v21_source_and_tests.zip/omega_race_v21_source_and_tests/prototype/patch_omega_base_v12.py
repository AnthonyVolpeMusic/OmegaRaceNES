"""Version 12: persistent, shootable land mines dropped by advanced enemies."""

code = '\n'.join(lines)

# Resolve mine hits before enemy hits so one projectile cannot destroy both.
old = '''JSR drone_collision7b
JSR drone_tick6'''
new = '''JSR omega_mine_bullet_collision12
JSR drone_collision7b
JSR drone_tick6'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Commanders tick a four-second drop timer; Shooting Stars tick a two-second
# timer. Basic drones never enter either branch.
old = '''JSR omega_commander_tick11
LDA $0306,X'''
new = '''JSR omega_mine_tick12
JSR omega_commander_tick11
LDA $0306,X'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''drone_tick_star11:
DEC $0307,X'''
new = '''drone_tick_star11:
JSR omega_mine_tick12
DEC $0307,X'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Initialize the drop timer whenever an advanced enemy is spawned, promoted or
# converted. Conversion restarts the shorter Shooting Star interval.
old = '''LDA #$0C
STA $030B,X
JSR drone_assign6
LDY $AD'''
new = '''LDA #$0C
STA $030B,X
JSR omega_mine_timer_reset12
JSR drone_assign6
LDY $AD'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''LDA #$0C
STA $030B,X
RTS
omega_force_promote11:'''
new = '''LDA #$0C
STA $030B,X
JSR omega_mine_timer_reset12
RTS
omega_force_promote11:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''LDA #$01
STA $030A,X
STA $030B,X
JSR drone_assign6'''
new = '''LDA #$01
STA $030A,X
STA $030B,X
JSR omega_mine_timer_reset12
JSR drone_assign6'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Render sixteen one-sprite mines after the six enemy-shot OAM slots.
old = '''JSR enemy_shots_render8
RTS
drone_collision7b:'''
new = '''JSR enemy_shots_render8
JSR omega_mines_render12
RTS
drone_collision7b:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Add stationary-mine contact to the existing Player One collision pass.
old = '''CPX #$60
BNE omega_player_shot_loop9
omega_player_collision_done9:
RTS'''
new = '''CPX #$60
BNE omega_player_shot_loop9
JSR omega_mine_player_hit12
BCC omega_player_collision_done9
JMP omega_player_kill9
omega_player_collision_done9:
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Mines persist through complete level setup. Only a mine whose stored position
# is within eight pixels of the newly chosen Player One spawn is removed.
old = '''LDA #$18
STA $13
LDX #$3F'''
new = '''LDA #$18
STA $13
JSR omega_mine_spawn_cleanup12
LDX #$3F'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += '''
omega_mine_timer_reset12:
LDA $0306,X
CMP #$02
BEQ omega_mine_timer_star12
CMP #$01
BEQ omega_mine_timer_commander12
LDA #$00
STA $030E,X
RTS
omega_mine_timer_commander12:
LDA #$F0
BNE omega_mine_timer_store12
omega_mine_timer_star12:
LDA #$78
omega_mine_timer_store12:
STA $030E,X
RTS

omega_mine_tick12:
DEC $030E,X
BNE omega_mine_tick_done12
JSR omega_mine_drop12
JSR omega_mine_timer_reset12
omega_mine_tick_done12:
RTS

omega_mine_drop12:
STX $B1
LDY #$00
omega_mine_drop_scan12:
LDA $0700,Y
BEQ omega_mine_drop_here12
TYA
CLC
ADC #$04
TAY
CPY #$40
BNE omega_mine_drop_scan12
LDX $B1
RTS
omega_mine_drop_here12:
LDA #$FF
STA $0700,Y
LDX $B1
LDA $0300,X
STA $0701,Y
LDA $0301,X
STA $0702,Y
LDX $B1
RTS

omega_mines_render12:
LDX #$00
LDY #$6C
omega_mine_render_loop12:
LDA $0700,X
BEQ omega_mine_render_hide12
LDA $0702,X
SEC
SBC #$01
STA $0200,Y
LDA #$EC
STA $0201,Y
LDA #$01
STA $0202,Y
LDA $0701,X
STA $0203,Y
JMP omega_mine_render_next12
omega_mine_render_hide12:
LDA #$F8
STA $0200,Y
omega_mine_render_next12:
INY
INY
INY
INY
TXA
CLC
ADC #$04
TAX
CPX #$40
BNE omega_mine_render_loop12
RTS

omega_mine_player_hit12:
LDX #$00
omega_mine_player_loop12:
LDA $0700,X
BEQ omega_mine_player_next12
LDA $11
CLC
ADC #$08
CMP $0701,X
BCC omega_mine_player_next12
BEQ omega_mine_player_next12
LDA $0701,X
CLC
ADC #$08
CMP $11
BCC omega_mine_player_next12
BEQ omega_mine_player_next12
LDA $13
CLC
ADC #$08
CMP $0702,X
BCC omega_mine_player_next12
BEQ omega_mine_player_next12
LDA $0702,X
CLC
ADC #$08
CMP $13
BCC omega_mine_player_next12
BEQ omega_mine_player_next12
SEC
RTS
omega_mine_player_next12:
TXA
CLC
ADC #$04
TAX
CPX #$40
BNE omega_mine_player_loop12
CLC
RTS

omega_mine_bullet_collision12:
LDY #$00
omega_mine_bullet_loop12:
LDA $0600,Y
BNE omega_mine_bullet_active12
JMP omega_mine_bullet_next12
omega_mine_bullet_active12:
LDA $0609,Y
BEQ omega_mine_bullet_flying12
JMP omega_mine_bullet_next12
omega_mine_bullet_flying12:
STY $B0
LDX #$00
omega_mine_hit_loop12:
LDA $0700,X
BNE omega_mine_hit_active12
JMP omega_mine_hit_next12
omega_mine_hit_active12:
LDY $B0
LDA $0602,Y
CLC
ADC #$03
CMP $0701,X
BCC omega_mine_hit_next12
LDA $0701,X
CLC
ADC #$08
CMP $0602,Y
BCC omega_mine_hit_next12
BEQ omega_mine_hit_next12
LDA $0604,Y
CLC
ADC #$03
CMP $0702,X
BCC omega_mine_hit_next12
LDA $0702,X
CLC
ADC #$08
CMP $0604,Y
BCC omega_mine_hit_next12
BEQ omega_mine_hit_next12
LDA #$00
STA $0700,X
LDA $0701,X
STA $0602,Y
LDA $0702,X
STA $0604,Y
LDA #$0F
STA $0600,Y
LDA #$01
STA $0609,Y
LDA #$00
STA $0605,Y
STA $0606,Y
STA $0607,Y
STA $0608,Y
LDA #$FA
JSR score_add
LDA #$64
JSR score_add
JSR omega_hud_request_score_v5a
LDY $B0
JMP omega_mine_bullet_next12
omega_mine_hit_next12:
TXA
CLC
ADC #$04
TAX
CPX #$40
BEQ omega_mine_hit_scan_done12
JMP omega_mine_hit_loop12
omega_mine_hit_scan_done12:
LDY $B0
omega_mine_bullet_next12:
TYA
CLC
ADC #$10
TAY
CPY #$40
BEQ omega_mine_bullet_done12
JMP omega_mine_bullet_loop12
omega_mine_bullet_done12:
RTS

omega_mine_spawn_cleanup12:
LDX #$00
omega_mine_cleanup_loop12:
LDA $0700,X
BEQ omega_mine_cleanup_next12
LDA $0701,X
SEC
SBC $11
BCS omega_mine_cleanup_absx12
EOR #$FF
CLC
ADC #$01
omega_mine_cleanup_absx12:
CMP #$09
BCS omega_mine_cleanup_next12
LDA $0702,X
SEC
SBC $13
BCS omega_mine_cleanup_absy12
EOR #$FF
CLC
ADC #$01
omega_mine_cleanup_absy12:
CMP #$09
BCS omega_mine_cleanup_next12
LDA #$00
STA $0700,X
omega_mine_cleanup_next12:
TXA
CLC
ADC #$04
TAX
CPX #$40
BNE omega_mine_cleanup_loop12
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]
