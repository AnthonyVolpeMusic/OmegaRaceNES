"""Machine-code regression tests for Omega Race Version 12A."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v12.py').read_text()
text = text.replace('Version 12.', 'Version 12A.', 1)
text = text.replace('omega_race_v12.nes', 'omega_race_v12a.nes')
text = text.replace('symbols_omega_v12.json', 'symbols_omega_v12a.json')
text = text.replace('exactly 240 active frames', 'exactly 180 active frames')
text = text.replace('exactly 120; conversion', 'exactly 60; conversion')
text = text.replace('mm[0x30E] == 240', 'mm[0x30E] == 180')
text = text.replace('range(239)', 'range(179)')
text = text.replace('mm[0x30E] == 120', 'mm[0x30E] == 60')
text = text.replace('range(119)', 'range(59)')
text = text.replace('every four seconds and Shooting Stars every two seconds',
                    'every three seconds and Shooting Stars every one second')
exec(compile(text, str(P / 'test_omega_v12.py'), 'exec'))


palettes = [
    [0x08,0x18,0x28,0x38],
    [0x0C,0x1C,0x2C,0x3C],
    [0x04,0x13,0x22,0x31],
    [0x01,0x12,0x23,0x34],
    [0x0B,0x1A,0x29,0x38],
    [0x06,0x17,0x28,0x39],
    [0x05,0x15,0x25,0x35],
    [0x21,0x11,0x01,0x0D],
]

# Level setup selects (level-1) modulo eight. The event writer emits exactly
# four background bytes, leaving all sprite-palette entries untouched.
mm, cc = boot()
assert mm[0xCF] == 0
last = 0
for level in range(1, 18):
    mm[0xC0] = level
    mm[0xA7] = 0
    call(mm, cc, 'omega_level_setup9')
    index = (level - 1) & 7
    assert mm[0xCF] == index
    if index != last:
        assert mm[0xA7] & 0x08
    else:
        assert not (mm[0xA7] & 0x08)
    mm.ppu = []
    mm[0xA7] = 0x08
    call(mm, cc, 'omega_hud_flush_v5a')
    assert mm.ppu == palettes[index]
    last = index
assert palettes[0] == [0x08,0x18,0x28,0x38]
print('PASS exact tile palettes rotate over eight levels and Level 9 returns to Level 1')

# Rebuilding the same level does not waste another NMI palette write.
mm, cc = boot()
mm[0xC0] = 6
call(mm, cc, 'omega_level_setup9')
assert mm[0xA7] & 0x08 and mm[0xCF] == 5
mm[0xA7] = 0
call(mm, cc, 'omega_level_setup9')
assert not (mm[0xA7] & 0x08)
print('PASS same-level respawns retain their palette without redundant PPU updates')
