"""Machine-code regression tests for Omega Race Version 9."""
from pathlib import Path

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
text = base.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v9.nes')
text = text.replace('symbols_omega_base_v1.json', 'symbols_omega_v9.json')
text = text.replace('range(400000)', 'range(900000)')
env = {'__file__': str(P / 'test_omega_v9.py')}
exec(compile(text, 'harness', 'exec'), env)
boot, call, S = env['boot'], env['call'], env['S']


def active(mm):
    return [a for a in range(0x300, 0x400, 16) if mm[a + 5]]


def commanders(mm):
    return [a for a in active(mm) if mm[a + 6] == 1]


mm, cc = boot()
assert mm[0xC0:0xC5] == [1, 7, 1, 120, 0]
assert len(active(mm)) == 7 and len(commanders(mm)) == 1
assert (mm[0x11], mm[0x13], mm[0x03]) == (0xE0, 0x18, 0x24)
assert all(mm[a] < 0x80 for a in active(mm))
assert not any(mm[0x580:0x5E0])
print('PASS Level 1 boots with 6 drones, 1 Commander, upper-right P1 and six empty shot slots')

# Exact requested formation, firing and speed tables through and beyond caps.
counts = [(7,1),(8,1),(10,2),(11,2),(13,3),(14,3),(16,4),(16,4),(16,4),(16,4)]
fires = [120,90,60,45,30,30,30,30,30,30]
speed_indices = [0,1,2,3,4,5,6,7,8,8]
odd_route = None
for level in range(1, 11):
    mm, cc = boot()
    mm[0xC0] = level
    call(mm, cc, 'omega_level_setup9')
    total, cmd = counts[level - 1]
    assert (len(active(mm)), len(commanders(mm))) == (total, cmd)
    assert (mm[0xC3], mm[0xC4]) == (fires[level - 1], speed_indices[level - 1])
    if level & 1:
        assert (mm[0x11], mm[0x03]) == (0xE0, 0x24)
        assert all(mm[a] < 0x80 for a in active(mm))
        if level == 1:
            odd_route = list(mm[0x400:0x480])
    else:
        assert (mm[0x11], mm[0x03]) == (0x18, 0x0C)
        assert all(mm[a] > 0x80 for a in active(mm))
        assert all(even == 0xF8 - odd for even, odd in zip(mm[0x400:0x480], odd_route))
print('PASS levels 1-10 match all counts, mirrored corners, fire intervals and speed caps')

# All sixteen enemies retain independent route data and clear the arena walls.
mm, cc = boot()
mm[0xC0] = 7
call(mm, cc, 'omega_level_setup9')
routes = [tuple(mm[0x400+i*8:0x408+i*8] + mm[0x500+i*8:0x508+i*8]) for i in range(16)]
assert len(set(routes)) == 16
for _ in range(2400):
    call(mm, cc, 'drone_tick6')
for a in active(mm):
    assert 16 <= mm[a] <= 232 and 16 <= mm[a + 1] <= 208
print('PASS sixteen distinct personal routes remain inside both walls')

# Table-driven movement rises by 25% per level and caps at 3x; Commander gets
# two identical movement steps and therefore remains exactly 2x.
for level, expected in ((1,64),(2,80),(3,96),(4,112),(5,128),(6,144),(7,160),(8,176),(9,192),(12,192)):
    mm, cc = boot()
    mm[0xC0] = level
    call(mm, cc, 'omega_level_config9')
    mm[0x300:0x307] = [20, mm[0x500], 0, 1, 0, 1, 0]
    cc.x = 0
    call(mm, cc, 'drone_move6')
    assert mm[0x304] == expected
mm, cc = boot()
mm[0xC0] = 4
call(mm, cc, 'omega_level_setup9')
for a in (0x300, 0x320):
    mm[a], mm[a+1], mm[a+2], mm[a+4], mm[a+5] = 20, mm[0x500 + ((a-0x300)//2)], 0, 0, 1
mm[0x306], mm[0x326] = 1, 0
mm[0x307] = 0xFF
call(mm, cc, 'drone_tick6')
assert mm[0x304] == (2 * mm[0x324]) & 0xFF
print('PASS enemy speed progression and exact Commander 2x multiplier')

# Six live projectile records block additional fire; freeing one permits one.
mm, cc = boot()
mm[0x300], mm[0x301] = 32, 40
mm[0x11], mm[0x13] = 220, 40
for a in range(0x580, 0x5E0, 16):
    mm[a] = 0xFF
cc.x = 0
call(mm, cc, 'commander_try_fire8')
assert sum(mm[a] != 0 for a in range(0x580, 0x5E0, 16)) == 6
mm[0x5D0] = 0
cc.x = 0
call(mm, cc, 'commander_try_fire8')
assert sum(mm[a] != 0 for a in range(0x580, 0x5E0, 16)) == 6 and mm[0x5D0] != 0
print('PASS collective enemy-missile cap is exactly six')

# Direct contact kills P1, removes one life, starts four moving explosion
# pieces, clears all shots and restarts the same complete level after 180 ticks.
mm, cc = boot()
mm[0x30:0x33] = [0x39, 0x30, 0]
mm[0x300], mm[0x301] = mm[0x11], mm[0x13]
mm[0x600] = mm[0x580] = 0xFF
call(mm, cc, 'omega_player_collision9')
assert mm[0x0677:0x0679] == [1, 180] and mm[0x3D] == 2
assert mm[0x67D] == 25 and not any(mm[0x600:0x640]) and not any(mm[0x580:0x5E0])
pieces = [tuple(mm[0x6E0+i:0x6E8+i]) for i in range(0, 32, 8)]
assert len(pieces) == 4 and all(p[1] == 0xE0 and p[3] == 0x18 for p in pieces)
assert all(any(p[j] for j in (4,5,6,7)) for p in pieces)
for _ in range(179):
    call(mm, cc, 'omega_death_tick9')
assert mm[0x677] == 1 and mm[0x678] == 1
call(mm, cc, 'omega_death_tick9')
assert mm[0x677] == 0 and mm[0xC0] == 1 and len(active(mm)) == 7
assert mm[0x30:0x33] == [0x39, 0x30, 0] and mm[0x3D] == 2
print('PASS enemy contact: four-piece death, life decrement and three-second same-level reset')

# A flying enemy missile also kills P1; its explosion form does not.
mm, cc = boot()
mm[0x580:0x58A] = [0xFF,0,mm[0x11]+2,0,mm[0x13]+2,0,0,0,0,1]
call(mm, cc, 'omega_player_collision9')
assert mm[0x677] == 0 and mm[0x3D] == 3
mm[0x589] = 0
call(mm, cc, 'omega_player_collision9')
assert mm[0x677] == 1 and mm[0x3D] == 2
print('PASS flying enemy missile kills P1; wall-impact animation does not')

# No remaining lives leaves the ship dead instead of restarting.
mm, cc = boot()
mm[0x3D] = 1
mm[0x300], mm[0x301] = mm[0x11], mm[0x13]
call(mm, cc, 'omega_player_collision9')
assert mm[0x3D] == 0 and mm[0x677] == 2
for _ in range(240):
    call(mm, cc, 'omega_death_tick9')
assert mm[0x677] == 2 and mm[0x3D] == 0
print('PASS zero lives holds the dead state pending a future Game Over screen')

# Clearing a wave waits exactly 300 frames, advances the level and rebuilds
# the mirrored formation. Score and remaining lives persist; supers refill.
mm, cc = boot()
mm[0x30:0x33] = [0x34,0x12,0]
mm[0x3D], mm[0x07] = 2, 1
for a in range(0x300, 0x400, 16):
    mm[a + 5] = 0
call(mm, cc, 'omega_wave_check9')
assert mm[0xC7] == 1 and mm[0xC5:0xC7] == [0x2C, 0x01]
for _ in range(299):
    call(mm, cc, 'omega_wave_delay9')
assert mm[0xC0] == 1
call(mm, cc, 'omega_wave_delay9')
assert mm[0xC0] == 2 and mm[0xC7] == 0
assert (len(active(mm)),len(commanders(mm))) == (8,1)
assert (mm[0x11],mm[0x03]) == (0x18,0x0C)
assert mm[0x30:0x33] == [0x34,0x12,0] and mm[0x3D] == 2 and mm[0x07] == 5
print('PASS five-second wave delay advances and completely rebuilds the mirrored next level')

# A killed Commander restores the multi-Commander quota when drones survive.
mm, cc = boot()
mm[0xC0] = 5
call(mm, cc, 'omega_level_setup9')
target = commanders(mm)[0]
mm[0x600], mm[0x602], mm[0x604], mm[0x609] = 0xFF, mm[target], mm[target+1], 0
call(mm, cc, 'drone_collision7b')
assert len(commanders(mm)) == 3 and len(active(mm)) == 12
print('PASS Commander destruction maintains the current level Commander quota')

# Stress the level-seven maximum formation/fire rate in the real main/NMI loop.
mm, cc = boot()
mm[0xC0] = 7
call(mm, cc, 'omega_level_setup9')
mm.ppu = []
mm.pad = 0
cc.pc = S['main']
cc.sp = 255
deadline = cc.processorCycles
for _ in range(360):
    end = deadline + 29781
    while cc.processorCycles < end:
        if cc.processorCycles >= deadline:
            cc.nmi()
            deadline += 29781
        cc.step()
assert 358 <= mm.dmas <= 360, (len(mm.ppu), mm.dmas, cc.pc, mm[0x677], mm[0x3D])
assert len(mm.ppu) <= 8
assert sum(mm[a] != 0 for a in range(0x580,0x5E0,16)) <= 6
print('PASS six seconds at maximum formation/fire rate remain stable within the frame budget')
