"""Build Omega Race Version 18."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v17b.py').read_text()

base_v17b = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v17b.py').read_text(),str(P/'patch_omega_base_v17b.py'),'exec'))\\n" + marker)'''
base_v18 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v18.py').read_text(),str(P/'patch_omega_base_v18.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v17b) == 1
recipe = recipe.replace(base_v17b, base_v17b + '\n' + base_v18, 1)

recipe = recipe.replace('omega_race_v17b.nes', 'omega_race_v18.nes')
recipe = recipe.replace('symbols_omega_v17b.json', 'symbols_omega_v18.json')
recipe = recipe.replace('prototype_omega_v17b.asm', 'prototype_omega_v18.asm')
exec(compile(recipe, str(P / 'build_omega_base_v17b.py'), 'exec'))
