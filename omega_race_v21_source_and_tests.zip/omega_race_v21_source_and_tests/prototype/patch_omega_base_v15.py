"""Version 15: synchronized two-voice level-clear song."""

code = '\n'.join(lines)

# Once the tune is active, ordinary Pulse 1 effects cannot interrupt Voice 1.
old = '''omega_pulse1_start14:
STA $D4'''
new = '''omega_pulse1_start14:
PHA
LDA $D7
CMP #$FF
BNE omega_pulse1_song_free15
PLA
RTS
omega_pulse1_song_free15:
PLA
STA $D4'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Let the ordinary Pulse 1 effect finish, then service the pending/active song.
old = '''sfx_done25:
RTS'''
new = '''sfx_done25:
LDA $D7
BEQ omega_level_song_done15
JSR omega_level_song_tick15
omega_level_song_done15:
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# While the song is active it owns Pulse 2; pending state still allows an
# existing shield/stop cue to advance normally.
old = '''pulse2_start26:
STA $8B'''
new = '''pulse2_start26:
PHA
LDA $D7
CMP #$FF
BNE pulse2_song_free15
PLA
RTS
pulse2_song_free15:
PLA
STA $8B'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''pulse2_tick26:
LDA $89'''
new = '''pulse2_tick26:
LDA $D7
CMP #$FF
BEQ pulse2_done26
LDA $89'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Clear all song state during a full audio reset.
old = '''STA $D5
STA $D6
STA $4015'''
new = '''STA $D5
STA $D6
STA $D7
STA $D8
STA $D9
STA $DA
STA $DB
STA $DC
STA $4015'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Arm the tune at successful wave completion. It does not begin until the
# final enemy's Pulse 1 destruction/extra-life cue has naturally completed.
old = '''LDA #$01
STA $C7
LDA #$2C'''
new = '''LDA #$01
STA $C7
STA $D7
LDA #$2C'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# A board rebuild cannot inherit any stale song state.
old = '''STA $067D
STA $C5
STA $C6
STA $C7'''
new = '''STA $067D
STA $C5
STA $C6
STA $C7
STA $D7
STA $D8
STA $D9
STA $DA
STA $DB
STA $DC'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += r'''
omega_level_song_tick15:
LDA $D7
CMP #$FF
BEQ omega_level_song_active15
LDA $82
BNE omega_level_song_return15
LDA #$FF
STA $D7
LDA #$00
STA $D8
STA $D9
STA $DA
STA $DB
STA $DC
STA $82
STA $83
STA $87
STA $89
LDA #$08
STA $4001
STA $4005
LDA #$BF
STA $4000
STA $4004
LDA $86
ORA #$03
STA $86
STA $4015
omega_level_song_active15:
LDA $D8
CMP #$C0
BEQ omega_level_song_stop15
LDA $DA
BNE omega_level_song_voice1_hold15
LDX $D9
LDA omega_clear_voice1_duration15,X
STA $DA
LDA omega_clear_voice1_low15,X
STA $4002
LDA omega_clear_voice1_high15,X
STA $4003
INC $D9
omega_level_song_voice1_hold15:
DEC $DA
LDA $DC
BNE omega_level_song_voice2_hold15
LDX $DB
LDA omega_clear_voice2_duration15,X
STA $DC
LDA omega_clear_voice2_low15,X
STA $4006
LDA omega_clear_voice2_high15,X
STA $4007
INC $DB
omega_level_song_voice2_hold15:
DEC $DC
INC $D8
omega_level_song_return15:
RTS
omega_level_song_stop15:
LDA #$00
STA $D7
LDA #$B0
STA $4000
STA $4004
LDA $86
AND #$FC
STA $86
STA $4015
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]

# Voice 1: three identical 48-frame measures, then the 48-frame cadence.
voice1_notes = [
    (0x7E,0,3),(0x77,0,3),(0x7E,0,3),(0x77,0,3),(0x6A,0,12),(0x9F,0,24),
    (0x7E,0,3),(0x77,0,3),(0x7E,0,3),(0x77,0,3),(0x6A,0,12),(0x9F,0,24),
    (0x7E,0,3),(0x77,0,3),(0x7E,0,3),(0x77,0,3),(0x6A,0,12),(0x9F,0,24),
    (0x7E,0,3),(0x77,0,3),(0x7E,0,3),(0x77,0,3),(0x8E,0,36),
]

# Voice 2: G3/E3/F3/C3 ostinato, followed by A2/A#2/C3 cadence.
voice2_notes = [
    (0x3A,2,6),(0xA6,2,6),(0x80,2,12),(0x56,3,24),
    (0x3A,2,6),(0xA6,2,6),(0x80,2,12),(0x56,3,24),
    (0x3A,2,6),(0xA6,2,6),(0x80,2,12),(0x56,3,24),
    (0xF8,3,6),(0xBF,3,6),(0x56,3,36),
]

assert sum(n[2] for n in voice1_notes) == 192
assert sum(n[2] for n in voice2_notes) == 192
data['omega_clear_voice1_low15'] = [n[0] for n in voice1_notes]
data['omega_clear_voice1_high15'] = [n[1] for n in voice1_notes]
data['omega_clear_voice1_duration15'] = [n[2] for n in voice1_notes]
data['omega_clear_voice2_low15'] = [n[0] for n in voice2_notes]
data['omega_clear_voice2_high15'] = [n[1] for n in voice2_notes]
data['omega_clear_voice2_duration15'] = [n[2] for n in voice2_notes]
