"""Omega Race V5A event-driven HUD patch layered on Version 5."""

code = '\n'.join(lines)

# $A7 is a HUD dirty-bit byte: bit 0 score, bit 1 supers, bit 2 lives.  A
# normal frame with no gameplay event performs no nametable writes.
assert code.count('JSR omega_hud_update_v5') == 1
code = code.replace('JSR omega_hud_update_v5', 'JSR omega_hud_flush_v5a', 1)

# Every current super-consumption path requests exactly one supers refresh.
# This includes the dormant rainbow-shot path so future control changes remain
# correct without revisiting HUD bookkeeping.
for old, new in (
    ('shield_available:\nDEC $07\nLDA #$3C',
     'shield_available:\nDEC $07\nJSR omega_hud_request_supers_v5a\nLDA #$3C'),
    ('special_stop:\nDEC $07\nLDA #$09',
     'special_stop:\nDEC $07\nJSR omega_hud_request_supers_v5a\nLDA #$09'),
    ('BNE rainbow_check\nDEC $07\nJSR sfx_shot_start25',
     'BNE rainbow_check\nDEC $07\nJSR omega_hud_request_supers_v5a\nJSR sfx_shot_start25'),
):
    assert code.count(old) == 1
    code = code.replace(old, new, 1)

start = code.index('omega_hud_update_v5:')
end = code.index('load_title:', start)
hud_code = '''omega_hud_request_score_v5a:
LDA $A7
ORA #$01
STA $A7
RTS
omega_hud_request_supers_v5a:
LDA $A7
ORA #$02
STA $A7
RTS
omega_hud_request_lives_v5a:
LDA $A7
ORA #$04
STA $A7
RTS
omega_hud_flush_v5a:
LDA $A7
BEQ omega_hud_flush_done_v5a
AND #$01
BEQ omega_hud_supers_check_v5a
LDA #$21
STA $2006
LDA #$90
STA $2006
LDX #$00
omega_hud_score_v5a:
LDA $33,X
CLC
ADC #$7B
STA $2007
INX
CPX #$06
BNE omega_hud_score_v5a
omega_hud_supers_check_v5a:
LDA $A7
AND #$02
BEQ omega_hud_lives_check_v5a
LDA #$21
STA $2006
LDA #$D3
STA $2006
LDA $07
CLC
ADC #$7B
STA $2007
omega_hud_lives_check_v5a:
LDA $A7
AND #$04
BEQ omega_hud_flush_clear_v5a
LDA #$22
STA $2006
LDA #$15
STA $2006
LDA $3D
CLC
ADC #$7B
STA $2007
omega_hud_flush_clear_v5a:
LDA #$00
STA $A7
omega_hud_flush_done_v5a:
RTS
'''
code = code[:start] + hud_code + code[end:]

lines = [s.strip() for s in code.splitlines() if s.strip()]
