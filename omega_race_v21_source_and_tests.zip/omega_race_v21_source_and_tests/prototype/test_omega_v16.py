"""Machine-code regression tests for Omega Race Version 16."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v15a.py').read_text()
text = text.replace('Version 15A', 'Version 16')
text = text.replace('omega_race_v15a.nes', 'omega_race_v16.nes')
text = text.replace('symbols_omega_v15a.json', 'symbols_omega_v16.json')
text = text.replace('prototype_omega_v15a.asm', 'prototype_omega_v16.asm')
exec(compile(text, str(P / 'test_omega_v15a.py'), 'exec'))


def triangle_frame(mm, cc):
    call(mm, cc, 'pulse_gate24c')
    if not (mm[0x86] & 4):
        return None
    return mm[0x400A] | ((mm[0x400B] & 7) << 8)


def gameplay_with_enemy(enemy_type=0):
    mm, cc = boot()
    mm[0x06] = 1
    mm[0x677] = 0
    mm[0xC7] = 0
    for address in range(0x300, 0x400, 0x10):
        mm[address + 5] = 0
    mm[0x305] = 1
    mm[0x306] = enemy_type
    mm[0x7B] = 24
    mm[0x7C] = mm[0x7D] = mm[0x7E] = mm[0x67F] = 0
    return mm, cc


# At the opening tempo, each note lasts six frames and is followed by exactly
# 24 silent frames. The four-note loop therefore takes 120 frames.
mm, cc = gameplay_with_enemy()
normal = [triangle_frame(mm, cc) for _ in range(120)]
expected = []
for period in (0x23A, 0x280, 0x2CE, 0x356):
    expected += [period] * 6 + [None] * 24
assert normal == expected
print('PASS normal triangle loop plays G2/F2/E-flat2/C2 with 6+24 timing')


# Every enemy kill removes two rest frames, reaches six after nine kills, and
# cannot reduce the rest below that floor.
mm, cc = gameplay_with_enemy()
rests = []
for _ in range(12):
    call(mm, cc, 'omega_triangle_kill16')
    rests.append(mm[0x7B])
assert rests == [22,20,18,16,14,12,10,8,6,6,6,6]
print('PASS kill-driven rest sequence is 22/20/18/.../6 with a hard floor')


# A kill during a long normal rest clamps that rest to the newly earned tempo.
mm, cc = gameplay_with_enemy()
for _ in range(7):
    triangle_frame(mm, cc)
assert not (mm[0x86] & 4) and mm[0x7D] == 0 and mm[0x67F] == 24
call(mm, cc, 'omega_triangle_kill16')
assert mm[0x7B] == 22 and mm[0x67F] == 22
print('PASS a mid-rest enemy kill applies the faster tempo immediately')


# The actual drone collision path adjusts tempo once. A mine collision awards
# points but does not count as an enemy kill.
mm, cc = gameplay_with_enemy()
mm[0x300:0x307] = [80,80,0,0,0,1,0]
mm[0x600:0x60A] = [0xFF,0,80,0,80,0,0,0,0,0]
call(mm, cc, 'drone_collision7b')
assert mm[0x7B] == 22

mm, cc = gameplay_with_enemy()
for address in range(0x700, 0x740, 4):
    mm[address] = 0
mm[0x700:0x703] = [0xFF,80,80]
mm[0x600:0x60A] = [0xFF,0,80,0,80,0,0,0,0,0]
call(mm, cc, 'omega_mine_bullet_collision12')
assert mm[0x7B] == 24
print('PASS enemy destruction accelerates the music while mine destruction does not')


# Any live Shooting Star immediately replaces the normal loop with continuous
# six-frame G2/C3/G2/C2 notes.
mm, cc = gameplay_with_enemy(2)
alert = [triangle_frame(mm, cc) for _ in range(24)]
assert alert == [0x23A] * 6 + [0x1AB] * 6 + [0x23A] * 6 + [0x356] * 6
assert mm[0x7E] == 1 and all(note is not None for note in alert)
print('PASS Shooting Star alert loop has four continuous six-frame notes')


# One surviving Shooting Star keeps alert mode active. Once the last one is
# gone, normal mode restarts immediately at G2 and preserves earned tempo.
mm, cc = gameplay_with_enemy(2)
mm[0x315] = 1
mm[0x316] = 2
for _ in range(3):
    call(mm, cc, 'omega_triangle_kill16')
assert mm[0x7B] == 18
triangle_frame(mm, cc)
mm[0x306] = 0
assert triangle_frame(mm, cc) == 0x23A and mm[0x7E] == 1
mm[0x316] = 0
assert triangle_frame(mm, cc) == 0x23A and mm[0x7E] == 0
for _ in range(5):
    assert triangle_frame(mm, cc) == 0x23A
assert triangle_frame(mm, cc) is None and mm[0x67F] == 18
print('PASS final Shooting Star removal restores normal mode at the earned tempo')


# No enemies, death, spawn flashing, and wave clear all silence the channel.
for condition in ('empty', 'death', 'spawn', 'wave'):
    mm, cc = gameplay_with_enemy()
    assert triangle_frame(mm, cc) == 0x23A
    if condition == 'empty':
        mm[0x305] = 0
    elif condition == 'death':
        mm[0x677] = 1
    elif condition == 'spawn':
        mm[0x677] = 4
    else:
        mm[0xC7] = 1
    assert triangle_frame(mm, cc) is None
print('PASS triangle music mutes outside active enemy gameplay')


# A complete board setup restores the 24-frame opening rest and sequence state.
mm, cc = gameplay_with_enemy()
for _ in range(9):
    call(mm, cc, 'omega_triangle_kill16')
mm[0x7C] = 3
mm[0x7D] = mm[0x7E] = 1
mm[0x67F] = 5
call(mm, cc, 'omega_level_setup9')
assert mm[0x7B] == 24
assert mm[0x7C] == mm[0x7D] == mm[0x7E] == mm[0x67F] == 0
print('PASS each rebuilt board resets the adaptive triangle tempo and sequence')

print('PASS Omega Race Version 16 adaptive triangle-music regression suite')
