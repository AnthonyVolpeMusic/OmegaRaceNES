"""Machine-code regression tests for Omega Race Version 11B."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v11a.py').read_text()
text = text.replace('Version 11A.', 'Version 11B.', 1)
text = text.replace('omega_race_v11a.nes', 'omega_race_v11b.nes')
text = text.replace('symbols_omega_v11a.json', 'symbols_omega_v11b.json')
exec(compile(text, str(P / 'test_omega_v11a.py'), 'exec'))

# Both pursuit and route movement are exactly 1.5 pixels/frame at Level 1 and
# Level 9: two fixed 0.75-pixel cardinal steps per frame, independent of C4.
for level_index in (0, 8):
    mm, cc = boot()
    mm[0xC4] = level_index
    mm[0x300:0x305] = [32, 40, 0, 1, 0]
    mm[0xAB], mm[0xAC] = 220, 40
    cc.x = 0
    for _ in range(4):
        call(mm, cc, 'omega_star_step11')
        call(mm, cc, 'omega_star_step11')
    assert (mm[0x300], mm[0x301], mm[0x304]) == (38, 40, 0)

    mm[0x300:0x305] = [32, 40, 0, 1, 0]
    for i in range(8):
        mm[0x400+i], mm[0x500+i] = 220, 40
    cc.x = 0
    for _ in range(4):
        call(mm, cc, 'omega_star_route_step11b')
        call(mm, cc, 'omega_star_route_step11b')
    assert (mm[0x300], mm[0x301], mm[0x304]) == (38, 40, 0)
print('PASS Shooting Star pursuit and route travel are fixed at 1.5 px/frame on every level')

# A diagonal step uses $88 per axis. Over 128 half-steps this is exactly 68
# pixels in each axis: a 1.5026 px/frame resultant, the intended 1.5 target.
mm, cc = boot()
mm[0x300:0x305] = [32, 40, 0, 1, 0]
mm[0xAB], mm[0xAC] = 220, 220
cc.x = 0
for _ in range(128):
    call(mm, cc, 'omega_star_step11')
assert (mm[0x300], mm[0x301], mm[0x304]) == (100, 108, 0)
print('PASS Shooting Star diagonal movement remains normalized to the same 1.5 px/frame speed')
