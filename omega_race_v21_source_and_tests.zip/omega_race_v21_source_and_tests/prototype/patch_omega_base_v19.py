"""Omega Race V19: Game Over, score ranks, replay, and title colon repair."""

code = '\n'.join(lines)

# The startup Level 1 setup leaves a supers HUD update queued.  Its PPU
# address $21D3 is precisely the title screen's colon; this wrote a 3 there.
old = '''omega_hud_flush_v5a:
LDA $A7'''
new = '''omega_hud_flush_v5a:
LDA $06
BEQ omega_hud_ignore19
LDA $0677
CMP #$03
BEQ omega_hud_ignore19
JMP omega_hud_active19
omega_hud_ignore19:
LDA $A7
AND #$80
STA $A7
RTS
omega_hud_active19:
LDA $A7'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Route the existing two-second final-death continuation to the new screen.
old = '''omega_death_final_freeze13a:
LDA #$02
STA $0677'''
new = '''omega_death_final_freeze13a:
JSR omega_gameover_enter19'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''CMP #$03
BNE ordinary_controls23
JMP results_controls23'''
new = '''CMP #$03
BNE ordinary_controls23
JMP omega_gameover_controls19'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Don't allow a queued level-palette write to recolor Game Over.
old = '''omega_palette_game17a:
LDA $A7'''
new = '''omega_palette_game17a:
LDA $0677
CMP #$03
BEQ omega_palette_flush_done12b
LDA $A7'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

gameover = '''omega_gameover_enter19:
JSR audio_reset25a
JSR results_off23
LDA #$03
STA $0677
LDA #$00
STA $A7
JSR omega_screen_palette19
JSR omega_gameover_load19
JSR omega_gameover_score19
JSR omega_rank19
JSR omega_gameover_rank_write19
JSR render
LDA #$00
STA $2003
LDA #$02
STA $4014
JSR results_on23
RTS

omega_screen_palette19:
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDX #$00
omega_screen_palette_loop19:
LDA palette,X
STA $2007
INX
CPX #$20
BNE omega_screen_palette_loop19
RTS

omega_gameover_load19:
LDA #$20
STA $2006
LDA #$00
STA $2006
LDX #$00
omega_gameover_page019:
LDA omega_gameover_nt019,X
STA $2007
INX
BNE omega_gameover_page019
LDX #$00
omega_gameover_page119:
LDA omega_gameover_nt119,X
STA $2007
INX
BNE omega_gameover_page119
LDX #$00
omega_gameover_page219:
LDA omega_gameover_nt219,X
STA $2007
INX
BNE omega_gameover_page219
LDX #$00
omega_gameover_page319:
LDA omega_gameover_nt319,X
STA $2007
INX
BNE omega_gameover_page319
RTS

omega_gameover_score19:
LDA #$21
STA $2006
LDA #$2D
STA $2006
LDX #$00
omega_gameover_digit19:
LDA $33,X
CLC
ADC #$7B
STA $2007
INX
CPX #$06
BNE omega_gameover_digit19
RTS

omega_rank19:
LDA $9A
CMP #$05
BEQ omega_rank_five19
CMP #$07
BEQ omega_rank_seven19
LDA #$00
BEQ omega_rank_base19
omega_rank_five19:
LDA #$0D
BNE omega_rank_base19
omega_rank_seven19:
LDA #$1A
omega_rank_base19:
STA $6A
LDX #$0C
omega_rank_compare19:
TXA
CLC
ADC $6A
TAY
LDA $32
CMP omega_rank_hi19,Y
BCC omega_rank_lower19
BNE omega_rank_found19
LDA $31
CMP omega_rank_mid19,Y
BCC omega_rank_lower19
BNE omega_rank_found19
LDA $30
CMP omega_rank_lo19,Y
BCS omega_rank_found19
omega_rank_lower19:
DEX
BPL omega_rank_compare19
LDX #$00
omega_rank_found19:
TXA
RTS

omega_gameover_rank_write19:
STA $6B
ASL A
STA $6C
LDA $6B
ASL A
ASL A
ASL A
ASL A
CLC
ADC $6C
TAX
LDA #$21
STA $2006
LDA #$C7
STA $2006
LDY #$12
omega_rank_write_loop19:
LDA omega_rank_text19,X
STA $2007
INX
DEY
BNE omega_rank_write_loop19
RTS

omega_gameover_controls19:
LDA $02
EOR #$FF
AND $01
AND #$30
BEQ omega_gameover_controls_done19
AND #$10
BNE omega_gameover_replay19
JMP omega_gameover_title19
omega_gameover_controls_done19:
RTS

omega_gameover_replay19:
JSR audio_reset25a
JSR results_off23
LDA #$00
LDX #$00
omega_gameover_clear_pools19:
STA $0300,X
STA $0400,X
STA $0500,X
STA $0600,X
STA $0700,X
INX
BNE omega_gameover_clear_pools19
LDA #$00
STA $0677
STA $A7
STA $06
JSR omega_start_game17
LDA #$88
STA $2000
RTS

omega_gameover_title19:
JSR audio_reset25a
JSR results_off23
JSR omega_screen_palette19
JSR load_title
LDA #$00
STA $06
STA $0677
LDA #$80
STA $A7
JSR render
LDA #$00
STA $2003
LDA #$02
STA $4014
JSR results_on23
RTS
'''
assert code.count('omega_dispatch17:\n') == 1
code = code.replace('omega_dispatch17:\n', gameover + 'omega_dispatch17:\n', 1)
lines = [s.strip() for s in code.splitlines() if s.strip()]

def omega_glyph19(char):
    if char == ' ': return 0
    if char == ':': return 0x8A
    if char.isdigit(): return 0x7B + int(char)
    assert 'A' <= char <= 'Z', char
    return 0x61 + ord(char) - ord('A')

screen = [0] * 1024
def put_line(row, text):
    col = (32 - len(text)) // 2
    assert 0 <= col and col + len(text) <= 32
    screen[row * 32 + col:row * 32 + col + len(text)] = list(map(omega_glyph19, text))

put_line(4, 'GAME OVER')
put_line(7, 'FINAL SCORE:')
put_line(9, '000000')
put_line(12, 'YOUR RANK:')
put_line(19, 'PRESS START TO PLAY AGAIN')
put_line(23, 'PRESS SELECT TO GO')
put_line(24, 'TO THE MAIN SCREEN')
for i in range(4):
    data[f'omega_gameover_nt{i}19'] = screen[i * 256:(i + 1) * 256]

ranks = (
    (0, 'JANITOR'), (1000, 'CONCESSIONS CLERK'),
    (2000, 'HOT DOG VENDOR'), (3000, 'PIT CREW'),
    (4000, 'PACE CAR'), (6000, 'LEAD FOOT'),
    (8000, 'TOUGH CUSTOMER'), (10000, 'ROAD WARRIOR'),
    (12500, 'INTIMIDATOR'), (15000, 'FRONT ROW JOE'),
    (20000, 'ROCKET MAN'), (25000, 'IRON MAN'),
    (30000, 'OMEGA RACER'),
)
limits = [threshold * lives for lives in (3, 5, 7) for threshold, _ in ranks]
data['omega_rank_lo19'] = [value & 255 for value in limits]
data['omega_rank_mid19'] = [(value >> 8) & 255 for value in limits]
data['omega_rank_hi19'] = [(value >> 16) & 255 for value in limits]
data['omega_rank_text19'] = [
    omega_glyph19(c)
    for _, name in ranks
    for c in name.center(18)[:18]
]
