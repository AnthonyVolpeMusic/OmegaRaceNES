# Omega Race NES — Version 7A swarm setup

Baseline: Version 6 drone art, animation, track steering, arena, player physics,
projectiles, sound effects and event-driven HUD are retained.

- Player One starts in the upper-right at ($E0,$18), facing west (heading $24).
- Seven basic drones begin at distinct, scattered positions in the southwest.
- Each drone receives its own eight-node racing line within the shared track
  corridor. The seven routes drift gradually inward and outward, so the ships
  no longer move on one identical invisible rail.
- Inner and outer route deviations extend to approximately 15 pixels from the
  master centerline, providing eight additional pixels of visible separation.
- Each drone independently acquires the nearest node on its personal route and
  then follows that route clockwise.
- Drone speed is half Version 6: 64/256 pixel per frame on straight sections;
  diagonal axes use 45/256 to maintain approximately uniform total speed.
- Drone artwork still loops frames 1-2-3-4, holding each for six frames.
- Drones remain harmless in 7A: no ship/projectile collision, destruction,
  score award or lives interaction. Those systems are reserved for 7B.

Build: `python3 prototype/build_omega_base_v7a.py`

Test: `python3 prototype/test_omega_v7a.py`

Dependencies: Python 3, Pillow and py65.

RAM $0300-$036F contains seven 16-byte drone records. The master centerline
remains at $0380-$038F; 56 personal route X coordinates occupy $0400-$0437 and
their Y coordinates occupy $0440-$0477. The seven drone OAM entries occupy
$0214-$022F.
