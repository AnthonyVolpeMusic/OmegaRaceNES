"""Machine-code regression tests for Omega Race Version 11A."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v11.py').read_text()
text = text.replace('Version 11.', 'Version 11A.', 1)
text = text.replace('omega_race_v11.nes', 'omega_race_v11a.nes')
text = text.replace('symbols_omega_v11.json', 'symbols_omega_v11a.json')

old = """frames = [
 ['00021000','00021000','00121100','00122222','22222110','01112110','11112111','11112111'],
 ['00211000','00211000','00121122','00122200','01222110','22112110','11111211','11111211'],
 ['00011000','02011020','00211200','00122100','01122110','01211210','12111121','11111111'],
]
frames.append([row[::-1] for row in frames[1]])"""
new = """frames = [
 ['20032001','00011000','00111100','00211300','03111120','01122110','11111111','12311231'],
 ['30013003','00012000','00211100','00311100','01111130','01122120','21111111','23112311'],
 ['10011002','00023000','00311200','00111100','01111110','02122130','31111112','31123112'],
 ['20021003','00031000','00111300','00111200','02111110','03122110','11111113','11231123'],
]"""
assert text.count(old) == 1
text = text.replace(old, new, 1)
exec(compile(text, str(P / 'test_omega_v11.py'), 'exec'))
