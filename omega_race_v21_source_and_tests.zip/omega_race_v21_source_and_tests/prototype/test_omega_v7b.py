"""Machine-code regression tests for Omega Race Version 7B."""
from pathlib import Path

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]


def harness(rom, symbols):
    text = base.replace('omega_race_player_base_v2_palette_test.nes', rom)
    text = text.replace('symbols_omega_base_v1.json', symbols)
    text = text.replace('range(400000)', 'range(600000)')
    env = {'__file__': str(P / 'test_omega_v7b.py')}
    exec(compile(text, 'harness', 'exec'), env)
    return env


new = harness('omega_race_v7b.nes', 'symbols_omega_v7b.json')
old = harness('omega_race_v7a.nes', 'symbols_omega_v7a.json')
boot, call = new['boot'], new['call']

mm, cc = boot()
assert all(mm[a + 5] == 1 for a in range(0x300, 0x370, 16))
assert mm[0x33:0x39] == [0] * 6 and mm[0xA7] == 0
print('PASS seven drones begin active; score HUD begins clean')

# A direct projectile hit destroys exactly one drone, converts that projectile
# into the existing stationary impact animation, and awards exactly 1000.
dx, dy = mm[0x300], mm[0x301]
mm[0x600] = 0xFF
mm[0x602], mm[0x604] = dx + 2, dy + 2
mm[0x605:0x609] = [1, 2, 3, 4]
mm[0x609] = 0
call(mm, cc, 'drone_collision7b')
assert mm[0x305] == 0
assert sum(mm[a + 5] for a in range(0x300, 0x370, 16)) == 6
assert mm[0x600] == 0x0F and mm[0x609] == 1
assert (mm[0x602], mm[0x604]) == (dx, dy)
assert mm[0x605:0x609] == [0, 0, 0, 0]
assert mm[0x30:0x33] == [0xE8, 0x03, 0x00]
assert mm[0x33:0x39] == [0, 0, 1, 0, 0, 0]
assert mm[0xA7] & 1
print('PASS projectile hit: one drone, reused impact state, exactly 1000 points')

# Rendering hides the destroyed drone and displays the explosion in the same
# projectile OAM slot used by a wall impact.
call(mm, cc, 'render')
assert mm[0x214] == 0xF8
assert mm[0x204] == dy - 1 and mm[0x207] == dx
assert mm[0x205] != 0x11
print('PASS destroyed drone hidden and existing impact animation rendered')

# The score's six nametable tiles are written once when the dirty event flushes.
mm.ppu = []
call(mm, cc, 'omega_hud_flush_v5a')
assert mm.ppu == [0x7B, 0x7B, 0x7C, 0x7B, 0x7B, 0x7B]
assert mm[0xA7] == 0
mm.ppu = []
call(mm, cc, 'omega_hud_flush_v5a')
assert mm.ppu == []
print('PASS score tiles update once on destruction, not on ordinary frames')

# Exact AABB edge misses must not destroy or score. Disable the other six so
# the deliberately missed projectile cannot overlap a neighboring drone.
for miss_x, miss_y in ((dx - 4, dy), (dx + 8, dy), (dx, dy - 4), (dx, dy + 8)):
    mm, cc = boot()
    for a in range(0x310, 0x370, 16):
        mm[a + 5] = 0
    mm[0x600], mm[0x609] = 0xFF, 0
    mm[0x602], mm[0x604] = miss_x, miss_y
    call(mm, cc, 'drone_collision7b')
    assert mm[0x305] == 1 and mm[0x33:0x39] == [0] * 6
print('PASS projectile/drone collision boundaries reject adjacent misses')

# One projectile can score only one target, even if two live drones overlap.
mm, cc = boot()
mm[0x310], mm[0x311] = mm[0x300], mm[0x301]
mm[0x600], mm[0x609] = 0xFF, 0
mm[0x602], mm[0x604] = mm[0x300], mm[0x301]
call(mm, cc, 'drone_collision7b')
assert mm[0x305] + mm[0x315] == 1
assert mm[0x33:0x39] == [0, 0, 1, 0, 0, 0]
print('PASS one projectile cannot double-score overlapping drones')

# Destroy the whole seven-drone test wave and verify 7 x 1000 exactly.
mm, cc = boot()
for a in range(0x300, 0x370, 16):
    mm[0x600], mm[0x609] = 0xFF, 0
    mm[0x602], mm[0x604] = mm[a], mm[a + 1]
    call(mm, cc, 'drone_collision7b')
assert all(mm[a + 5] == 0 for a in range(0x300, 0x370, 16))
assert mm[0x30:0x33] == [0x58, 0x1B, 0x00]
assert mm[0x33:0x39] == [0, 0, 7, 0, 0, 0]
before = [(mm[a], mm[a + 1]) for a in range(0x300, 0x370, 16)]
for _ in range(600):
    call(mm, cc, 'drone_tick6')
after = [(mm[a], mm[a + 1]) for a in range(0x300, 0x370, 16)]
assert after == before
print('PASS seven kills total 7000; destroyed drones remain inactive')

# V7A arena, CHR artwork, routes, player state and sound data stay unchanged.
om, oc = old['boot']()
nm, nc = boot()
assert new['CHR'] == old['CHR'] and nm.ppu == om.ppu
assert nm[0x11] == om[0x11] == 0xE0 and nm[0x13] == om[0x13] == 0x18
assert nm[0x03] == om[0x03] == 0x24
assert nm[0x380:0x390] == om[0x380:0x390]
assert nm[0x400:0x478] == om[0x400:0x478]
print('PASS Version 7A graphics, routes, player setup and playfield retained')

# Real main/NMI execution remains inside the frame budget with all drones live.
mm, cc = boot()
mm.ppu = []
mm.pad = 0
cc.pc = new['S']['main']
cc.sp = 255
deadline = cc.processorCycles
for frame in range(180):
    end = deadline + 29781
    while cc.processorCycles < end:
        if cc.processorCycles >= deadline:
            cc.nmi()
            deadline += 29781
        cc.step()
assert not mm.ppu and 178 <= mm.dmas <= 180
assert sum(mm[a + 5] for a in range(0x300, 0x370, 16)) == 7
print('PASS real main/NMI execution with collision checks and no false hits')
