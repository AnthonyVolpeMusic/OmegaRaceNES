"""Machine-code and source-hook regression tests for Omega Race Version 14."""
import json
from pathlib import Path

from py65.devices.mpu6502 import MPU

P = Path(__file__).parent
S = json.loads((P / "symbols_omega_v14.json").read_text())
IMAGE = (P / "omega_race_v14.nes").read_bytes()
ROM = IMAGE[16:32784]
ASM = (P / "prototype_omega_v14.asm").read_text()


class Memory(list):
    def __init__(self):
        super().__init__([0] * 65536)
        self.ppu = []
        self.dmas = 0
        self.pad = 0
        self.index = 0

    def __getitem__(self, key):
        if key == 0x2002:
            return 0x80
        if key == 0x4016:
            value = (self.pad >> (7 - self.index)) & 1 if self.index < 8 else 1
            self.index += 1
            return value
        return super().__getitem__(key)

    def __setitem__(self, key, value):
        if key == 0x4016:
            self.index = 0
        if key == 0x2007:
            self.ppu.append(value)
        if key == 0x4014:
            self.dmas += 1
        super().__setitem__(key, value)


def boot():
    mm = Memory()
    mm[0x8000:] = ROM
    cc = MPU(memory=mm, pc=S["reset"])
    for _ in range(900000):
        cc.step()
        if cc.pc == S["main"]:
            return mm, cc
    raise AssertionError("boot timeout")


def call(mm, cc, name, a=None, x=None, y=None):
    if a is not None:
        cc.a = a
    if x is not None:
        cc.x = x
    if y is not None:
        cc.y = y
    cc.pc = S[name]
    cc.sp = 255
    cc.stPushWord(0x7FFE)
    for _ in range(300000):
        cc.step()
        if cc.pc == 0x7FFF:
            return
    raise AssertionError(name + " timeout")


def pulse_frames(effect):
    mm, cc = boot()
    call(mm, cc, "omega_pulse1_start14", a=effect)
    frames = [(mm[0x4000] & 15, mm[0x4002] | ((mm[0x4003] & 7) << 8))]
    while mm[0x82]:
        call(mm, cc, "omega_pulse1_tick14")
        if mm[0x82]:
            frames.append((mm[0x4000] & 15,
                           mm[0x4002] | ((mm[0x4003] & 7) << 8)))
    return mm, cc, frames


fade12 = [15, 14, 12, 11, 10, 8, 7, 5, 4, 3, 1, 0]
fade10 = [15, 13, 12, 10, 8, 7, 5, 3, 2, 0]

mm, cc, frames = pulse_frames(1)
assert len(frames) == 12
assert [v for v, _ in frames] == fade12
assert [p for _, p in frames] == [
    0x0BD, 0x0CE, 0x0E0, 0x0F1, 0x102, 0x114,
    0x125, 0x137, 0x148, 0x159, 0x16B, 0x17C,
]
print("PASS Player One fire slides D5 to D4 and fades over 12 frames")

mm, cc, frames = pulse_frames(2)
assert len(frames) == 12 and [v for v, _ in frames] == fade12
assert frames[0][1] == 0x08E and frames[-1][1] == 0x23A
assert all(frames[n][1] <= frames[n + 1][1] for n in range(11))
print("PASS Commander/Shooting Star fire slides G5 to G3 over 12 frames")

for effect, first, second, label in (
    (3, 0x389, 0x474, "drone B2/G2"),
    (4, 0x0D5, 0x1AB, "Commander C5/C4"),
    (5, 0x0D5, 0x07E, "Shooting Star C5/A5"),
    (6, 0x356, 0x389, "wall bounce C3/B2"),
):
    mm, cc, frames = pulse_frames(effect)
    assert len(frames) == 16
    assert [v for v, _ in frames] == list(range(15, -1, -1))
    assert [p for _, p in frames] == [first, first, second, second] * 4
    print(f"PASS {label} alternates every two frames and fades for 16 frames")

mm, cc, frames = pulse_frames(7)
assert len(frames) == 9
assert [v for v, _ in frames] == [15] * 9
assert [p for _, p in frames] == [0x356] * 3 + [0x280] * 3 + [0x6AD] * 3
print("PASS mine destruction plays C3, F3 and C2 for three frames each")

mm, cc, frames = pulse_frames(8)
assert len(frames) == 10 and [v for v, _ in frames] == fade10
assert frames[0][1] == 0x23A and frames[-1][1] == 0x1AB
assert all(frames[n][1] >= frames[n + 1][1] for n in range(9))
print("PASS projectile wall impact slides G3 to C4 over 10 frames")

mm, cc, frames = pulse_frames(9)
assert len(frames) == 36
assert [v for v, _ in frames] == ([15] * 6 + [0] * 6) * 3
assert {p for _, p in frames} == {0x23A}
print("PASS extra life plays three six-frame G3 beeps with six-frame gaps")

# A lower-priority fire sound cannot cut off a destruction sound. An equal
# destruction priority may replace it, and the extra-life cue overrides both.
mm, cc = boot()
call(mm, cc, "omega_pulse1_start14", a=3)
state = (mm[0xD2], mm[0xD3], mm[0x82], mm[0x83])
call(mm, cc, "omega_pulse1_start14", a=1)
assert (mm[0xD2], mm[0xD3], mm[0x82], mm[0x83]) == state
call(mm, cc, "omega_pulse1_start14", a=5)
assert mm[0xD2] == 5 and mm[0xD3] == 4
call(mm, cc, "omega_pulse1_start14", a=9)
assert mm[0xD2] == 9 and mm[0xD3] == 5
print("PASS Pulse 1 priority prevents routine shots from masking key cues")

# Player death owns the APU for 76 frames: two #12 noise bursts separated by
# silence, then sixty frames of #11 noise that reaches silence at the end.
mm, cc = boot()
call(mm, cc, "pulse2_start26", a=7)
call(mm, cc, "omega_pulse1_start14", a=3)
call(mm, cc, "omega_death_sfx_start14")
death = [(mm[0x4015], mm[0x400C] & 15, mm[0x400E] & 15)]
while mm[0x84]:
    call(mm, cc, "omega_death_noise_tick14")
    if mm[0x84]:
        death.append((mm[0x4015], mm[0x400C] & 15, mm[0x400E] & 15))
assert len(death) == 76
assert mm[0x82] == mm[0x87] == mm[0xD6] == 0 and mm[0x4015] == 0
assert all(enable == 8 for enable, _, _ in death)
assert [v for _, v, _ in death[:16]] == [15] * 4 + [0] * 4 + [15] * 4 + [0] * 4
assert all(period == 12 for _, v, period in death[:16] if v)
assert all(period == 11 for _, _, period in death[16:])
assert death[16][1] == 15 and death[-1][1] == 0
print("PASS Player One death silences other channels and follows the 76-frame noise script")

# Preserve the existing special cues on Pulse 2 and the inherited noise/thrust
# channel; the new event hooks all appear exactly where their gameplay events
# occur in the assembled source.
mm, cc = boot()
call(mm, cc, "pulse2_start26", a=7)
assert mm[0x8B] == 7 and mm[0x87]
call(mm, cc, "pulse2_start26", a=9)
assert mm[0x8B] == 9 and mm[0x87]
required_hooks = (
    "commander_spawn_shot8:\nLDX $B1", "LDA #$02\nJSR omega_pulse1_start14\ncommander_fire_done8:",
    "omega_enemy_sfx_start14:\nJSR omega_pulse1_start14", "LDA #$07\nJSR omega_pulse1_start14\nLDA #$FA",
    "omega_shot_explode_v4:\nLDA #$08", "JSR omega_halve_ship_speed_v4\nLDA #$06",
    "score_extra_life10:\nLDA #$09", "JSR death_burst_start22\nJSR omega_death_sfx_start14",
)
assert all(hook in ASM for hook in required_hooks)
print("PASS all gameplay hooks are present; shield, stop-super and thrust engines remain intact")

# Integration spot checks for three collision paths and the death hook.
mm, cc = boot()
for address in range(0x300, 0x400, 0x10):
    mm[address + 5] = 0
mm[0x600:0x60A] = [0xFF, 0, 80, 0, 80, 0, 0, 0, 0, 0]
mm[0x300:0x307] = [80, 80, 0, 0, 0, 1, 0]
call(mm, cc, "drone_collision7b")
assert mm[0xD2] == 3 and mm[0x305] == 0 and mm[0x609] == 1

mm, cc = boot()
for address in range(0x700, 0x740, 4):
    mm[address] = 0
mm[0x600:0x60A] = [0xFF, 0, 80, 0, 80, 0, 0, 0, 0, 0]
mm[0x700:0x703] = [0xFF, 80, 80]
call(mm, cc, "omega_mine_bullet_collision12")
assert mm[0xD2] == 7 and mm[0x700] == 0 and mm[0x609] == 1

mm, cc = boot()
mm[0x600] = 0xFF
call(mm, cc, "omega_shot_explode_v4", x=0)
assert mm[0xD2] == 8 and mm[0x609] == 1

mm, cc = boot()
mm[0x677] = 0
call(mm, cc, "omega_player_kill9")
assert mm[0x677] == 1 and mm[0xD6] == 1 and mm[0x4015] == 8
print("PASS collision and death events start their assigned effects in machine code")

print("PASS Omega Race Version 14 sound-effects regression suite")
