"""Build Omega Race Version 19 from its full reproducible source chain."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v18.py').read_text()

base_v18 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v18.py').read_text(),str(P/'patch_omega_base_v18.py'),'exec'))\\n" + marker)'''
base_v19 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v19.py').read_text(),str(P/'patch_omega_base_v19.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v18) == 1
recipe = recipe.replace(base_v18, base_v18 + '\n' + base_v19, 1)
recipe = recipe.replace('omega_race_v18.nes', 'omega_race_v19.nes')
recipe = recipe.replace('symbols_omega_v18.json', 'symbols_omega_v19.json')
recipe = recipe.replace('prototype_omega_v18.asm', 'prototype_omega_v19.asm')
exec(compile(recipe, str(P / 'build_omega_base_v18.py'), 'exec'))
