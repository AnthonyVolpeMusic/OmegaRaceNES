"""Regression and V3-specific tests for the bordered Omega Race arena."""
from pathlib import Path

P = Path(__file__).parent
source = (P / 'test_omega_base_v1.py').read_text()
source = source.replace('omega_race_player_base_v2_palette_test.nes',
                        'omega_race_v3_bordered_arena_test.nes')
source = source.replace('symbols_omega_base_v1.json', 'symbols_omega_v3.json')
source = source.replace('for _ in range(400000):', 'for _ in range(600000):')
source = source.replace('m[0x11]==128 and m[0x13]==120',
                        'm[0x11]==224 and m[0x13]==24')
source = source.replace('m.ppu[-32:]', 'm.ppu[4096:4128]')
source = source.replace('m[0x13]=16;m[0x16]=0;m[0x17]=0xff',
                        'm[0x13]=12;m[0x16]=0;m[0x17]=0xff')
source = source.replace('m[0x11]==128 and m[0x13]==120',
                        'm[0x11]==224 and m[0x13]==24')
exec(compile(source, str(P / 'test_omega_base_v1.py'), 'exec'))

# The static nametable follows the initial 4 KiB clear and 32 palette writes.
nm,nc = boot()
nt = nm.ppu[4128:5152]
assert len(nt) == 1024
assert nt[1*32+0] == 0x90 and nt[1*32+31] == 0x93
assert nt[28*32+0] == 0x97 and nt[28*32+31] == 0x95
assert all(nt[1*32+x] == 0x91 for x in range(1,31))
assert all(nt[28*32+x] == 0x96 for x in range(1,31))
assert nt[11*32+10] == 0x90 and nt[11*32+21] == 0x93
assert nt[18*32+10] == 0x97 and nt[18*32+21] == 0x95
assert not any(nt[960:1024])
print('PASS 32x28 outer border and centered 12x8 middle box nametable')

# The inherited V35 starfield formerly occupied $90-$99.  Verify every final
# border tile contains the approved full pattern rather than a one-pixel star.
border_rows = [
    ['33221122','30000000','20000000','20000000','10000000','10000000','20000000','20000000'],
    ['33221122','00000000','00000000','00000000','00000000','00000000','00000000','00000000'],
    ['30000000','30000000','20000000','20000000','10000000','10000000','20000000','20000000'],
    ['33221122','00000003','00000003','00000002','00000002','00000001','00000001','00000002'],
    ['00000002','00000003','00000003','00000002','00000002','00000001','00000001','00000002'],
    ['00000002','00000003','00000003','00000002','00000002','00000001','00000001','23322112'],
    ['00000000','00000000','00000000','00000000','00000000','00000000','00000000','23322112'],
    ['30000000','30000000','20000000','20000000','10000000','10000000','20000000','23322112'],
]
def bg_chr_pixel(tile_number,x,y):
    base=tile_number*16
    return ((CHR[base+y]>>(7-x))&1) | (((CHR[base+8+y]>>(7-x))&1)<<1)
for tile_number,rows in enumerate(border_rows,0x90):
    assert [[bg_chr_pixel(tile_number,x,y) for x in range(8)] for y in range(8)] == \
           [[int(c) for c in row] for row in rows]
print('PASS approved $90-$97 border CHR survives inherited starfield generation')

# Player reflects from all four faces of the solid middle box.
for x,y,vx,vy,expect_x,expect_y,x_negative,y_negative in (
    (71,100,1,0,72,100,True,False),
    (177,100,0xff,0,176,100,False,False),
    (100,79,0,1,100,80,False,True),
    (100,153,0,0xff,100,152,False,False),
):
    mm,cc=boot();mm[0x11]=x;mm[0x13]=y;mm[0x14]=0;mm[0x15]=vx
    mm[0x16]=0;mm[0x17]=vy;call(mm,cc,'physics')
    assert (mm[0x11],mm[0x13])==(expect_x,expect_y), \
        ('ship',x,y,vx,vy,mm[0x11],mm[0x13],mm[0x15],mm[0x17])
    assert bool(mm[0x15]&0x80)==x_negative, \
        ('ship vx',x,y,vx,vy,mm[0x15])
    assert bool(mm[0x17]&0x80)==y_negative, \
        ('ship vy',x,y,vx,vy,mm[0x17])
print('PASS Player One reflects from all four middle-box faces')

# A live projectile uses the corresponding four-pixel collision envelope.
for x,y,vx,vy,expect_x,expect_y,x_negative,y_negative in (
    (75,100,1,0,76,100,True,False),
    (177,100,0xff,0,176,100,False,False),
    (100,83,0,1,100,84,False,True),
    (100,153,0,0xff,100,152,False,False),
):
    mm,cc=boot();mm[0x600]=48;mm[0x602]=x;mm[0x604]=y
    mm[0x605]=0;mm[0x606]=vx;mm[0x607]=0
    mm[0x608]=vy;mm[0x609]=0;call(mm,cc,'bullets')
    assert (mm[0x602],mm[0x604])==(expect_x,expect_y), \
        ('shot',x,y,vx,vy,mm[0x602],mm[0x604],mm[0x606],mm[0x608])
    assert bool(mm[0x606]&0x80)==x_negative, \
        ('shot vx',x,y,vx,vy,mm[0x606])
    assert bool(mm[0x608]&0x80)==y_negative, \
        ('shot vy',x,y,vx,vy,mm[0x608])
print('PASS projectiles reflect from all four middle-box faces')

# Only Player One's top origin is four pixels closer to the border.  The
# collision must clamp at $0C and reverse upward velocity there.
mm,cc=boot();mm[0x13]=12;mm[0x16]=0;mm[0x17]=0xff
call(mm,cc,'physics')
assert mm[0x13]==12 and not (mm[0x17]&0x80)
print('PASS Player One top-wall rebound is four pixels closer to the border')
