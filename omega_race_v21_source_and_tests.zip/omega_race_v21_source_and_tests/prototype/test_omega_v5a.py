"""Full V4B regression suite plus V5A event-driven HUD checks."""
from pathlib import Path

P = Path(__file__).parent
source = (P / 'test_omega_v4b.py').read_text()
source = source.replace('omega_race_v4b_speed_test.nes',
                        'omega_race_v5a_event_hud_test.nes')
source = source.replace('symbols_omega_v4b.json', 'symbols_omega_v5a.json')
exec(compile(source, str(P / 'test_omega_v4b.py'), 'exec'))

def glyphs(text):
    result=[]
    for ch in text:
        if ch==' ': result.append(0)
        elif ch==':': result.append(0x8a)
        elif '0'<=ch<='9': result.append(0x7b+ord(ch)-ord('0'))
        else: result.append(0x61+ord(ch)-ord('A'))
    return result

def one_nmi(mm,cc):
    mm.ppu=[];mm[0]=1;mm[0xa2]=0;cc.pc=0x7fff;cc.sp=255;cc.nmi()
    for _ in range(20000):
        cc.step()
        if cc.pc==0x7fff:return
    raise AssertionError('NMI timeout')

# Initial display is entirely static and still has the exact centered layout.
mm,cc=boot();nt=mm.ppu[4128:5152]
assert nt[12*32+10:12*32+22]==glyphs('SCORE:000000')
assert nt[14*32+10:14*32+22]==glyphs('  SUPERS:5  ')
assert nt[16*32+10:16*32+22]==glyphs('LIVES LEFT:3')
one_nmi(mm,cc);assert mm.ppu==[] and mm[0xa7]==0
print('PASS static initial HUD and zero ordinary-frame nametable writes')

# Using either current super marks only the supers digit dirty.  The next NMI
# writes one glyph and clears the request; the following NMI writes nothing.
for pad in (0x40,0x44):
    mm,cc=boot();mm[1]=pad;mm[2]=0;call(mm,cc,'game_controls')
    assert mm[7]==4 and mm[0xa7]==2
    one_nmi(mm,cc);assert mm.ppu==[0x7f] and mm[0xa7]==0
    one_nmi(mm,cc);assert mm.ppu==[]
print('PASS super consumption performs one event-driven digit update')

# Future score and lives hooks update only their own fields.
mm,cc=boot();mm[0x33:0x39]=[1,2,3,4,5,6]
call(mm,cc,'omega_hud_request_score_v5a');assert mm[0xa7]==1
one_nmi(mm,cc);assert mm.ppu==[0x7c,0x7d,0x7e,0x7f,0x80,0x81]
mm[0x3d]=2;call(mm,cc,'omega_hud_request_lives_v5a');assert mm[0xa7]==4
one_nmi(mm,cc);assert mm.ppu==[0x7d]
print('PASS dormant score and lives event hooks update only requested values')

# Simultaneous requests coalesce into one ordered eight-glyph vblank update.
mm[0x07]=3;call(mm,cc,'omega_hud_request_score_v5a')
call(mm,cc,'omega_hud_request_supers_v5a')
call(mm,cc,'omega_hud_request_lives_v5a');assert mm[0xa7]==7
one_nmi(mm,cc)
assert mm.ppu==[0x7c,0x7d,0x7e,0x7f,0x80,0x81,0x7e,0x7d]
assert mm[0xa7]==0
print('PASS simultaneous HUD events coalesce safely into one vblank')
