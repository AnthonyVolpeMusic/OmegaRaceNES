"""Omega Race V5: live score, supers, and lives display in the middle box."""
from pathlib import Path

P = Path(__file__).parent
exec(compile((P / 'build_omega_base_v1.py').read_text(),
             str(P / 'build_omega_base_v1.py'), 'exec'))

marker = 'asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker) == 1
source = source.replace(
    marker,
    "exec(compile((P/'patch_omega_base_v3.py').read_text(),"
    "str(P/'patch_omega_base_v3.py'),'exec'))\n"
    "exec(compile((P/'patch_omega_base_v4.py').read_text(),"
    "str(P/'patch_omega_base_v4.py'),'exec'))\n"
    "exec(compile((P/'patch_omega_base_v4a.py').read_text(),"
    "str(P/'patch_omega_base_v4a.py'),'exec'))\n"
    "exec(compile((P/'patch_omega_base_v4b.py').read_text(),"
    "str(P/'patch_omega_base_v4b.py'),'exec'))\n"
    "exec(compile((P/'patch_omega_base_v5.py').read_text(),"
    "str(P/'patch_omega_base_v5.py'),'exec'))\n" + marker)

output_marker = "output=P/'omega_race_player_base_v2_palette_test.nes'"
assert source.count(output_marker) == 1
source = source.replace(
    output_marker,
    "exec(compile((P/'patch_omega_chr_v3.py').read_text(),"
    "str(P/'patch_omega_chr_v3.py'),'exec'))\n" + output_marker)
source = source.replace(output_marker,
                        "output=P/'omega_race_v5_center_hud_test.nes'")
source = source.replace('symbols_omega_base_v1.json', 'symbols_omega_v5.json')
source = source.replace('prototype_omega_base_v1.asm', 'prototype_omega_v5.asm')
exec(compile(source, str(P / 'build_v15.py'), 'exec'))
