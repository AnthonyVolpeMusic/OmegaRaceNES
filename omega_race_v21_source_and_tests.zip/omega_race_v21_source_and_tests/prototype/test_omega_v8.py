"""Machine-code regression tests for Omega Race Version 8."""
from pathlib import Path

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
text = base.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v8.nes')
text = text.replace('symbols_omega_base_v1.json', 'symbols_omega_v8.json')
text = text.replace('range(400000)', 'range(700000)')
env = {'__file__': str(P / 'test_omega_v8.py')}
exec(compile(text, 'harness', 'exec'), env)
boot, call, CHR, S = env['boot'], env['call'], env['CHR'], env['S']


def chr_pixel(tile, x, y):
    base = (0x100 + tile) * 16
    return ((CHR[base + y] >> (7-x)) & 1) | (((CHR[base + 8 + y] >> (7-x)) & 1) << 1)


frames = [
 ['00112300','03111110','21133111','11133112','11333313','31333311','02111110','00113200'],
 ['00311200','02111130','11122111','11122111','31222212','21222213','01111110','00132100'],
 ['00231100','01111120','11122113','31122111','21222211','11222212','01111130','00321100'],
 ['00123100','01111110','31133112','21133113','11333311','11333311','03111120','00211300'],
]
for f, rows in enumerate(frames):
    for y, row in enumerate(rows):
        for x, value in enumerate(row):
            assert chr_pixel(0xE4 + f, x, y) == int(value)
print('PASS all 256 Commander pixels match the supplied four frames')

mm, cc = boot()
assert [mm[a + 6] for a in range(0x300, 0x370, 16)] == [1, 0, 0, 0, 0, 0, 0]
assert all(mm[a + 5] == 1 and mm[a + 7] == 120 for a in range(0x300, 0x370, 16))
assert not any(mm[0x480:0x4C0])
call(mm, cc, 'render')
assert mm[0x215] == 0xE4 and all(mm[a] == 0xE0 for a in range(0x219, 0x230, 4))
print('PASS Level 1 starts with one Commander, six drones, and an empty four-shot pool')

# Cardinal fractional movement is exactly 2x before either accumulator wraps.
mm, cc = boot()
for a, kind in ((0x300, 1), (0x310, 0)):
    mm[a + 6] = kind
    mm[a + 2] = 0
    mm[a + 4] = 0
    route = 0x400 + ((a - 0x300) // 2)
    mm[a] = (mm[route] - 8) & 0xFF
    mm[a + 1] = mm[route + 0x40]
cc.x = 0
call(mm, cc, 'drone_move6')
cc.x = 0x10
call(mm, cc, 'drone_move6')
assert mm[0x304] == 0x80 and mm[0x314] == 0x40
print('PASS Commander movement rate is exactly twice the drone rate')

# A clear upper lane fires; the middle box rejects a diagonal crossing.
mm, cc = boot()
mm[0x300:0x308] = [32, 40, 0, 1, 0, 1, 1, 1]
mm[0x11], mm[0x13] = 220, 40
cc.x = 0
call(mm, cc, 'commander_try_fire8')
assert sum(mm[a] != 0 for a in range(0x480, 0x4C0, 16)) == 1

mm, cc = boot()
mm[0x300:0x308] = [32, 176, 0, 1, 0, 1, 1, 1]
mm[0x11], mm[0x13] = 220, 24
cc.x = 0
call(mm, cc, 'commander_try_fire8')
assert not any(mm[a] for a in range(0x480, 0x4C0, 16))
print('PASS Commander fires on a clear ray and withholds fire through the middle box')

# Timer expires on the 120th tick, and all four live entries enforce the cap.
mm, cc = boot()
mm[0x300], mm[0x301], mm[0x307] = 32, 40, 120
mm[0x11], mm[0x13] = 220, 40
for i in range(8):
    mm[0x400 + i], mm[0x440 + i] = 32, 40
for _ in range(119):
    call(mm, cc, 'drone_tick6')
assert not any(mm[a] for a in range(0x480, 0x4C0, 16))
call(mm, cc, 'drone_tick6')
assert sum(mm[a] != 0 for a in range(0x480, 0x4C0, 16)) == 1
for a in range(0x480, 0x4C0, 16):
    mm[a] = 0xFF
mm[0x307] = 1
call(mm, cc, 'drone_tick6')
assert sum(mm[a] != 0 for a in range(0x480, 0x4C0, 16)) == 4
print('PASS two-second cadence is 120 frames and shared enemy-shot cap is four')

# Commander scores 1500 and immediately promotes one of six surviving drones.
mm, cc = boot()
dx, dy = mm[0x300], mm[0x301]
mm[0x600], mm[0x602], mm[0x604], mm[0x609] = 0xFF, dx, dy, 0
call(mm, cc, 'drone_collision7b')
assert mm[0x305] == 0
assert mm[0x30:0x33] == [0xDC, 0x05, 0x00]
assert mm[0x33:0x39] == [0, 0, 1, 5, 0, 0]
commanders = [a for a in range(0x300, 0x370, 16) if mm[a + 5] and mm[a + 6] == 1]
assert len(commanders) == 1 and mm[commanders[0] + 7] == 120
print('PASS Commander awards 1500 and immediately promotes one surviving drone')

# A normal drone remains 1000 points and does not add another Commander.
target = next(a for a in range(0x300, 0x370, 16) if mm[a + 5] and mm[a + 6] == 0)
mm[0x610], mm[0x612], mm[0x614], mm[0x619] = 0xFF, mm[target], mm[target + 1], 0
call(mm, cc, 'drone_collision7b')
assert mm[0x30:0x33] == [0xC4, 0x09, 0x00]
assert sum(mm[a + 5] and mm[a + 6] == 1 for a in range(0x300, 0x370, 16)) == 1
print('PASS ordinary drone still awards 1000 with no promotion')

# Enemy shots explode on outer and middle walls, and never alter P1 lives.
for x, y, vx, vy in ((247, 40, 1, 0), (68, 75, 0, 1)):
    mm, cc = boot()
    lives = mm[0x3D]
    mm[0x480:0x48A] = [0xFF, 0, x, 0, y, 0, vx, 0, vy, 0]
    call(mm, cc, 'enemy_shots_tick8')
    assert mm[0x480] == 0x0F and mm[0x489] == 1 and mm[0x3D] == lives
print('PASS enemy shots reuse wall explosions and cannot damage Player One')

# Real main/NMI execution remains stable across multiple firing opportunities.
mm, cc = boot()
mm.ppu = []
mm.pad = 0
cc.pc = S['main']
cc.sp = 255
deadline = cc.processorCycles
for _ in range(300):
    end = deadline + 29781
    while cc.processorCycles < end:
        if cc.processorCycles >= deadline:
            cc.nmi()
            deadline += 29781
        cc.step()
assert not mm.ppu and 298 <= mm.dmas <= 300
assert mm[0x3D] == 3
assert sum(mm[a] != 0 for a in range(0x480, 0x4C0, 16)) <= 4
print('PASS five seconds of real main/NMI execution remain within frame budget')
