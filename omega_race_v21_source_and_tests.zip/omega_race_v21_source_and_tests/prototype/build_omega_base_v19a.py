"""Build Omega Race Version 19A on top of confirmed Version 19."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v19.py').read_text()

base_v19 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v19.py').read_text(),str(P/'patch_omega_base_v19.py'),'exec'))\\n" + marker)'''
base_v19a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v19a.py').read_text(),str(P/'patch_omega_base_v19a.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v19) == 1
recipe = recipe.replace(base_v19, base_v19 + '\n' + base_v19a, 1)
recipe = recipe.replace('omega_race_v19.nes', 'omega_race_v19a.nes')
recipe = recipe.replace('symbols_omega_v19.json', 'symbols_omega_v19a.json')
recipe = recipe.replace('prototype_omega_v19.asm', 'prototype_omega_v19a.asm')
exec(compile(recipe, str(P / 'build_omega_base_v19.py'), 'exec'))
