# Omega Race NES — Version 13A final-life timing

Baseline: Version 13.

- The last-life sequence still waits for every Player One projectile and impact
  animation to disappear.
- It now continues the live arena action for another full 120 frames/two
  seconds, matching deaths where lives remain.
- At the end of those 120 frames, the arena freezes in place for the future
  Game Over screen instead of rebuilding the level.
- All other Version 13 behavior remains unchanged.

Build: `python3 prototype/build_omega_base_v13a.py`

Test: `python3 prototype/test_omega_v13a.py`
