"""ROM-level tests for title placement, logo palette and level-song release."""
from pathlib import Path
import json

P = Path(__file__).parent
baseline = (P / 'test_omega_v19.py').read_text()
source = baseline.split('# The actual first vblank')[0]
source = source.replace('omega_race_v19.nes', 'omega_race_v19a.nes')
source = source.replace('symbols_omega_v19.json', 'symbols_omega_v19a.json')
env = {'__file__': str(P / 'test_omega_v19a.py')}
exec(compile(source, 'v19a machine harness', 'exec'), env)
boot, call = env['boot'], env['call']
assert_line = env['assert_line']
symbols = json.loads((P / 'symbols_omega_v19a.json').read_text())
rom = (P / 'omega_race_v19a.nes').read_bytes()
prg = rom[16:32784]

def table(name, count):
    addr = symbols[name] - 0x8000
    return prg[addr:addr + count]

title = b''.join(table(f'title_nt{i}', 256) for i in range(4))
old_rom = (P / 'omega_race_v19.nes').read_bytes()[16:32784]
old_symbols = json.loads((P / 'symbols_omega_v19.json').read_text())
old_title = b''.join(
    old_rom[old_symbols[f'title_nt{i}'] - 0x8000:old_symbols[f'title_nt{i}'] - 0x8000 + 256]
    for i in range(4)
)
for row in range(27):
    assert title[(row+3)*32:(row+4)*32] == old_title[row*32:(row+1)*32]
assert title[:3*32] == bytes(3*32)
assert title[23*32:960] == bytes(960-23*32)
for old_y in range(3,9):
    assert any(title[(old_y+3)*32+4:(old_y+3)*32+28])
assert table('palette',8) == bytes([0x0F,0x18,0x28,0x38, 0x0F,0x07,0x28,0x16])
for ty in range(6,12):
    for tx in range(4,28):
        attr = 960 + (ty//4)*8 + tx//4
        shift = ((ty//2)%2)*4 + ((tx//2)%2)*2
        assert (title[attr]>>shift)&3 == 1

m,c = boot()
assert_line(m,15,'PRESS SELECT TO CHOOSE')
assert_line(m,17,'STARTING LIVES: THREE')
assert_line(m,22,'PRESS START TO BEGIN')
assert m.name[0x2233] == 0x8A
m[0]=1
c.pc=0x7fff
c.sp=255
c.nmi()
for _ in range(25000):
    c.step()
    if c.pc==0x7fff:
        break
else:
    raise AssertionError('first NMI timeout')
assert m.name[0x2233] == 0x8A
for value,word in ((5,'FIVE '),(7,'SEVEN'),(3,'THREE')):
    m[0x9A] = value
    m[0xA7] = 0x80
    call(m,c,'omega_title_flush17')
    assert_line(m,17,'STARTING LIVES: '+word)
    assert m.name[0x2233] == 0x8A
print('PASS logo and title copy shift exactly 24px, $07/$28/$16 logo palette, dynamic lives and colon')

# Normal timing: 16-frame final-enemy sound, then 288 song frames.  Wave
# advances only after the song has explicitly silenced both pulse voices.
for cue in (16,40):
    m,c = boot()
    m[0xC7] = 1
    m[0xD7] = 1
    m[0xC5] = 0x30
    m[0xC6] = 1
    m[0x82] = cue
    m[0x86] = 1
    for frame in range(1, cue+289):
        call(m,c,'sfx_tick25')
        call(m,c,'pulse2_tick26')
        call(m,c,'omega_wave_delay9')
        if frame == 304 and cue == 40:
            assert m[0xC0] == 1 and m[0xD7] == 0xFF
            assert m[0xC5] == m[0xC6] == 0
        if frame == cue + 287:
            assert m[0xD7] == 0xFF and m[0x86]&3 == 3
        if frame == cue + 288:
            assert m[0xD7] == 0
            assert m[0x86]&3 == 0
            assert m[0x4015]&3 == 0
            assert m[0x4000] == m[0x4004] == 0x30
            assert m[0xDA] == m[0xDC] == 0
            assert m[0xC0] == 2
print('PASS both pulse channels silence at song end; a delayed song completes before the next wave')

# Version 19 Game Over remains present; Start retains selected starting lives
# and returning to the relocated title retains the new layout.
m,c = boot()
m[0x9A] = 7
call(m,c,'omega_start_game17')
call(m,c,'omega_gameover_enter19')
assert_line(m,4,'GAME OVER')
m[1],m[2] = 0x20,0
call(m,c,'game_controls')
call(m,c,'omega_title_flush17')
assert m[6] == 0 and m[0x9A] == 7
assert_line(m,17,'STARTING LIVES: SEVEN')
print('PASS existing Game Over and Select return retain the title and life-selector behavior')
