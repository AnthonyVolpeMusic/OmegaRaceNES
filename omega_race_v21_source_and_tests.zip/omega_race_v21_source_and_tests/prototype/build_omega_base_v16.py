"""Build Omega Race Version 16 with adaptive triangle music."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v15a.py').read_text()

base_v15a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v15a.py').read_text(),str(P/'patch_omega_base_v15a.py'),'exec'))\\n" + marker)'''
base_v16 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v16.py').read_text(),str(P/'patch_omega_base_v16.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v15a) == 1
recipe = recipe.replace(base_v15a, base_v15a + '\n' + base_v16, 1)

recipe = recipe.replace('omega_race_v15a.nes', 'omega_race_v16.nes')
recipe = recipe.replace('symbols_omega_v15a.json', 'symbols_omega_v16.json')
recipe = recipe.replace('prototype_omega_v15a.asm', 'prototype_omega_v16.asm')
exec(compile(recipe, str(P / 'build_omega_base_v15a.py'), 'exec'))
