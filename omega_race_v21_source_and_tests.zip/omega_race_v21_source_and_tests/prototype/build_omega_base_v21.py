"""Build Omega Race Version 21 from confirmed Version 20A."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v20a.py').read_text()

base_v20a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v20a.py').read_text(),str(P/'patch_omega_base_v20a.py'),'exec'))\\n" + marker)'''
base_v21 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v21.py').read_text(),str(P/'patch_omega_base_v21.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v20a) == 1
recipe = recipe.replace(base_v20a, base_v20a + '\n' + base_v21, 1)
recipe = recipe.replace('omega_race_v20a.nes', 'omega_race_v21.nes')
recipe = recipe.replace('symbols_omega_v20a.json', 'symbols_omega_v21.json')
recipe = recipe.replace('prototype_omega_v20a.asm', 'prototype_omega_v21.asm')
exec(compile(recipe, str(P / 'build_omega_base_v20a.py'), 'exec'))
