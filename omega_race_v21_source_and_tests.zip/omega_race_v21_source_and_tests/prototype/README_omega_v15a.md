# Omega Race NES — Version 15A slower level-clear song

Baseline: Version 15.

- Sixteenth notes alternate between four and five frames.
- Eighth notes last nine frames.
- Quarter notes last 18 frames.
- Half notes last 36 frames.
- Three-quarter notes last 54 frames.
- Each measure now lasts 72 frames; the complete tune lasts 288 frames, or
  approximately 4.8 seconds.
- The level intermission is extended from 300 to 304 frames so the song can
  begin after the final 16-frame destruction cue and still finish cleanly.

Build: `python3 prototype/build_omega_base_v15a.py`

Test: `python3 prototype/test_omega_v15a.py`
