"""Four harmless drones, a shared geometry-derived loop, independent targets.

RAM $0300..033F: 16-byte records (x,y,target,direction,step fraction).
$0380..038F: shared node x/y arrays. $A8/$A9: animation phase/timer.
$AA..AE: private drone scratch. No collision or score callbacks enabled.
"""
code='\n'.join(lines)
# Derive an octagon from V5A's middle rectangle and playfield extents.
# Coordinates describe 8x8 sprite origins. Keep the loop well clear of walls.
bx,by,bw,bh=9*8,10*8,14*8,10*8
left=(0+bx)//2-4
right=(bx+bw+256)//2-4
top=(8+by)//2-4
bottom=(by+bh+232)//2-4
cut=min(bx-left,by-top,32)
nodes=[(left+cut,top),(right-cut,top),(right,top+cut),
       (right,bottom-cut),(right-cut,bottom),(left+cut,bottom),
       (left,bottom-cut),(left,top+cut)]
assert len(nodes)==8
data['drone_nodes_x6']=[p[0] for p in nodes]
data['drone_nodes_y6']=[p[1] for p in nodes]
data['drone_spawn_nodes6']=[0,2,4,6]
data['drone_directions6']=[1,255,1,255]

old='LDA #$10\nSTA $3E\nLDA #$88\nSTA $2000'
assert code.count(old)==1
code=code.replace(old,'JSR drone_init6\n'+old,1)
old='JSR physics\nJSR bullets'
assert code.count(old)==1
code=code.replace(old,old+'\nJSR drone_tick6',1)
old='render_burst_done22a:\nRTS'
assert code.count(old)==1
code=code.replace(old,'render_burst_done22a:\nJSR drone_render6\nRTS',1)
code+='''
drone_init6:
LDA #$00
STA $A8
STA $A9
LDX #$07
drone_nodes_load6:
LDA drone_nodes_x6,X
STA $0380,X
LDA drone_nodes_y6,X
STA $0388,X
DEX
BPL drone_nodes_load6
LDX #$00
LDY #$00
drone_spawn6:
STY $AD
LDA drone_directions6,Y
STA $0303,X
LDA drone_spawn_nodes6,Y
TAY
LDA $0380,Y
STA $0300,X
LDA $0388,Y
STA $0301,X
LDA #$00
STA $0304,X
JSR drone_assign6
LDY $AD
INY
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE drone_spawn6
RTS
drone_assign6:
LDA #$FF
STA $AE
LDY #$00
drone_nearest6:
LDA $0300,X
SEC
SBC $0380,Y
BCS drone_abs_x6
EOR #$FF
CLC
ADC #$01
drone_abs_x6:
STA $AA
LDA $0301,X
SEC
SBC $0388,Y
BCS drone_abs_y6
EOR #$FF
CLC
ADC #$01
drone_abs_y6:
CMP $AA
BCS drone_distance6
LDA $AA
drone_distance6:
CMP $AE
BCS drone_nearest_next6
STA $AE
TYA
STA $0302,X
drone_nearest_next6:
INY
CPY #$08
BNE drone_nearest6
RTS
drone_tick6:
INC $A9
LDA $A9
CMP #$06
BCC drone_tick_start6
LDA #$00
STA $A9
INC $A8
LDA $A8
AND #$03
STA $A8
drone_tick_start6:
LDX #$00
drone_tick_loop6:
JSR drone_move6
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE drone_tick_loop6
RTS
drone_move6:
LDY $0302,X
LDA $0380,Y
STA $AB
LDA $0388,Y
STA $AC
LDA $0300,X
CMP $AB
BNE drone_step6
LDA $0301,X
CMP $AC
BNE drone_step6
LDA $0302,X
CLC
ADC $0303,X
AND #$07
STA $0302,X
TAY
LDA $0380,Y
STA $AB
LDA $0388,Y
STA $AC
drone_step6:
LDA #$80
STA $AA
LDA $0300,X
CMP $AB
BEQ drone_fraction6
LDA $0301,X
CMP $AC
BEQ drone_fraction6
LDA #$5B
STA $AA
drone_fraction6:
LDA $0304,X
CLC
ADC $AA
STA $0304,X
BCC drone_move_done6
LDA $0300,X
CMP $AB
BEQ drone_move_y6
BCC drone_right6
DEC $0300,X
JMP drone_move_y6
drone_right6:
INC $0300,X
drone_move_y6:
LDA $0301,X
CMP $AC
BEQ drone_move_done6
BCC drone_down6
DEC $0301,X
RTS
drone_down6:
INC $0301,X
drone_move_done6:
RTS
drone_render6:
LDX #$00
LDY #$14
drone_render_loop6:
LDA $0301,X
SEC
SBC #$01
STA $0200,Y
LDA $A8
CLC
ADC #$E0
STA $0201,Y
LDA #$03
STA $0202,Y
LDA $0300,X
STA $0203,Y
INY
INY
INY
INY
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE drone_render_loop6
RTS
'''
lines=[s.strip() for s in code.splitlines() if s.strip()]
