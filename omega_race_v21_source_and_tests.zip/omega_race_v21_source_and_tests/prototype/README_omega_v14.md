# Omega Race NES — Version 14 sound-effects pass

Baseline: Version 13A.

New dedicated effects:

- Player One fire: D5 to D4 portamento, 12-frame fade.
- Commander/Shooting Star fire: G5 to G3 portamento, 12-frame fade.
- Drone destroyed: B2/G2, alternating every two frames for 16 frames.
- Commander destroyed: C5/C4, alternating every two frames for 16 frames.
- Shooting Star destroyed: C5/A5, alternating every two frames for 16 frames.
- Player wall bounce: C3/B2, alternating every two frames for 16 frames.
- Mine destroyed: C3, F3, C2, three frames each.
- Player projectile wall impact: G3 to C4 portamento over ten frames.
- Extra life: three six-frame G3 beeps separated by six-frame rests.
- Player One death: all channels are silenced; noise 12 plays for four frames,
  rests for four and repeats once, followed by a 60-frame noise-11 fade.

Mine drops remain silent. The existing shield, stop-super and continuous-thrust
effects are retained. Level-clear audio remains reserved for a future song.

Build: `python3 prototype/build_omega_base_v14.py`
