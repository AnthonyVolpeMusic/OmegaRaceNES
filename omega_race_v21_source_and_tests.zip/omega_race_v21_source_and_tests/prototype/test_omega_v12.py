"""Machine-code regression tests for Omega Race Version 12."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v11b.py').read_text()
text = text.replace('Version 11B.', 'Version 12.', 1)
text = text.replace('omega_race_v11b.nes', 'omega_race_v12.nes')
text = text.replace('symbols_omega_v11b.json', 'symbols_omega_v12.json')
exec(compile(text, str(P / 'test_omega_v11b.py'), 'exec'))


def mine_count(mm):
    return sum(mm[a] != 0 for a in range(0x700, 0x740, 4))


# Exact supplied 8x8 tile: 0 transparent, 1 red and 3 orange.
mine_rows = [
    '00010000',
    '00111000',
    '00131000',
    '01131100',
    '01333100',
    '11333110',
    '11111110',
    '00000000',
]
for y, row in enumerate(mine_rows):
    for x, value in enumerate(row):
        assert chr_pixel(0xEC, x, y) == int(value)
print('PASS all 64 land-mine pixels match the supplied drawing')

# Initial Commanders wait exactly 240 active frames. Shooting Stars wait
# exactly 120; conversion initializes the shorter interval.
mm, cc = boot()
assert mm[0x30E] == 240
assert all(mm[a + 14] == 0 for a in range(0x310, 0x370, 16))
cc.x = 0
for _ in range(239):
    call(mm, cc, 'omega_mine_tick12')
    cc.x = 0
assert mine_count(mm) == 0 and mm[0x30E] == 1
call(mm, cc, 'omega_mine_tick12')
assert mine_count(mm) == 1 and mm[0x30E] == 240
assert mm[0x701:0x703] == mm[0x300:0x302]

for a in range(0x700, 0x740, 4):
    mm[a] = 0
mm[0x306] = 2
cc.x = 0
call(mm, cc, 'omega_mine_timer_reset12')
assert mm[0x30E] == 120
for _ in range(119):
    call(mm, cc, 'omega_mine_tick12')
    cc.x = 0
assert mine_count(mm) == 0 and mm[0x30E] == 1
call(mm, cc, 'omega_mine_tick12')
assert mine_count(mm) == 1 and mm[0x30E] == 120
print('PASS Commanders drop every four seconds and Shooting Stars every two seconds')

# Every occupied slot blocks further drops without replacing an old mine.
mm, cc = boot()
for i, a in enumerate(range(0x700, 0x740, 4)):
    mm[a:a+3] = [0xFF, 16 + i * 8, 180]
before = list(mm[0x700:0x740])
mm[0x300], mm[0x301] = 200, 40
cc.x = 0
call(mm, cc, 'omega_mine_drop12')
assert mine_count(mm) == 16 and list(mm[0x700:0x740]) == before
print('PASS the shared onscreen land-mine limit is exactly sixteen')

# Mines occupy the sixteen OAM slots immediately after enemy projectiles and
# use tile $EC with Commander palette 1.
call(mm, cc, 'omega_mines_render12')
for i in range(16):
    oam = 0x26C + i * 4
    assert mm[oam + 1] == 0xEC and mm[oam + 2] == 1
    assert mm[oam + 3] == 16 + i * 8 and mm[oam] == 179
print('PASS all sixteen mines render as one 8x8 sprite with the requested palette')

# Mine contact uses the existing Player One death/restart system.
mm, cc = boot()
for a in range(0x300, 0x400, 16):
    mm[a + 5] = 0
for a in range(0x580, 0x5E0, 16):
    mm[a] = 0
mm[0x700:0x703] = [0xFF, mm[0x11], mm[0x13]]
call(mm, cc, 'omega_player_collision9')
assert mm[0x677] == 1 and mm[0x3D] == 2
print('PASS touching a land mine destroys Player One')

# A Player One projectile destroys one mine, reuses its explosion and adds 350
# points exactly once.
mm, cc = boot()
for a in range(0x300, 0x400, 16):
    mm[a + 5] = 0
mm[0x700:0x703] = [0xFF, 80, 120]
mm[0x600:0x60B] = [0xFF,0,80,0,120,0,0,0,0,0,0]
call(mm, cc, 'omega_mine_bullet_collision12')
assert mm[0x700] == 0 and mm[0x600] == 0x0F and mm[0x609] == 1
assert mm[0x30:0x33] == [0x5E,0x01,0] and mm[0x33:0x39] == [0,0,0,3,5,0]
assert mm[0xA7] & 0x01
print('PASS shooting a mine awards 350 points and reuses the impact explosion')

# Level and life setup preserve mines. Only positions within eight pixels of
# the newly selected P1 spawn are preemptively removed (eight is inclusive).
mm, cc = boot()
for a in range(0x700, 0x740, 4):
    mm[a] = 0
mm[0x700:0x703] = [0xFF, 0xE8, 0x20]  # 8 px from odd-level spawn
mm[0x704:0x707] = [0xFF, 0xD7, 0x18]  # 9 px away; survives
mm[0x708:0x70B] = [0xFF, 100, 180]    # far mine; survives
mm[0xC0] = 1
call(mm, cc, 'omega_level_setup9')
assert mm[0x700] == 0 and mm[0x704] and mm[0x708]

mm[0x70C:0x70F] = [0xFF, 0x10, 0x10]  # 8 px from even-level spawn
mm[0xC0] = 2
call(mm, cc, 'omega_level_setup9')
assert mm[0x704] and mm[0x708] and mm[0x70C] == 0
print('PASS mines persist across board rebuilds with eight-pixel spawn protection')

# A full Level 7 formation, six enemy shots and sixteen persistent mines stay
# within the real main/NMI frame loop budget.
mm, cc = boot()
mm[0xC0] = 7
call(mm, cc, 'omega_level_setup9')
for i, a in enumerate(range(0x700, 0x740, 4)):
    mm[a:a+3] = [0xFF, 12 + i * 14, 208]
for a in range(0x580, 0x5E0, 16):
    mm[a] = 0xFF
mm.ppu = []
mm.pad = 0
cc.pc = S['main']
cc.sp = 255
deadline = cc.processorCycles
for _ in range(360):
    end = deadline + 29781
    while cc.processorCycles < end:
        if cc.processorCycles >= deadline:
            cc.nmi()
            deadline += 29781
        cc.step()
assert 350 <= mm.dmas <= 360, (len(mm.ppu), mm.dmas, cc.pc, mm[0x677], mm[0x3D])
assert len(mm.ppu) <= 8 and mine_count(mm) <= 16
print('PASS maximum enemy, projectile and mine load remains stable within the frame budget')
