"""Machine-code regression tests for Omega Race Version 7A."""
from pathlib import Path

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]


def harness(rom, symbols):
    text = base.replace('omega_race_player_base_v2_palette_test.nes', rom)
    text = text.replace('symbols_omega_base_v1.json', symbols)
    text = text.replace('range(400000)', 'range(600000)')
    env = {'__file__': str(P / 'test_omega_v7a.py')}
    exec(compile(text, 'harness', 'exec'), env)
    return env


new = harness('omega_race_v7a.nes', 'symbols_omega_v7a.json')
old = harness('omega_race_v6_drone_test.nes', 'symbols_omega_v6.json')
boot, call = new['boot'], new['call']
mm, cc = boot()

assert mm[0x11] == 0xE0 and mm[0x13] == 0x18 and mm[0x03] == 0x24
print('PASS Player One starts upper right facing west')

spawn_x = [40, 48, 58, 68, 35, 55, 70]
spawn_y = [166, 178, 188, 193, 150, 171, 184]
for i, a in enumerate(range(0x300, 0x370, 16)):
    assert mm[a] == spawn_x[i] and mm[a + 1] == spawn_y[i]
    assert mm[a + 3] == 1
assert len(set(zip(spawn_x, spawn_y))) == 7
assert all(x < 72 and y >= 150 for x, y in zip(spawn_x, spawn_y))
print('PASS seven distinct southwest spawns, all clockwise')

# Every drone has eight private destinations derived from the safe centerline.
base_nodes = [(64, 40), (184, 40), (216, 72), (216, 160),
              (184, 192), (64, 192), (32, 160), (32, 72)]
inward = [(1, 1), (-1, 1), (-1, 1), (-1, -1),
          (-1, -1), (1, -1), (1, -1), (1, 1)]
profiles = [
    [-14, -12, -10, 0, 10, 12, 14, 10],
    [13, 15, 12, 9, -10, -13, -15, -11],
    [-10, 11, 15, 12, 0, -12, -14, -13],
    [15, 10, -11, -15, -12, 9, 13, 14],
    [-15, -10, 12, 14, 11, -11, -13, 9],
    [9, 14, 13, -9, -14, -12, 10, 15],
    [12, -9, -14, -13, 10, 15, 11, -10],
]
routes = []
for profile in profiles:
    route = [(x + dx * o, y + dy * o)
             for (x, y), (dx, dy), o in zip(base_nodes, inward, profile)]
    routes.append(route)
assert len({tuple(r) for r in routes}) == 7
for i, route in enumerate(routes):
    assert list(mm[0x400 + i * 8:0x408 + i * 8]) == [x for x, _ in route]
    assert list(mm[0x440 + i * 8:0x448 + i * 8]) == [y for _, y in route]
print('PASS seven widened personal racing lines loaded inside shared corridor')

# Put every drone exactly on its private node zero. Each must choose and begin
# moving toward its own node one rather than the master route's destination.
for i, a in enumerate(range(0x300, 0x370, 16)):
    mm[a], mm[a + 1] = routes[i][0]
    mm[a + 2], mm[a + 4] = 0, 0
    for _ in range(6):
        cc.x = a - 0x300
        call(mm, cc, 'drone_move6')
    assert mm[a + 2] == 1
    expected_dx = 1 if routes[i][1][0] > routes[i][0][0] else -1
    expected_dy = 1 if routes[i][1][1] > routes[i][0][1] else (-1 if routes[i][1][1] < routes[i][0][1] else 0)
    assert mm[a] == routes[i][0][0] + expected_dx
    assert mm[a + 1] == routes[i][0][1] + expected_dy
print('PASS movement resolves each drone through its own node table')

# Restore a clean boot for rendering and long-run checks.
mm, cc = boot()

call(mm, cc, 'render')
for a in range(0x214, 0x230, 4):
    assert mm[a] != 0xF8 and mm[a + 1] == 0xE0 and mm[a + 2] == 3
print('PASS all seven animated drone sprites are rendered')

# Measure movement after the short nearest-node acquisition leg. Half V6's
# 0.5 px/frame rate should produce about 3000 pixels in 12000 frames.
seen = [set() for _ in range(7)]
travel = [0.0] * 7
for tick in range(12000):
    before = [tuple(mm[a:a + 2]) for a in range(0x300, 0x370, 16)]
    call(mm, cc, 'drone_tick6')
    for i, a in enumerate(range(0x300, 0x370, 16)):
        x, y = mm[a:a + 2]
        seen[i].add(mm[a + 2])
        assert 1 < x < 247 and 9 < y < 224
        assert not (x + 7 >= 72 and x <= 183 and y + 7 >= 80 and y <= 159)
        dx, dy = x - before[i][0], y - before[i][1]
        assert abs(dx) <= 1 and abs(dy) <= 1
        travel[i] += (dx * dx + dy * dy) ** 0.5
assert all(s == set(range(8)) for s in seen)
assert all(2950 < t < 3050 for t in travel), travel
assert mm[7] == 5 and mm[0x3D] == 3 and mm[0x33:0x39] == [0] * 6
print('PASS half-speed clockwise laps, wall clearance, no collision or scoring')

# Preserve all V6 graphics and the static playfield/HUD.
om, oc = old['boot']()
assert new['CHR'] == old['CHR']
assert mm.ppu == om.ppu
print('PASS Version 6 artwork, arena, palette and HUD retained')

# Exercise the real main/NMI handshake for three seconds.
mm, cc = boot()
mm.ppu = []
mm.pad = 0
cc.pc = new['S']['main']
cc.sp = 255
deadline = cc.processorCycles
for frame in range(180):
    end = deadline + 29781
    while cc.processorCycles < end:
        if cc.processorCycles >= deadline:
            cc.nmi()
            deadline += 29781
        cc.step()
assert not mm.ppu and 178 <= mm.dmas <= 180
assert mm[7] == 5 and mm[0x3D] == 3 and mm[0x33:0x39] == [0] * 6
assert all(mm[a] != 0xF8 for a in range(0x214, 0x230, 4))
print('PASS real main/NMI execution with seven harmless drones')
