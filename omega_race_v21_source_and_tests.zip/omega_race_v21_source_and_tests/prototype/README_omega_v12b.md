# Omega Race NES — Version 12B shield and palette fixes

Baseline: Version 12A.

- An active shield now protects Player One from drone/Commander/Shooting Star
  contact, live enemy projectiles and land mines for the full 60-frame timer.
- A pending level palette is now written at the first VBlank, independently of
  the normal frame-ready HUD/OAM update path.
- Same-level restarts retain the palette already applied at level start.
- Palette writes remain event-driven and still touch only `$3F00-$3F03`.
- All Version 12A gameplay, mine timing and the eight-level palette cycle are
  otherwise unchanged.

Build: `python3 prototype/build_omega_base_v12b.py`

Test: `python3 prototype/test_omega_v12b.py`
