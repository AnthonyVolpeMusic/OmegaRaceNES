# Omega Race NES — Version 12 land mines

Baseline: Version 11B's revised Shooting Star artwork, fixed 1.5-pixel speed,
hybrid pursuit, firing, conversion, scoring and collision rules.

- Commanders drop a stationary land mine every 240 active frames (four
  seconds).
- Shooting Stars drop one every 120 active frames (two seconds).
- All advanced enemies share a strict maximum of sixteen active mines.
- Mines use Anthony Volpe's exact 8x8 drawing at sprite tile `$EC` with
  transparent `$08`, red `$16`, and orange `$38`.
- Touching a mine destroys Player One through the existing death/restart
  system.
- A Player One projectile destroys a mine, reuses the existing impact
  animation, and awards 350 points with an event-driven score update.
- Mines persist when Player One respawns and when the next level begins.
- During board setup, only a mine within eight pixels of Player One's new spawn
  position is preemptively removed. The eight-pixel limit is inclusive.
- Mines do not count as enemies and therefore do not prevent level completion.

Build: `python3 prototype/build_omega_base_v12.py`

Test: `python3 prototype/test_omega_v12.py`

Dependencies: Python 3, Pillow and py65.
