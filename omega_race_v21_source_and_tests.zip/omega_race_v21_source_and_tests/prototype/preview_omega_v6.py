"""Render a diagnostic still from actual ROM nametable, CHR and OAM bytes.
This is not a hardware PPU emulator; colors are representative NES golds.
"""
from pathlib import Path
from PIL import Image
P=Path(__file__).parent
env={'__file__':str(P/'test_omega_v6.py')}
exec(compile((P/'test_omega_v6.py').read_text().split('# Independently transcribed')[0], 'preview harness','exec'),env)
m,c=env['boot']();nt=m.ppu[4128:5152];chrdata=env['new']['CHR']
env['call'](m,c,'render')
im=Image.new('RGB',(256,240));pal=[(64,51,0),(157,143,0),(252,224,0),(255,241,160)]
def pixel(tile,x,y):
    at=tile*16
    return ((chrdata[at+y]>>(7-x))&1)|(((chrdata[at+y+8]>>(7-x))&1)<<1)
for y in range(240):
    for x in range(256):im.putpixel((x,y),pal[pixel(nt[(y//8)*32+x//8],x%8,y%8)])
for a in reversed(range(0x200,0x300,4)):
    sy,t,p,sx=m[a:a+4];sy+=1
    if sy>=240:continue
    colors=[0,3,1,2] if p==0 else [0,1,2,3]
    if p==2:colors=[0,2,3,1]
    for y in range(8):
        for x in range(8):
            value=pixel(0x100+t,x,y)
            if value and sx+x<256 and sy+y<240:im.putpixel((sx+x,sy+y),pal[colors[value]])
im.resize((768,720),Image.Resampling.NEAREST).save(P/'omega_v6_diagnostic.png')
