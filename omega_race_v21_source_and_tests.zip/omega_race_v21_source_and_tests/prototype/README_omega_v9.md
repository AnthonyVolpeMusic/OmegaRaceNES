# Omega Race NES — Version 9 collisions and level progression

Baseline: Version 8's independently routed drones, Commander animation and
clear-line firing, scoring, arena, controls, graphics and audio.

- Player One now dies from a flying enemy projectile or direct contact with a
  drone or Commander.
- Death removes one life, starts the existing death sound, and creates four
  independently moving explosion pieces with randomized directions.
- If lives remain, the complete current level restarts after exactly 180
  simulation frames (three seconds). Score persists and SUPERS refill to five.
- With no lives remaining, the ship stays dead; a dedicated Game Over screen is
  intentionally deferred.
- Destroying every enemy starts an exact 300-frame (five-second) delay before
  the next level is populated.
- Odd levels place Player One upper-right, facing west, with enemies scattered
  southwest on clockwise routes. Even levels mirror the complete setup:
  Player One is upper-left facing east, and southeast enemies run
  counterclockwise routes.
- All sixteen possible enemies retain separate personal routes.
- Commander firing intervals are 120, 90, 60, 45 and then 30 frames beginning
  at Level 5.
- Enemy speed is 1.00x on Level 1 and rises in 0.25x steps through the 3.00x
  cap on Level 9. Commanders remain exactly twice the current drone speed.
- Starting drone/Commander counts are 6/1, 7/1, 8/2, 9/2, 10/3, 11/3 and
  12/4 from Level 7 onward.
- Destroyed Commanders promote surviving drones until the current level's
  Commander quota is restored, when enough drones remain.
- All Commanders share six enemy-projectile records. When all six are occupied,
  no Commander can fire another missile.
- Score, lives and SUPERS tiles remain event-driven.

Build: `python3 prototype/build_omega_base_v9.py`

Test: `python3 prototype/test_omega_v9.py`

Dependencies: Python 3, Pillow and py65.
