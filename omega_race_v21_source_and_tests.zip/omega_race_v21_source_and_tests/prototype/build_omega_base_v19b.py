"""Build Omega Race Version 19B from confirmed Version 19A."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v19a.py').read_text()

base_v19a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v19a.py').read_text(),str(P/'patch_omega_base_v19a.py'),'exec'))\\n" + marker)'''
base_v19b = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v19b.py').read_text(),str(P/'patch_omega_base_v19b.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v19a) == 1
recipe = recipe.replace(base_v19a, base_v19a + '\n' + base_v19b, 1)
recipe = recipe.replace('omega_race_v19a.nes', 'omega_race_v19b.nes')
recipe = recipe.replace('symbols_omega_v19a.json', 'symbols_omega_v19b.json')
recipe = recipe.replace('prototype_omega_v19a.asm', 'prototype_omega_v19b.asm')
exec(compile(recipe, str(P / 'build_omega_base_v19a.py'), 'exec'))
