"""Build Omega Race Version 13 with revised life and round timing."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v12b.py').read_text()

base_v12b = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v12b.py').read_text(),str(P/'patch_omega_base_v12b.py'),'exec'))\\n" + marker)'''
base_v13 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v13.py').read_text(),str(P/'patch_omega_base_v13.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v12b) == 1
recipe = recipe.replace(base_v12b, base_v12b + '\n' + base_v13, 1)

recipe = recipe.replace('omega_race_v12b.nes', 'omega_race_v13.nes')
recipe = recipe.replace('symbols_omega_v12b.json', 'symbols_omega_v13.json')
recipe = recipe.replace('prototype_omega_v12b.asm', 'prototype_omega_v13.asm')
exec(compile(recipe, str(P / 'build_omega_base_v12b.py'), 'exec'))
