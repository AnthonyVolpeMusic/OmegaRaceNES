"""Build Omega Race Version 12B with shield and palette fixes."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v12a.py').read_text()

base_v12a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v12a.py').read_text(),str(P/'patch_omega_base_v12a.py'),'exec'))\\n" + marker)'''
base_v12b = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v12b.py').read_text(),str(P/'patch_omega_base_v12b.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v12a) == 1
recipe = recipe.replace(base_v12a, base_v12a + '\n' + base_v12b, 1)

recipe = recipe.replace('omega_race_v12a.nes', 'omega_race_v12b.nes')
recipe = recipe.replace('symbols_omega_v12a.json', 'symbols_omega_v12b.json')
recipe = recipe.replace('prototype_omega_v12a.asm', 'prototype_omega_v12b.asm')
exec(compile(recipe, str(P / 'build_omega_base_v12a.py'), 'exec'))
