"""Version 16: adaptive triangle-channel gameplay music."""

code = '\n'.join(lines)

# Replace the inherited Asteroids two-note pulse with Omega Race's four-note
# adaptive loop and Shooting Star alert. Legacy recalculation code remains for
# unreachable inherited routines that still reference its label.
start = code.index('pulse_gate24c:')
end = code.index('pulse_recalculate24d:', start)
code = code[:start] + r'''pulse_gate24c:
LDA $06
BNE omega_triangle_game16
JMP omega_triangle_off16
omega_triangle_game16:
LDA $0677
BEQ omega_triangle_alive16
JMP omega_triangle_off16
omega_triangle_alive16:
LDA $C7
BEQ omega_triangle_scan_start16
JMP omega_triangle_off16
omega_triangle_scan_start16:
LDA #$00
STA $7F
STA $80
LDX #$00
omega_triangle_scan16:
LDA $0305,X
BEQ omega_triangle_scan_next16
LDA #$01
STA $7F
LDA $0306,X
CMP #$02
BNE omega_triangle_scan_next16
LDA #$01
STA $80
omega_triangle_scan_next16:
TXA
CLC
ADC #$10
TAX
BNE omega_triangle_scan16
LDA $7F
BNE omega_triangle_enemy_present16
JMP omega_triangle_off16
omega_triangle_enemy_present16:
LDA $80
CMP $7E
BEQ omega_triangle_mode_ready16
STA $7E
LDA #$00
STA $067F
STA $7C
STA $7D
omega_triangle_mode_ready16:
LDA $067F
BEQ omega_triangle_phase_due16
DEC $067F
BNE omega_triangle_done16
omega_triangle_phase_due16:
LDA $7E
BNE omega_triangle_star_note16
LDA $7D
BEQ omega_triangle_normal_note16
LDA #$00
STA $7D
JSR omega_triangle_silence16
LDA $7B
STA $067F
RTS
omega_triangle_normal_note16:
LDX $7C
LDA omega_triangle_normal_low16,X
STA $400A
LDA omega_triangle_normal_high16,X
JSR omega_triangle_play16
LDA #$06
STA $067F
LDA #$01
STA $7D
JMP omega_triangle_advance16
omega_triangle_star_note16:
LDX $7C
LDA omega_triangle_star_low16,X
STA $400A
LDA omega_triangle_star_high16,X
JSR omega_triangle_play16
LDA #$06
STA $067F
LDA #$00
STA $7D
omega_triangle_advance16:
INC $7C
LDA $7C
AND #$03
STA $7C
omega_triangle_done16:
RTS
omega_triangle_play16:
PHA
LDA #$FF
STA $4008
LDA $86
ORA #$04
STA $86
STA $4015
PLA
STA $400B
RTS
omega_triangle_silence16:
LDA $86
AND #$FB
STA $86
STA $4015
RTS
omega_triangle_off16:
LDA #$00
STA $067F
STA $7C
STA $7D
STA $7E
JMP omega_triangle_silence16
''' + code[end:]

# Every destroyed enemy—not a mine—reduces the normal rest by two frames.
old = '''drone_score_done9:
JSR omega_hud_request_score_v5a'''
new = '''drone_score_done9:
JSR omega_triangle_kill16
JSR omega_hud_request_score_v5a'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Reset the normal rest and sequencer on every board/level setup.
old = '''STA $D9
STA $DA
STA $DB
STA $DC
STA $08'''
new = '''STA $D9
STA $DA
STA $DB
STA $DC
STA $067F
STA $7C
STA $7D
STA $7E
LDA #$18
STA $7B
LDA #$00
STA $08'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += r'''
omega_triangle_kill16:
LDA $7B
CMP #$08
BCC omega_triangle_kill_done16
SEC
SBC #$02
STA $7B
LDA $7E
BNE omega_triangle_kill_done16
LDA $7D
BNE omega_triangle_kill_done16
LDA $067F
CMP $7B
BCC omega_triangle_kill_done16
BEQ omega_triangle_kill_done16
LDA $7B
STA $067F
omega_triangle_kill_done16:
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]

# Triangle periods: normal G2/F2/E-flat2/C2; alert G2/C3/G2/C2.
data['omega_triangle_normal_low16'] = [0x3A,0x80,0xCE,0x56]
data['omega_triangle_normal_high16'] = [0x02,0x02,0x02,0x03]
data['omega_triangle_star_low16'] = [0x3A,0xAB,0x3A,0x56]
data['omega_triangle_star_high16'] = [0x02,0x01,0x02,0x03]
