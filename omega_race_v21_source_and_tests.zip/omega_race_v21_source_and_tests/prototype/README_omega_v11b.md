# Omega Race NES — Version 11B Shooting Star speed

Baseline: Version 11A's revised four-frame Shooting Star artwork and Version
11's conversion, pursuit, firing, scoring and collision rules.

- Shooting Stars now move at a fixed 1.5 pixels per active frame from Level 1
  onward.
- Both direct pursuit and personal-route fallback use the fixed speed.
- Cardinal movement is two 0.75-pixel fixed-point steps per frame.
- Diagonal components are normalized to preserve an approximately 1.5-pixel
  resultant speed instead of making diagonal travel faster.
- Drone and Commander speeds retain their existing level-based progression.

Build: `python3 prototype/build_omega_base_v11b.py`

Test: `python3 prototype/test_omega_v11b.py`

Dependencies: Python 3, Pillow and py65.
