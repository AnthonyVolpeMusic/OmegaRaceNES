"""Machine-code regression tests for Omega Race Version 13A."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v13.py').read_text()
text = text.replace('Version 13.', 'Version 13A.', 1)
text = text.replace('omega_race_v13.nes', 'omega_race_v13a.nes')
text = text.replace('symbols_omega_v13.json', 'symbols_omega_v13a.json')

# V13 froze immediately after the final shot. V13A verifies the replacement
# below after all unaffected V13 checks have run.
start = text.index("# Zero lives still permits the final shots to finish;")
end = text.index("# Level advancement also enters", start)
text = text[:start] + text[end:]
exec(compile(text, str(P / 'test_omega_v13.py'), 'exec'))


# On the final life, the countdown begins only after all Player One shots have
# vanished. The arena continues for all 120 frames and freezes on the last one.
mm, cc = boot()
mm[0x0677] = 0
mm[0x3D] = 1
mm[0x600] = 0xFF
call(mm, cc, 'omega_player_kill9')
assert mm[0x3D] == 0 and mm[0x0677] == 1 and mm[0x600]
for _ in range(120):
    call(mm, cc, 'omega_death_tick9')
assert mm[0x0677] == 1 and mm[0x0678] == 0
mm[0x600] = 0
call(mm, cc, 'omega_death_tick9')
assert mm[0x0677] == 1 and mm[0x0678] == 120
for expected in range(119, 0, -1):
    call(mm, cc, 'omega_death_tick9')
    assert mm[0x0677] == 1 and mm[0x0678] == expected
call(mm, cc, 'omega_death_tick9')
assert mm[0x0677] == 2 and mm[0x0678] == 0
print('PASS final life continues for 120 frames after the final shot, then freezes')

# The continuation is live gameplay, not merely a countdown: enemies advance
# until the exact frame on which the future Game Over freeze begins.
mm, cc = boot()
mm[0x0677] = 1
mm[0x3D] = 0
mm[0x600:0x640] = [0] * 0x40
mm[0x0678] = 120
samples = []
for _ in range(120):
    samples.append((mm[0x300], mm[0x301], mm[0x304]))
    call(mm, cc, 'omega_frame9')
assert len(set(samples)) > 1 and mm[0x0677] == 2
frozen = list(mm[0x300:0x400])
for _ in range(60):
    call(mm, cc, 'omega_frame9')
assert list(mm[0x300:0x400]) == frozen
print('PASS enemy action remains live throughout the final continuation and then stops')
