"""Build Omega Race Version 17 with its first native title screen."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v16.py').read_text()

base_v16 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v16.py').read_text(),str(P/'patch_omega_base_v16.py'),'exec'))\\n" + marker)'''
base_v17 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v17.py').read_text(),str(P/'patch_omega_base_v17.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v16) == 1
recipe = recipe.replace(base_v16, base_v16 + '\n' + base_v17, 1)

recipe = recipe.replace('omega_race_v16.nes', 'omega_race_v17.nes')
recipe = recipe.replace('symbols_omega_v16.json', 'symbols_omega_v17.json')
recipe = recipe.replace('prototype_omega_v16.asm', 'prototype_omega_v17.asm')
exec(compile(recipe, str(P / 'build_omega_base_v16.py'), 'exec'))
