"""Install the deduplicated 192x48 Omega Race title logo."""

for index, pixels in enumerate(omega_logo_tiles17, 1):
    rows = [list(pixels[y * 8:(y + 1) * 8]) for y in range(8)]
    tile(index, rows)
