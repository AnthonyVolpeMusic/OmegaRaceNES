"""Regression and V4-specific tests for the narrowed Omega Race track."""
from pathlib import Path

P = Path(__file__).parent
source = (P / 'test_omega_base_v1.py').read_text()
source = source.replace('omega_race_player_base_v2_palette_test.nes',
                        'omega_race_v4_narrow_track_test.nes')
source = source.replace('symbols_omega_base_v1.json', 'symbols_omega_v4.json')
source = source.replace('for _ in range(400000):', 'for _ in range(600000):')
source = source.replace('m[0x11]==128 and m[0x13]==120',
                        'm[0x11]==224 and m[0x13]==24')
source = source.replace('m.ppu[-32:]', 'm.ppu[4096:4128]')

# V4 intentionally replaces the old projectile-reflection assertions.  Retain
# all other boot, palette, control, rendering and stability regression checks.
old_start = source.index('# Ship and shots reflect')
old_end = source.index('# Rendering exposes', old_start)
source = source[:old_start] + source[old_end:]
exec(compile(source, str(P / 'test_omega_base_v1.py'), 'exec'))

# Static 32x28 outer border and centered 14x10 middle box.
nm,nc = boot()
nt = nm.ppu[4128:5152]
assert len(nt) == 1024
assert nt[1*32+0] == 0x90 and nt[1*32+31] == 0x93
assert nt[28*32+0] == 0x97 and nt[28*32+31] == 0x95
assert all(nt[1*32+x] == 0x91 for x in range(1,31))
assert all(nt[28*32+x] == 0x96 for x in range(1,31))
assert nt[10*32+9] == 0x90 and nt[10*32+22] == 0x93
assert nt[19*32+9] == 0x97 and nt[19*32+22] == 0x95
assert not any(nt[960:1024])
print('PASS 32x28 outer border and centered 14x10 middle box nametable')

# Player reflects at the enlarged eight-pixel middle-box envelope and halves
# the complete velocity vector on every face.  1.0/-1.0 becomes 0.5/-0.5.
for x,y,vx,vy,expect_x,expect_y,expect_velocity in (
    (63,100,1,1,64,101,[0x80,0xff,0x80,0x00]),
    (185,100,0xff,1,184,101,[0x80,0x00,0x80,0x00]),
    (100,71,1,1,101,72,[0x80,0x00,0x80,0xff]),
    (100,161,1,0xff,101,160,[0x80,0x00,0x80,0x00]),
):
    mm,cc=boot();mm[0x11]=x;mm[0x13]=y;mm[0x14]=0;mm[0x15]=vx
    mm[0x16]=0;mm[0x17]=vy;call(mm,cc,'physics')
    assert (mm[0x11],mm[0x13])==(expect_x,expect_y), \
        ('ship position',x,y,mm[0x11],mm[0x13])
    assert mm[0x14:0x18]==expect_velocity, \
        ('ship velocity',x,y,mm[0x14:0x18])
print('PASS Player One reflects and loses half speed at all middle-box faces')

# Outer boundaries also halve both components after reflection.
for x,y,vx,vy,expect_velocity in (
    (248,100,1,1,[0x80,0xff,0x80,0x00]),
    (0,100,0xff,1,[0x80,0x00,0x80,0x00]),
    (100,222,1,1,[0x80,0x00,0x80,0xff]),
    (100,12,1,0xff,[0x80,0x00,0x80,0x00]),
):
    mm,cc=boot();mm[0x11]=x;mm[0x13]=y;mm[0x14]=0;mm[0x15]=vx
    mm[0x16]=0;mm[0x17]=vy;call(mm,cc,'physics')
    assert mm[0x14:0x18]==expect_velocity, \
        ('outer velocity',x,y,mm[0x14:0x18])
print('PASS Player One loses half speed at all four outer boundaries')

# Clear-space flight preserves the complete fixed-point velocity exactly.
mm,cc=boot();mm[0x11]=30;mm[0x13]=40;mm[0x14:0x18]=[0x55,0x01,0xaa,0xfe]
for _ in range(20):
    before=mm[0x14:0x18]
    call(mm,cc,'physics')
    assert mm[0x14:0x18]==before
print('PASS flight has no passive friction or velocity decay')

# A flying projectile has unlimited lifetime.  Hundreds of clear-space frames
# must leave it live and in normal (non-explosion) state.
mm,cc=boot();mm[0x600]=0xff;mm[0x602]=30;mm[0x604]=40
for _ in range(300): call(mm,cc,'bullets')
assert mm[0x600]==0xff and mm[0x609]==0
print('PASS live projectiles have no distance or lifetime limit')

# Contact with every outer or middle-box face starts the existing impact
# explosion, freezes the shot, and frees the slot after its 15-frame sequence.
wall_cases = (
    (252,100,1,0), (0,100,0xff,0), (100,226,0,1), (100,16,0,0xff),
    (67,100,1,0), (185,100,0xff,0), (100,75,0,1), (100,161,0,0xff),
)
for x,y,vx,vy in wall_cases:
    mm,cc=boot();mm[0x600]=0xff;mm[0x602]=x;mm[0x604]=y
    mm[0x605]=0;mm[0x606]=vx;mm[0x607]=0;mm[0x608]=vy
    call(mm,cc,'bullets')
    assert mm[0x600]==15 and mm[0x609]==1, \
        ('impact state',x,y,mm[0x600],mm[0x609])
    assert mm[0x605:0x609]==[0,0,0,0]
    call(mm,cc,'render')
    assert mm[0x205] in range(0x1b,0x20)
    for _ in range(15): call(mm,cc,'bullets')
    assert mm[0x600]==0 and mm[0x609]==0
print('PASS wall impacts animate, stop, disappear, and release their shot slots')

# Only Player One keeps the V3 top-origin correction.
mm,cc=boot();mm[0x13]=12;mm[0x16]=0;mm[0x17]=0xff
call(mm,cc,'physics')
assert mm[0x13]==12 and mm[0x17]==0
print('PASS Player One top-wall origin remains four pixels closer')
