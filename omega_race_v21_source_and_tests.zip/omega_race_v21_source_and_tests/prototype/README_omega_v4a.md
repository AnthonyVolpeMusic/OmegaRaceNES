# Omega Race NES – Version 4A test build

- Preserves Version 4 as the previous stable checkpoint.
- Moves Player One's top-border rebound two pixels north, from Y=$0C to Y=$0A.
- Moves missile top-border impact six pixels north, from Y=$10 to Y=$0A.
- All other Version 4 graphics, geometry, physics, projectile behavior,
  controls, palettes, and sounds remain unchanged.
