"""Install the corrected Omega Race colon glyph."""

tile(0x8A, omega_colon_tile18)
