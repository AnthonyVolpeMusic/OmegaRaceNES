# Omega Race NES — Version 7B drone collision and scoring

Baseline: Version 7A's seven widened personal clockwise racing lines, half-speed
drone movement, player controls, arena, graphics, audio and event-driven HUD.

- Player projectiles collide with each live 8x8 drone using a 4x4 projectile
  hitbox and an 8x8 drone hitbox.
- A hit deactivates exactly one drone immediately.
- Each destroyed drone awards exactly 1,000 points.
- The projectile becomes the existing stationary 15-frame wall-impact
  explosion and is relocated to the destroyed drone's position.
- A projectile cannot destroy or score more than one drone in a frame.
- The six score tiles are marked dirty only when a drone is destroyed; normal
  frames perform no score nametable writes.
- Destroyed drones are hidden and stop consuming movement updates.
- Player/drone contact remains inactive for this build.

Build: `python3 prototype/build_omega_base_v7b.py`

Test: `python3 prototype/test_omega_v7b.py`

Dependencies: Python 3, Pillow and py65.
