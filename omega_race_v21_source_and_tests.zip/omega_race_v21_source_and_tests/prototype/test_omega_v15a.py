"""Machine-code regression tests for Omega Race Version 15A."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v14.py').read_text()
text = text.replace('Version 14', 'Version 15A')
text = text.replace('omega_race_v14.nes', 'omega_race_v15a.nes')
text = text.replace('symbols_omega_v14.json', 'symbols_omega_v15a.json')
text = text.replace('prototype_omega_v14.asm', 'prototype_omega_v15a.asm')
exec(compile(text, str(P / 'test_omega_v14.py'), 'exec'))


voice1_notes = [
    (0x07E,4),(0x077,5),(0x07E,4),(0x077,5),(0x06A,18),(0x09F,36),
    (0x07E,4),(0x077,5),(0x07E,4),(0x077,5),(0x06A,18),(0x09F,36),
    (0x07E,4),(0x077,5),(0x07E,4),(0x077,5),(0x06A,18),(0x09F,36),
    (0x07E,4),(0x077,5),(0x07E,4),(0x077,5),(0x08E,54),
]
voice2_notes = [
    (0x23A,9),(0x2A6,9),(0x280,18),(0x356,36),
    (0x23A,9),(0x2A6,9),(0x280,18),(0x356,36),
    (0x23A,9),(0x2A6,9),(0x280,18),(0x356,36),
    (0x3F8,9),(0x3BF,9),(0x356,54),
]


def expand(notes):
    return [period for period, duration in notes for _ in range(duration)]


# Arm a wave clear behind the final 16-frame drone destruction cue.
mm, cc = boot()
for address in range(0x300, 0x400, 0x10):
    mm[address + 5] = 0
call(mm, cc, 'omega_pulse1_start14', a=3)
call(mm, cc, 'omega_wave_check9')
assert mm[0xC7] == 1 and (mm[0xC6], mm[0xC5]) == (1, 0x30)
for remaining in range(15, 0, -1):
    call(mm, cc, 'sfx_tick25')
    call(mm, cc, 'pulse2_tick26')
    assert mm[0xD7] == 1 and mm[0x82] == remaining
call(mm, cc, 'sfx_tick25')
call(mm, cc, 'pulse2_tick26')
assert mm[0xD7] == 0xFF and mm[0xD8] == 1
print('PASS slower tune still waits for the complete destruction cue')


# Capture every sounding frame and verify both voices against the revised score.
voice1 = [mm[0x4002] | ((mm[0x4003] & 7) << 8)]
voice2 = [mm[0x4006] | ((mm[0x4007] & 7) << 8)]
for _ in range(287):
    call(mm, cc, 'sfx_tick25')
    call(mm, cc, 'pulse2_tick26')
    assert mm[0xD7] == 0xFF
    voice1.append(mm[0x4002] | ((mm[0x4003] & 7) << 8))
    voice2.append(mm[0x4006] | ((mm[0x4007] & 7) << 8))
assert voice1 == expand(voice1_notes)
assert voice2 == expand(voice2_notes)
assert len(voice1) == len(voice2) == 288
assert mm[0xD8] == 0x20 and mm[0xD9] == 24 and mm[0xDB] == 15
print('PASS 4/5-frame sixteenths and 9/18/36/54-frame notes match exactly')


# The following tick silences both pulse channels without clipping frame 288.
call(mm, cc, 'sfx_tick25')
call(mm, cc, 'pulse2_tick26')
assert mm[0xD7] == 0 and not (mm[0x86] & 3)
assert (mm[0x4000] & 15) == 0 and (mm[0x4004] & 15) == 0
print('PASS both sustained final notes receive their full 54 frames')


# Simulate the entire intermission. The song occupies exactly 288 frames after
# its 16-frame lead-in and the board advances only after both voices stop.
mm, cc = boot()
for address in range(0x300, 0x400, 0x10):
    mm[address + 5] = 0
call(mm, cc, 'omega_pulse1_start14', a=3)
call(mm, cc, 'omega_wave_check9')
active_frames = 0
for _ in range(304):
    call(mm, cc, 'sfx_tick25')
    call(mm, cc, 'pulse2_tick26')
    active_frames += mm[0xD7] == 0xFF
    call(mm, cc, 'omega_wave_delay9')
assert active_frames == 288
assert mm[0xC0] == 2 and mm[0xC7] == 0 and mm[0xD7] == 0
assert (mm[0x4000] & 15) == 0 and (mm[0x4004] & 15) == 0
print('PASS the minimally extended 304-frame intermission never clips the song')

print('PASS Omega Race Version 15A slower-song regression suite')
