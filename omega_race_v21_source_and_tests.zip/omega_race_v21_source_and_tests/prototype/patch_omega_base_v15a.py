"""Version 15A: slower level-clear song tempo."""

code = '\n'.join(lines)

# The slower 288-frame song begins after the 16-frame destruction cue. Extend
# the intermission by four frames so both voices finish before Level 2 setup.
old = '''LDA #$2C
STA $C5
LDA #$01
STA $C6'''
new = '''LDA #$30
STA $C5
LDA #$01
STA $C6'''
assert code.count(old) == 1
code = code.replace(old, new, 1)
lines = [s.strip() for s in code.splitlines() if s.strip()]

# Four sixteenths alternate 4/5/4/5 frames, totaling one 18-frame quarter.
voice1_durations = [
    4,5,4,5,18,36,
    4,5,4,5,18,36,
    4,5,4,5,18,36,
    4,5,4,5,54,
]
voice2_durations = [
    9,9,18,36,
    9,9,18,36,
    9,9,18,36,
    9,9,54,
]
assert len(voice1_durations) == len(data['omega_clear_voice1_duration15'])
assert len(voice2_durations) == len(data['omega_clear_voice2_duration15'])
assert sum(voice1_durations) == 288
assert sum(voice2_durations) == 288
data['omega_clear_voice1_duration15'] = voice1_durations
data['omega_clear_voice2_duration15'] = voice2_durations

# Change the active-song terminal count from 192 to 288. Because the frame
# counter is one byte, use $D9 as a one-bit page counter only after all Voice 1
# notes have been loaded; the Voice 1 note index naturally ends at 23.
code = '\n'.join(lines)
old = '''omega_level_song_active15:
LDA $D8
CMP #$C0
BEQ omega_level_song_stop15
LDA $DA'''
new = '''omega_level_song_active15:
LDA $D9
CMP #$18
BCC omega_level_song_time_ok15
LDA $D8
CMP #$20
BEQ omega_level_song_stop15
omega_level_song_time_ok15:
LDA $DA'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# $D8 wraps after frame 255. At that point increment the completed Voice 1
# index from 23 to 24, providing the high-page marker used above.
old = '''DEC $DC
INC $D8
omega_level_song_return15:'''
new = '''DEC $DC
INC $D8
BNE omega_level_song_return15
INC $D9
omega_level_song_return15:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)
lines = [s.strip() for s in code.splitlines() if s.strip()]
