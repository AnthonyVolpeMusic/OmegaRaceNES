"""Omega Race V3 bordered arena and central-box collision patch."""

code = '\n'.join(lines)

# Build the 32x30 nametable.  Rows 1..28 are the television-safe 32x28 area.
# The central 12x8 box occupies columns 10..21 and rows 11..18.
omega_nt = bytearray(1024)
TL, TOP, LEFT, TR, RIGHT, BR, BOTTOM, BL = range(0x90, 0x98)

def omega_box(x0, y0, width, height):
    x1, y1 = x0 + width - 1, y0 + height - 1
    omega_nt[y0 * 32 + x0] = TL
    omega_nt[y0 * 32 + x1] = TR
    omega_nt[y1 * 32 + x0] = BL
    omega_nt[y1 * 32 + x1] = BR
    for x in range(x0 + 1, x1):
        omega_nt[y0 * 32 + x] = TOP
        omega_nt[y1 * 32 + x] = BOTTOM
    for y in range(y0 + 1, y1):
        omega_nt[y * 32 + x0] = LEFT
        omega_nt[y * 32 + x1] = RIGHT

omega_box(0, 1, 32, 28)
omega_box(10, 11, 12, 8)
data['omega_nt0_v3'] = omega_nt[:256]
data['omega_nt1_v3'] = omega_nt[256:512]
data['omega_nt2_v3'] = omega_nt[512:768]
data['omega_nt3_v3'] = omega_nt[768:]

# Load the static playfield while rendering is still disabled.
loader = '''JMP main
omega_load_playfield_v3:
LDA #$20
STA $2006
LDA #$00
STA $2006
LDX #$00
omega_load_nt0_v3:
LDA omega_nt0_v3,X
STA $2007
INX
BNE omega_load_nt0_v3
LDX #$00
omega_load_nt1_v3:
LDA omega_nt1_v3,X
STA $2007
INX
BNE omega_load_nt1_v3
LDX #$00
omega_load_nt2_v3:
LDA omega_nt2_v3,X
STA $2007
INX
BNE omega_load_nt2_v3
LDX #$00
omega_load_nt3_v3:
LDA omega_nt3_v3,X
STA $2007
INX
BNE omega_load_nt3_v3
RTS
'''
assert code.count('main:\n') == 1
code = code.replace('main:\n', loader + 'main:\n', 1)

old = '''LDA #$01
STA $06
STA $8E
LDA #$80
STA $11
LDA #$78
STA $13'''
new = '''JSR omega_load_playfield_v3
LDA #$01
STA $06
STA $8E
LDA #$E0
STA $11
LDA #$18
STA $13'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Player One's triangular artwork has four transparent rows at its upper
# extent in some headings.  Give only the ship a $0C top origin so its visible
# pixels meet the top border; every other actor retains the inherited $10
# upper-playfield limit.  $8F/$90 identify the ship's $0010 position record.
old = '''LDA #$10
STA $91
LDA #$02
STA $93'''
new = '''LDA #$10
LDY $90
BNE omega_y_low_ready_v3
LDY $8F
CPY #$10
BNE omega_y_low_ready_v3
LDA #$0C
omega_y_low_ready_v3:
STA $91
LDA #$02
STA $93'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Add central-box reflection after the inherited outer-boundary reflection.
old = '''JSR bounce_step31
LDX $9B
RTS
shot_bounce31:'''
new = '''JSR bounce_step31
JSR omega_ship_box_v3
LDX $9B
RTS
shot_bounce31:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''JSR bounce_step31
LDX $9B
RTS
rock0300_bounce31:'''
new = '''JSR bounce_step31
JSR omega_shot_box_v3
LDX $9B
RTS
rock0300_bounce31:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

box_code = '''omega_ship_box_v3:
LDA $11
CMP #$48
BCC omega_ship_box_done_v3
CMP #$B1
BCS omega_ship_box_done_v3
LDA $13
CMP #$50
BCC omega_ship_box_done_v3
CMP #$99
BCS omega_ship_box_done_v3
LDA #$00
STA $9E
LDA $11
CMP #$50
BCC omega_ship_hit_left_v3
CMP #$A8
BCS omega_ship_hit_right_v3
JMP omega_ship_box_y_v3
omega_ship_hit_left_v3:
INC $9E
LDA #$48
STA $11
LDA $15
BMI omega_ship_box_y_v3
JSR omega_reverse_ship_x_v3
JMP omega_ship_box_y_v3
omega_ship_hit_right_v3:
INC $9E
LDA #$B0
STA $11
LDA $15
BPL omega_ship_box_y_v3
JSR omega_reverse_ship_x_v3
omega_ship_box_y_v3:
LDA $13
CMP #$58
BCC omega_ship_hit_top_v3
CMP #$90
BCS omega_ship_hit_bottom_v3
LDA $9E
BNE omega_ship_box_done_v3
LDA #$50
STA $13
LDA $17
BMI omega_ship_box_done_v3
JSR omega_reverse_ship_y_v3
RTS
omega_ship_hit_top_v3:
LDA #$50
STA $13
LDA $17
BMI omega_ship_box_done_v3
JSR omega_reverse_ship_y_v3
RTS
omega_ship_hit_bottom_v3:
LDA #$98
STA $13
LDA $17
BPL omega_ship_box_done_v3
JSR omega_reverse_ship_y_v3
omega_ship_box_done_v3:
RTS
omega_reverse_ship_x_v3:
LDA #$00
SEC
SBC $14
STA $14
LDA #$00
SBC $15
STA $15
RTS
omega_reverse_ship_y_v3:
LDA #$00
SEC
SBC $16
STA $16
LDA #$00
SBC $17
STA $17
RTS
omega_shot_box_v3:
LDA $0602,X
CMP #$4C
BCC omega_shot_box_done_v3
CMP #$B1
BCS omega_shot_box_done_v3
LDA $0604,X
CMP #$54
BCC omega_shot_box_done_v3
CMP #$99
BCS omega_shot_box_done_v3
LDA #$00
STA $9E
LDA $0602,X
CMP #$50
BCC omega_shot_hit_left_v3
CMP #$AC
BCS omega_shot_hit_right_v3
JMP omega_shot_box_y_v3
omega_shot_hit_left_v3:
INC $9E
LDA #$4C
STA $0602,X
LDA $0606,X
BMI omega_shot_box_y_v3
JSR omega_reverse_shot_x_v3
JMP omega_shot_box_y_v3
omega_shot_hit_right_v3:
INC $9E
LDA #$B0
STA $0602,X
LDA $0606,X
BPL omega_shot_box_y_v3
JSR omega_reverse_shot_x_v3
omega_shot_box_y_v3:
LDA $0604,X
CMP #$58
BCC omega_shot_hit_top_v3
CMP #$94
BCS omega_shot_hit_bottom_v3
LDA $9E
BNE omega_shot_box_done_v3
LDA #$54
STA $0604,X
LDA $0608,X
BMI omega_shot_box_done_v3
JSR omega_reverse_shot_y_v3
RTS
omega_shot_hit_top_v3:
LDA #$54
STA $0604,X
LDA $0608,X
BMI omega_shot_box_done_v3
JSR omega_reverse_shot_y_v3
RTS
omega_shot_hit_bottom_v3:
LDA #$98
STA $0604,X
LDA $0608,X
BPL omega_shot_box_done_v3
JSR omega_reverse_shot_y_v3
omega_shot_box_done_v3:
RTS
omega_reverse_shot_x_v3:
LDA #$00
SEC
SBC $0605,X
STA $0605,X
LDA #$00
SBC $0606,X
STA $0606,X
RTS
omega_reverse_shot_y_v3:
LDA #$00
SEC
SBC $0607,X
STA $0607,X
LDA #$00
SBC $0608,X
STA $0608,X
RTS
'''
assert code.count('rock0300_bounce31:\n') == 1
code = code.replace('rock0300_bounce31:\n', box_code + 'rock0300_bounce31:\n', 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]
