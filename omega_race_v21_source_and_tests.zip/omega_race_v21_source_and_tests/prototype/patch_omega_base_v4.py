"""Omega Race V4 gameplay patch layered on the stable V3 arena."""

code = '\n'.join(lines)

# Replace the 12x8 central box with a centered 14x10 box.  The television-safe
# outer border remains exactly as it was in V3.
omega_nt = bytearray(1024)
TL, TOP, LEFT, TR, RIGHT, BR, BOTTOM, BL = range(0x90, 0x98)

def omega_box_v4(x0, y0, width, height):
    x1, y1 = x0 + width - 1, y0 + height - 1
    omega_nt[y0 * 32 + x0] = TL
    omega_nt[y0 * 32 + x1] = TR
    omega_nt[y1 * 32 + x0] = BL
    omega_nt[y1 * 32 + x1] = BR
    for x in range(x0 + 1, x1):
        omega_nt[y0 * 32 + x] = TOP
        omega_nt[y1 * 32 + x] = BOTTOM
    for y in range(y0 + 1, y1):
        omega_nt[y * 32 + x0] = LEFT
        omega_nt[y * 32 + x1] = RIGHT

omega_box_v4(0, 1, 32, 28)
omega_box_v4(9, 10, 14, 10)
data['omega_nt0_v3'] = omega_nt[:256]
data['omega_nt1_v3'] = omega_nt[256:512]
data['omega_nt2_v3'] = omega_nt[512:768]
data['omega_nt3_v3'] = omega_nt[768:]

# A live projectile never ages out.  $0600 remains $FF until an impact changes
# it to the existing 15-frame explosion countdown.
old = '''bullet_flying:
DEC $0600,X
LDA $8E'''
new = '''bullet_flying:
LDA $8E'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Both the ordinary fire path and the dormant four-shot setup use unlimited
# live-shot state, so a future control change cannot silently restore range.
assert code.count('LDA #$30\nSTA $0600,X') == 2
code = code.replace('LDA #$30\nSTA $0600,X',
                    'LDA #$FF\nSTA $0600,X')

# Detect an inherited outer-wall reflection, halve Player One's complete
# velocity vector once, then test the enlarged middle box.  The reflection is
# already complete when $98 is nonzero.
old = '''JSR bounce_step31
JSR omega_ship_box_v3
LDX $9B
RTS
shot_bounce31:'''
new = '''JSR bounce_step31
LDA $98
BEQ omega_ship_outer_done_v4
JSR omega_halve_ship_speed_v4
omega_ship_outer_done_v4:
JSR omega_ship_box_v4
LDX $9B
RTS
shot_bounce31:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Projectiles use the inherited movement precision and outer limits, but any
# detected wall contact now starts the existing impact explosion instead of
# reflecting.  The middle box performs the same terminal impact test.
old = '''JSR bounce_step31
JSR omega_shot_box_v3
LDX $9B
RTS
omega_ship_box_v3:'''
new = '''JSR bounce_step31
LDA $98
BNE omega_shot_explode_v4
JSR omega_shot_box_v4
LDX $9B
RTS
omega_shot_explode_v4:
LDA #$0F
STA $0600,X
LDA #$01
STA $0609,X
LDA #$00
STA $0605,X
STA $0606,X
STA $0607,X
STA $0608,X
LDX $9B
RTS
omega_ship_box_v3:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Replace V3's middle-box helpers.  The 14x10 visual box spans tile columns
# 9..22 and rows 10..19.  Player origin limits are shifted eight pixels on all
# four approaches: X=$40/$B8 and Y=$48/$A0.  A collision reflects first, then
# halves both velocity components exactly once.  Shots explode on contact.
start = code.index('omega_ship_box_v3:')
end = code.index('rock0300_bounce31:', start)
box_code = '''omega_ship_box_v4:
LDA $11
CMP #$40
BCC omega_ship_box_done_v4
CMP #$B9
BCS omega_ship_box_done_v4
LDA $13
CMP #$48
BCC omega_ship_box_done_v4
CMP #$A1
BCS omega_ship_box_done_v4
LDA #$00
STA $9E
LDA $11
CMP #$48
BCC omega_ship_hit_left_v4
CMP #$B0
BCS omega_ship_hit_right_v4
JMP omega_ship_box_y_v4
omega_ship_hit_left_v4:
INC $9E
LDA #$40
STA $11
LDA $15
BMI omega_ship_box_y_v4
JSR omega_reverse_ship_x_v4
JMP omega_ship_box_y_v4
omega_ship_hit_right_v4:
INC $9E
LDA #$B8
STA $11
LDA $15
BPL omega_ship_box_y_v4
JSR omega_reverse_ship_x_v4
omega_ship_box_y_v4:
LDA $13
CMP #$50
BCC omega_ship_hit_top_v4
CMP #$98
BCS omega_ship_hit_bottom_v4
LDA $9E
BNE omega_ship_box_hit_v4
LDA #$48
STA $13
LDA $17
BMI omega_ship_box_done_v4
JSR omega_reverse_ship_y_v4
JMP omega_ship_box_hit_v4
omega_ship_hit_top_v4:
LDA #$48
STA $13
LDA $17
BMI omega_ship_box_hit_v4
JSR omega_reverse_ship_y_v4
JMP omega_ship_box_hit_v4
omega_ship_hit_bottom_v4:
LDA #$A0
STA $13
LDA $17
BPL omega_ship_box_hit_v4
JSR omega_reverse_ship_y_v4
omega_ship_box_hit_v4:
JSR omega_halve_ship_speed_v4
omega_ship_box_done_v4:
RTS
omega_reverse_ship_x_v4:
LDA #$00
SEC
SBC $14
STA $14
LDA #$00
SBC $15
STA $15
RTS
omega_reverse_ship_y_v4:
LDA #$00
SEC
SBC $16
STA $16
LDA #$00
SBC $17
STA $17
RTS
omega_halve_ship_speed_v4:
LDA $15
CMP #$80
ROR A
STA $15
ROR $14
LDA $17
CMP #$80
ROR A
STA $17
ROR $16
RTS
omega_shot_box_v4:
LDA $0602,X
CMP #$44
BCC omega_shot_box_done_v4
CMP #$B9
BCS omega_shot_box_done_v4
LDA $0604,X
CMP #$4C
BCC omega_shot_box_done_v4
CMP #$A1
BCS omega_shot_box_done_v4
JMP omega_shot_explode_v4
omega_shot_box_done_v4:
RTS
'''
code = code[:start] + box_code + code[end:]

lines = [s.strip() for s in code.splitlines() if s.strip()]
