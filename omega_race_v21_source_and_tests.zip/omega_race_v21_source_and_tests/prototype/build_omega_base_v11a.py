"""Build Omega Race Version 11A from Version 11 with revised Star art."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v11.py').read_text()

needle = r"exec(compile((P/'patch_omega_chr_v11.py').read_text(),str(P/'patch_omega_chr_v11.py'),'exec'))\\noutput=P/'omega_race_v11.nes'"
replacement = needle.replace(
    r"\\noutput=P/'omega_race_v11.nes'",
    r"\\nexec(compile((P/'patch_omega_chr_v11a.py').read_text(),str(P/'patch_omega_chr_v11a.py'),'exec'))\\noutput=P/'omega_race_v11a.nes'",
)
assert recipe.count(needle) == 1
recipe = recipe.replace(needle, replacement, 1)
recipe = recipe.replace('symbols_omega_v11.json', 'symbols_omega_v11a.json')
recipe = recipe.replace('prototype_omega_v11.asm', 'prototype_omega_v11a.asm')
exec(compile(recipe, str(P / 'build_omega_base_v11.py'), 'exec'))
