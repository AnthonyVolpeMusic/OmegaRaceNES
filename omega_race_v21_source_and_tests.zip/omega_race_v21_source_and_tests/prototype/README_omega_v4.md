# Omega Race NES – Version 4 test build

- Preserves Version 3 as the previous stable checkpoint.
- Enlarges the centered middle box from 12×8 to 14×10 tiles.
- Updates the ship collision envelope eight pixels outward around the box.
- Halves both components of Player One's velocity after any outer-wall or
  middle-box collision; velocity otherwise remains unchanged without friction.
- Removes projectile distance/lifetime expiration.
- Projectiles now use the existing impact animation and disappear when they hit
  either the outer wall or the middle box.
- Keeps the four-projectile limit and all established controls, palettes,
  border graphics, and sound behavior.
