"""Machine-code regression tests for Omega Race Version 11."""
from pathlib import Path

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
text = base.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v11.nes')
text = text.replace('symbols_omega_base_v1.json', 'symbols_omega_v11.json')
text = text.replace('range(400000)', 'range(1000000)')
env = {'__file__': str(P / 'test_omega_v11.py')}
exec(compile(text, 'harness', 'exec'), env)
boot, call, CHR, S = env['boot'], env['call'], env['CHR'], env['S']


def chr_pixel(tile, x, y):
    base = (0x100 + tile) * 16
    return ((CHR[base + y] >> (7-x)) & 1) | (((CHR[base + 8 + y] >> (7-x)) & 1) << 1)


def active(mm):
    return [a for a in range(0x300, 0x400, 16) if mm[a + 5]]


frames = [
 ['00021000','00021000','00121100','00122222','22222110','01112110','11112111','11112111'],
 ['00211000','00211000','00121122','00122200','01222110','22112110','11111211','11111211'],
 ['00011000','02011020','00211200','00122100','01122110','01211210','12111121','11111111'],
]
frames.append([row[::-1] for row in frames[1]])
for f, rows in enumerate(frames):
    for y, row in enumerate(rows):
        for x, value in enumerate(row):
            assert chr_pixel(0xE8 + f, x, y) == int(value)
print('PASS all 256 Shooting Star pixels match the supplied four drawings')

# Initial Commanders receive exactly 1,200 active-frame ticks; ordinary drones
# have no conversion timer. The 1,200th tick changes the type in place.
mm, cc = boot()
assert mm[0x306] == 1 and mm[0x308:0x30C] == [0xB0, 0x04, 1, 12]
assert all(mm[a + 8] == 0 and mm[a + 9] == 0 for a in range(0x310, 0x370, 16))
cc.x = 0
for _ in range(1199):
    call(mm, cc, 'omega_commander_tick11')
    cc.x = 0
assert mm[0x306] == 1 and mm[0x308:0x30A] == [1, 0]
call(mm, cc, 'omega_commander_tick11')
assert mm[0x306] == 2 and mm[0x307] == 30 and mm[0x30A:0x30C] == [1, 1]
print('PASS Commander converts in place after exactly 20 seconds / 1,200 active frames')

# Shooting Stars render with the new CHR and the existing Commander palette.
call(mm, cc, 'render')
assert 0xE8 <= mm[0x215] <= 0xEB and mm[0x216] == 1
print('PASS Shooting Star uses its four-frame art and Commander palette')

# A clear upper lane selects direct pursuit and moves toward Player One.
mm, cc = boot()
for a in range(0x300, 0x400, 16):
    mm[a + 5] = 0
mm[0x300:0x30E] = [32, 40, 0, 1, 0xC0, 1, 2, 30, 0, 0, 1, 1, 0, 0]
mm[0x11], mm[0x13] = 220, 40
cc.x = 0
call(mm, cc, 'omega_star_move11')
assert mm[0x30A] == 0 and mm[0x300] > 32 and mm[0x301] == 40
print('PASS clear line of sight selects free pursuit toward Player One')

# A ray through the middle box selects the inherited personal route. Long-run
# motion must remain within the arena and outside the expanded middle boundary.
mm, cc = boot()
for a in range(0x300, 0x400, 16):
    mm[a + 5] = 0
mm[0x300:0x30E] = [32, 176, 0, 1, 0xC0, 1, 2, 30, 0, 0, 0, 1, 0, 0]
mm[0x11], mm[0x13] = 220, 24
cc.x = 0
call(mm, cc, 'omega_star_move11')
assert mm[0x30A] == 1
for _ in range(2400):
    cc.x = 0
    call(mm, cc, 'omega_star_move11')
    x, y = mm[0x300], mm[0x301]
    assert 8 <= x <= 240 and 14 <= y <= 216
    assert not (0x40 <= x <= 0xB8 and 0x48 <= y <= 0xA0)
print('PASS blocked pursuit falls back to the personal route without grinding into the middle box')

# Safety recovery restores the last valid position at both outer and middle
# boundaries and immediately switches back to route recovery.
for record, player in (([8,40,0,1,0xC0,1,2,30,0,0,0,2,0,0], (0,40)),
                       ([63,80,0,1,0xC0,1,2,30,0,0,0,2,0,0], (100,80))):
    mm, cc = boot()
    for a in range(0x300, 0x400, 16):
        mm[a + 5] = 0
    mm[0x300:0x30E] = record
    mm[0x11], mm[0x13] = player
    old = tuple(mm[0x300:0x302])
    cc.x = 0
    call(mm, cc, 'omega_star_move11')
    assert tuple(mm[0x300:0x302]) == old and mm[0x30A] == 1
print('PASS Shooting Star recovers cleanly from outer and middle boundary contact')

# Half-second cadence is exact, line-of-sight gating remains in force and all
# Shooting Stars share the existing six-projectile ceiling.
mm, cc = boot()
for a in range(0x300, 0x400, 16):
    mm[a + 5] = 0
mm[0x300:0x30C] = [32,40,0,1,0,1,2,30,0,0,1,0xFF]
mm[0x11], mm[0x13] = 220, 40
for i in range(8):
    mm[0x400+i] = 32
    mm[0x500+i] = 40
for _ in range(29):
    call(mm, cc, 'drone_tick6')
assert not any(mm[a] for a in range(0x580, 0x5E0, 16))
call(mm, cc, 'drone_tick6')
assert sum(mm[a] != 0 for a in range(0x580, 0x5E0, 16)) == 1
for a in range(0x580, 0x5E0, 16):
    mm[a] = 0
mm[0x300], mm[0x301], mm[0x307] = 32, 176, 1
mm[0x11], mm[0x13] = 220, 24
call(mm, cc, 'drone_tick6')
assert not any(mm[a] for a in range(0x580, 0x5E0, 16))
for a in range(0x580, 0x5E0, 16):
    mm[a] = 0xFF
mm[0x307] = 1
call(mm, cc, 'drone_tick6')
assert sum(mm[a] != 0 for a in range(0x580, 0x5E0, 16)) == 6
print('PASS Shooting Star fires every 30 frames only on clear shots and obeys the six-shot cap')

# Shooting Star destruction awards 2,500 and promotes exactly one surviving
# basic drone, including a fresh Commander conversion timer.
mm, cc = boot()
for a in range(0x300, 0x400, 16):
    mm[a + 5] = 0
mm[0x300:0x307] = [40,40,0,1,0,1,2]
mm[0x310:0x317] = [60,40,0,1,0,1,0]
mm[0x320:0x327] = [80,40,0,1,0,1,0]
mm[0x600], mm[0x602], mm[0x604], mm[0x609] = 0xFF, 40, 40, 0
call(mm, cc, 'drone_collision7b')
assert mm[0x305] == 0 and mm[0x30:0x33] == [0xC4, 0x09, 0]
assert mm[0x33:0x39] == [0,0,2,5,0,0]
promoted = [a for a in active(mm) if mm[a + 6] == 1]
assert len(promoted) == 1 and mm[promoted[0]+8:promoted[0]+10] == [0xB0,0x04]
print('PASS Shooting Star awards 2,500 and promotes exactly one surviving drone')

# With no basic drone remaining, destruction cannot invent a replacement.
mm, cc = boot()
for a in range(0x300, 0x400, 16):
    mm[a + 5] = 0
mm[0x300:0x307] = [40,40,0,1,0,1,2]
mm[0x600], mm[0x602], mm[0x604], mm[0x609] = 0xFF, 40, 40, 0
call(mm, cc, 'drone_collision7b')
assert not active(mm) and mm[0x30:0x33] == [0xC4,0x09,0]
print('PASS no replacement Commander is created when no drone survives')

# Shooting Stars retain normal lethal contact behavior.
mm, cc = boot()
mm[0x306] = 2
mm[0x300], mm[0x301] = mm[0x11], mm[0x13]
call(mm, cc, 'omega_player_collision9')
assert mm[0x677] == 1 and mm[0x3D] == 2
print('PASS direct Shooting Star contact destroys Player One')

# Stress a maximum wave containing several final forms in the real main/NMI
# loop; rendering and the six-shot limit must remain frame-stable.
mm, cc = boot()
mm[0xC0] = 7
call(mm, cc, 'omega_level_setup9')
for a in (0x300,0x310,0x320,0x330):
    mm[a + 6], mm[a + 7], mm[a + 10], mm[a + 11] = 2, 30, 1, 1
mm.ppu = []
mm.pad = 0
cc.pc = S['main']
cc.sp = 255
deadline = cc.processorCycles
for _ in range(360):
    end = deadline + 29781
    while cc.processorCycles < end:
        if cc.processorCycles >= deadline:
            cc.nmi()
            deadline += 29781
        cc.step()
assert 354 <= mm.dmas <= 360, (len(mm.ppu), mm.dmas, cc.pc, mm[0x677], mm[0x3D])
assert len(mm.ppu) <= 8
assert sum(mm[a] != 0 for a in range(0x580,0x5E0,16)) <= 6
print('PASS maximum wave with four Shooting Stars remains stable within the frame budget')
