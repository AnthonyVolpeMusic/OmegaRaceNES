"""Version 11: Commander-to-Shooting-Star final form and hybrid pursuit AI."""

code = '\n'.join(lines)

# Commanders receive a fresh 1,200-frame conversion timer. Byte 10 is the
# Shooting Star movement mode (0 direct, 1 personal route); byte 11 is its
# twelve-frame line-of-sight refresh timer.
old = '''STA $0306,X
LDA $C3
STA $0307,X
JSR drone_assign6'''
new = '''STA $0306,X
LDA $C3
STA $0307,X
LDA $0306,X
BEQ drone_spawn_timer_done11
LDA #$B0
STA $0308,X
LDA #$04
STA $0309,X
drone_spawn_timer_done11:
LDA #$01
STA $030A,X
LDA #$0C
STA $030B,X
JSR drone_assign6'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Type 0 follows its route once, type 1 follows twice and counts down to final
# form, and type 2 uses free pursuit/track-recovery movement with fixed fire.
start = code.index('drone_tick6:')
end = code.index('drone_move6:', start)
tick = '''drone_tick6:
INC $A9
LDA $A9
CMP #$06
BCC drone_tick_start11
LDA #$00
STA $A9
INC $A8
LDA $A8
AND #$03
STA $A8
drone_tick_start11:
LDX #$00
drone_tick_loop11:
LDA $0305,X
BEQ drone_tick_next11
LDA $0306,X
BEQ drone_tick_basic11
CMP #$02
BEQ drone_tick_star11
JSR omega_commander_tick11
LDA $0306,X
CMP #$02
BEQ drone_tick_next11
JSR drone_move6
JSR drone_move6
JMP drone_tick_next11
drone_tick_basic11:
JSR drone_move6
JMP drone_tick_next11
drone_tick_star11:
DEC $0307,X
BNE drone_star_move11
LDA #$1E
STA $0307,X
JSR commander_try_fire8
drone_star_move11:
JSR omega_star_move11
drone_tick_next11:
TXA
CLC
ADC #$10
TAX
BNE drone_tick_loop11
RTS
'''
code = code[:start] + tick + code[end:]

# Select Shooting Star art at $E8-$EB while retaining the Commander palette.
old = '''LDA $0306,X
BEQ drone_render_basic9
LDA #$E4
BNE drone_render_base9
drone_render_basic9:
LDA #$E0'''
new = '''LDA $0306,X
BEQ drone_render_basic9
CMP #$02
BEQ drone_render_star11
LDA #$E4
BNE drone_render_base9
drone_render_star11:
LDA #$E8
BNE drone_render_base9
drone_render_basic9:
LDA #$E0'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Add the 2,500-point Shooting Star branch to enemy destruction.
old = '''LDA $B1
BEQ drone_score_1000_9
LDX #$06
drone_score_1500_loop9:
LDA #$FA
JSR score_add
DEX
BNE drone_score_1500_loop9
JSR commander_promote8
JMP drone_score_done9
drone_score_1000_9:'''
new = '''LDA $B1
BEQ drone_score_1000_9
CMP #$02
BEQ drone_score_2500_11
LDX #$06
drone_score_1500_loop9:
LDA #$FA
JSR score_add
DEX
BNE drone_score_1500_loop9
JSR commander_promote8
JMP drone_score_done9
drone_score_2500_11:
LDX #$0A
drone_score_2500_loop11:
LDA #$FA
JSR score_add
DEX
BNE drone_score_2500_loop11
JSR omega_force_promote11
JMP drone_score_done9
drone_score_1000_9:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Promotion now initializes both the firing and 20-second conversion timers.
old = '''commander_promote_here9:
LDA #$01
STA $0306,X
LDA $C3
STA $0307,X
RTS'''
new = '''commander_promote_here9:
JSR omega_promote_record11
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += '''
omega_promote_record11:
LDA #$01
STA $0306,X
LDA $C3
STA $0307,X
LDA #$B0
STA $0308,X
LDA #$04
STA $0309,X
LDA #$01
STA $030A,X
LDA #$0C
STA $030B,X
RTS

omega_force_promote11:
JSR random
AND #$0F
ASL A
ASL A
ASL A
ASL A
TAX
LDA #$10
STA $B2
omega_force_scan11:
LDA $0305,X
BEQ omega_force_next11
LDA $0306,X
BEQ omega_force_here11
omega_force_next11:
TXA
CLC
ADC #$10
TAX
DEC $B2
BNE omega_force_scan11
RTS
omega_force_here11:
JSR omega_promote_record11
RTS

omega_commander_tick11:
LDA $0308,X
BNE omega_commander_timer_low11
LDA $0309,X
BEQ omega_commander_convert11
DEC $0309,X
LDA #$FF
STA $0308,X
JMP omega_commander_timer_check11
omega_commander_timer_low11:
DEC $0308,X
omega_commander_timer_check11:
LDA $0308,X
ORA $0309,X
BEQ omega_commander_convert11
DEC $0307,X
BNE omega_commander_tick_done11
LDA $C3
STA $0307,X
JSR commander_try_fire8
omega_commander_tick_done11:
RTS
omega_commander_convert11:
LDA #$02
STA $0306,X
LDA #$1E
STA $0307,X
LDA #$01
STA $030A,X
STA $030B,X
JSR drone_assign6
RTS

omega_star_move11:
LDA $0300,X
STA $030C,X
LDA $0301,X
STA $030D,X
DEC $030B,X
BNE omega_star_mode11
LDA #$0C
STA $030B,X
STX $B1
JSR commander_heading8
STA $B2
JSR commander_los8
STA $AA
LDX $B1
LDA $AA
BEQ omega_star_blocked11
LDA #$00
STA $030A,X
JMP omega_star_mode11
omega_star_blocked11:
LDA $030A,X
BNE omega_star_mode11
LDA #$01
STA $030A,X
JSR drone_assign6
omega_star_mode11:
LDA $030A,X
BNE omega_star_route11
LDA $11
STA $AB
LDA $13
STA $AC
JSR omega_star_step11
JSR omega_star_step11
JMP omega_star_bounds11
omega_star_route11:
JSR drone_move6
JSR drone_move6
omega_star_bounds11:
LDA $0300,X
CMP #$08
BCC omega_star_restore11
CMP #$F1
BCS omega_star_restore11
LDA $0301,X
CMP #$0E
BCC omega_star_restore11
CMP #$D9
BCS omega_star_restore11
LDA $0300,X
CMP #$40
BCC omega_star_move_done11
CMP #$B9
BCS omega_star_move_done11
LDA $0301,X
CMP #$48
BCC omega_star_move_done11
CMP #$A1
BCS omega_star_move_done11
omega_star_restore11:
LDA $030C,X
STA $0300,X
LDA $030D,X
STA $0301,X
LDA #$01
STA $030A,X
JSR drone_assign6
omega_star_move_done11:
RTS

omega_star_step11:
LDY $C4
LDA omega_speed_cardinal9,Y
STA $AA
LDA $0300,X
CMP $AB
BEQ omega_star_fraction11
LDA $0301,X
CMP $AC
BEQ omega_star_fraction11
LDA omega_speed_diagonal9,Y
STA $AA
omega_star_fraction11:
LDA $0304,X
CLC
ADC $AA
STA $0304,X
BCC omega_star_step_done11
LDA $0300,X
CMP $AB
BEQ omega_star_step_y11
BCC omega_star_step_right11
DEC $0300,X
JMP omega_star_step_y11
omega_star_step_right11:
INC $0300,X
omega_star_step_y11:
LDA $0301,X
CMP $AC
BEQ omega_star_step_done11
BCC omega_star_step_down11
DEC $0301,X
RTS
omega_star_step_down11:
INC $0301,X
omega_star_step_done11:
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]
