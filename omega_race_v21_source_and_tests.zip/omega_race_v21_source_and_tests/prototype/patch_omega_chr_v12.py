"""Version 12: Anthony's exact 8x8 land-mine tile at sprite tile $EC."""

# 0 transparent ($08), 1 red ($16), 3 orange ($38).
land_mine = [
    '00010000',
    '00111000',
    '00131000',
    '01131100',
    '01333100',
    '11333110',
    '11111110',
    '00000000',
]
assert len(land_mine) == 8 and all(len(row) == 8 for row in land_mine)
tile(0x1EC, [[int(value) for value in row] for row in land_mine])
