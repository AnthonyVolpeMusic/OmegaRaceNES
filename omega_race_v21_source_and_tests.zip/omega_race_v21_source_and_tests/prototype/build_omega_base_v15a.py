"""Build Omega Race Version 15A with the slower level-clear song."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v15.py').read_text()

base_v15 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v15.py').read_text(),str(P/'patch_omega_base_v15.py'),'exec'))\\n" + marker)'''
base_v15a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v15a.py').read_text(),str(P/'patch_omega_base_v15a.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v15) == 1
recipe = recipe.replace(base_v15, base_v15 + '\n' + base_v15a, 1)

recipe = recipe.replace('omega_race_v15.nes', 'omega_race_v15a.nes')
recipe = recipe.replace('symbols_omega_v15.json', 'symbols_omega_v15a.json')
recipe = recipe.replace('prototype_omega_v15.asm', 'prototype_omega_v15a.asm')
exec(compile(recipe, str(P / 'build_omega_base_v15.py'), 'exec'))
