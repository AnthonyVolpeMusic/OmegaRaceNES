# Omega Race NES — Version 13 life and round timing

Baseline: Version 12B.

- Every life and level now begins with three supers instead of five.
- Player One's projectiles and the enemy action continue after Player One dies.
- The restart countdown waits until all Player One projectile records—including
  wall-impact animations—have disappeared.
- With lives remaining, a full two-second delay follows before the level is
  rebuilt.
- With no lives remaining, the arena freezes after the final Player One shot
  disappears, reserving the state for a future Game Over screen.
- Initial play, respawns and new levels all begin with a fully frozen two-second
  ship flash: ten frames visible and ten frames hidden, repeated six times.

Build: `python3 prototype/build_omega_base_v13.py`

Test: `python3 prototype/test_omega_v13.py`
