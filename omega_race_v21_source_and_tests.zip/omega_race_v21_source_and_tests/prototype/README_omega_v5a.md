# Omega Race NES – Version 5A event-driven HUD

- Preserves the centered Version 5 HUD and the completed Version 4 gameplay
  baseline.
- Removes unconditional per-frame HUD tile writes.
- Refreshes the supers digit once, during the next vertical blank, whenever a
  super is consumed.
- Provides dormant event hooks for the future enemy-score and player-death
  systems; score and lives are not rewritten until those hooks are requested.
- Coalesces simultaneous score, supers, and lives events into one safe vblank
  update.
