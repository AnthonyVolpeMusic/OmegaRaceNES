"""Omega Race Version 17B: clean black title screen without sprite debris."""

code = '\n'.join(lines)

# The inherited Asteroids title renderer interprets Omega Race's seven live
# enemy records as decorative asteroid sprites.  The common renderer has
# already hidden all 64 OAM entries before reaching this label, so title mode
# should simply return and leave the screen sprite-free.
start = code.index('render_title:\n')
end = code.index('ship_bounce31:\n', start)
code = code[:start] + '''render_title:
RTS
''' + code[end:]

lines = [s.strip() for s in code.splitlines() if s.strip()]

# NES palette addresses $3F10/$14/$18/$1C mirror the four background-color
# entries.  Make every universal/mirrored startup entry true black so later
# sprite-palette writes cannot turn the title backdrop back to $08 pea green.
for index in (0, 4, 8, 12, 16, 20, 24, 28):
    data['palette'][index] = 0x0F
