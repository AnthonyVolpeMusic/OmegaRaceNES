"""Version 11B: fixed 1.5-pixel-per-frame Shooting Star movement."""

code = '\n'.join(lines)

# A Shooting Star takes two 0.75-pixel steps per active frame.  $C0 is 0.75
# in 8.8 fixed point; $88 is the diagonal component, preserving a true
# approximately 1.5-pixel resultant speed rather than making diagonals faster.
old = '''omega_star_route11:
JSR drone_move6
JSR drone_move6
omega_star_bounds11:'''
new = '''omega_star_route11:
JSR omega_star_route_step11b
JSR omega_star_route_step11b
omega_star_bounds11:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''omega_star_step11:
LDY $C4
LDA omega_speed_cardinal9,Y
STA $AA
LDA $0300,X
CMP $AB
BEQ omega_star_fraction11
LDA $0301,X
CMP $AC
BEQ omega_star_fraction11
LDA omega_speed_diagonal9,Y
STA $AA'''
new = '''omega_star_step11:
LDA #$C0
STA $AA
LDA $0300,X
CMP $AB
BEQ omega_star_fraction11
LDA $0301,X
CMP $AC
BEQ omega_star_fraction11
LDA #$88
STA $AA'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += '''
omega_star_route_step11b:
LDY $0302,X
STY $AF
TXA
LSR A
CLC
ADC $AF
TAY
LDA $0400,Y
STA $AB
LDA $0500,Y
STA $AC
LDA $0300,X
CMP $AB
BNE omega_star_route_step_move11b
LDA $0301,X
CMP $AC
BNE omega_star_route_step_move11b
LDA $0302,X
CLC
ADC $0303,X
AND #$07
STA $0302,X
TAY
STY $AF
TXA
LSR A
CLC
ADC $AF
TAY
LDA $0400,Y
STA $AB
LDA $0500,Y
STA $AC
omega_star_route_step_move11b:
LDA #$C0
STA $AA
LDA $0300,X
CMP $AB
BEQ omega_star_route_fraction11b
LDA $0301,X
CMP $AC
BEQ omega_star_route_fraction11b
LDA #$88
STA $AA
omega_star_route_fraction11b:
LDA $0304,X
CLC
ADC $AA
STA $0304,X
BCC omega_star_route_done11b
LDA $0300,X
CMP $AB
BEQ omega_star_route_y11b
BCC omega_star_route_right11b
DEC $0300,X
JMP omega_star_route_y11b
omega_star_route_right11b:
INC $0300,X
omega_star_route_y11b:
LDA $0301,X
CMP $AC
BEQ omega_star_route_done11b
BCC omega_star_route_down11b
DEC $0301,X
RTS
omega_star_route_down11b:
INC $0301,X
omega_star_route_done11b:
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]
