"""Build Omega Race Version 11B with fixed Shooting Star speed."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v11.py').read_text()

base_v11 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v11.py').read_text(),str(P/'patch_omega_base_v11.py'),'exec'))\\n" + marker)'''
base_v11b = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v11b.py').read_text(),str(P/'patch_omega_base_v11b.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v11) == 1
recipe = recipe.replace(base_v11, base_v11 + '\n' + base_v11b, 1)

chr_v11 = r'''exec(compile((P/'patch_omega_chr_v11.py').read_text(),str(P/'patch_omega_chr_v11.py'),'exec'))\\noutput=P/'omega_race_v11.nes' '''.rstrip()
chr_v11b = r'''exec(compile((P/'patch_omega_chr_v11.py').read_text(),str(P/'patch_omega_chr_v11.py'),'exec'))\\nexec(compile((P/'patch_omega_chr_v11a.py').read_text(),str(P/'patch_omega_chr_v11a.py'),'exec'))\\noutput=P/'omega_race_v11b.nes' '''.rstrip()
assert recipe.count(chr_v11) == 1
recipe = recipe.replace(chr_v11, chr_v11b, 1)
recipe = recipe.replace('symbols_omega_v11.json', 'symbols_omega_v11b.json')
recipe = recipe.replace('prototype_omega_v11.asm', 'prototype_omega_v11b.asm')
exec(compile(recipe, str(P / 'build_omega_base_v11.py'), 'exec'))
