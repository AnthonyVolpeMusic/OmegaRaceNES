"""Version 9: P1 death, level progression, mirrored waves and scaling."""

code = '\n'.join(lines)

# Sixteen distinct personal routes retain the established broad oval corridor.
base_nodes = list(zip(data['drone_nodes_x6'], data['drone_nodes_y6']))
inward = [(1, 1), (-1, 1), (-1, 1), (-1, -1),
          (-1, -1), (1, -1), (1, -1), (1, 1)]
profiles = [
    [-14,-12,-10,  0, 10, 12, 14, 10], [13,15,12,9,-10,-13,-15,-11],
    [-10,11,15,12,0,-12,-14,-13], [15,10,-11,-15,-12,9,13,14],
    [-15,-10,12,14,11,-11,-13,9], [9,14,13,-9,-14,-12,10,15],
    [12,-9,-14,-13,10,15,11,-10], [-12,14,-8,15,-11,9,-15,10],
    [8,-15,11,-9,15,-13,10,-12], [14,-7,-15,10,-9,13,-11,15],
    [-9,12,-14,8,15,-10,13,-15], [11,-13,9,-15,12,-8,14,-10],
    [-15,8,13,-11,9,14,-10,12], [10,15,-12,9,-14,11,-8,13],
    [15,-11,8,13,-10,-14,12,-9], [-8,-14,15,-10,13,9,-12,11],
]
routes = []
for profile in profiles:
    route = []
    for (x, y), (ix, iy), offset in zip(base_nodes, inward, profile):
        route.append((x + ix * offset, y + iy * offset))
    routes.append(route)
data['drone_route_x7a'] = [x for route in routes for x, _ in route]
data['drone_route_y7a'] = [y for route in routes for _, y in route]
data['drone_spawn_x7a'] = [40,48,58,68,35,55,70,30,44,62,76,36,52,66,28,72]
data['drone_spawn_y7a'] = [166,178,188,193,150,171,184,160,196,154,181,190,145,200,174,162]
data['omega_level_total9'] = [7,8,10,11,13,14,16]
data['omega_level_commanders9'] = [1,1,2,2,3,3,4]
data['omega_fire_interval9'] = [120,90,60,45,30]
data['omega_speed_cardinal9'] = [64,80,96,112,128,144,160,176,192]
data['omega_speed_diagonal9'] = [45,57,68,79,91,102,113,124,136]

# Level one begins through the same complete setup path used by respawns and
# later levels.
old = 'JSR drone_init6\nLDA #$10\nSTA $3E'
new = 'LDA #$01\nSTA $C0\nJSR omega_level_setup9\nLDA #$10\nSTA $3E'
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Replace the always-live V8 frame body with a small game-state dispatcher.
old = '''JSR controls
JSR shield_tick
JSR physics
JSR bullets
JSR enemy_shots_tick8
JSR drone_collision7b
JSR drone_tick6
JSR thrust_audio27
JSR pulse_gate24c
JSR shield_phase34
JSR render'''
new = '''JSR omega_frame9'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Rebuild wave initialization for 16 records and mirrored odd/even layouts.
start = code.index('drone_init6:')
end = code.index('drone_assign6:', start)
init = '''drone_init6:
LDA #$00
STA $A8
STA $A9
LDX #$00
drone_clear_records9:
STA $0300,X
INX
BNE drone_clear_records9
LDX #$7F
drone_routes_load9:
LDA drone_route_x7a,X
STA $0400,X
LDA drone_route_y7a,X
STA $0500,X
DEX
BPL drone_routes_load9
LDA $C0
AND #$01
BNE drone_routes_ready9
LDX #$7F
drone_routes_mirror9:
LDA #$F8
SEC
SBC $0400,X
STA $0400,X
DEX
BPL drone_routes_mirror9
drone_routes_ready9:
LDX #$00
LDY #$00
drone_spawn9:
CPY $C1
BEQ drone_spawn_done9
STY $AD
LDA #$01
STA $0303,X
LDA $C0
AND #$01
BEQ drone_spawn_even9
LDA drone_spawn_x7a,Y
JMP drone_spawn_x_ready9
drone_spawn_even9:
LDA #$F8
SEC
SBC drone_spawn_x7a,Y
drone_spawn_x_ready9:
STA $0300,X
LDA drone_spawn_y7a,Y
STA $0301,X
LDA #$00
STA $0304,X
LDA #$01
STA $0305,X
TYA
CMP $C2
BCC drone_spawn_commander9
LDA #$00
JMP drone_spawn_type9
drone_spawn_commander9:
LDA #$01
drone_spawn_type9:
STA $0306,X
LDA $C3
STA $0307,X
JSR drone_assign6
LDY $AD
INY
TXA
CLC
ADC #$10
TAX
JMP drone_spawn9
drone_spawn_done9:
LDX #$5F
LDA #$00
drone_clear_shots9:
STA $0580,X
DEX
BPL drone_clear_shots9
RTS
'''
code = code[:start] + init + code[end:]

# Personal-route Y coordinates move to page $05 to make room for records 8-15.
code = code.replace('SBC $0440,Y', 'SBC $0500,Y')
code = code.replace('LDA $0440,Y', 'LDA $0500,Y')

# Each Commander performs two scaled drone steps. Fire timers use the current
# level's interval rather than a fixed 120 frames.
start = code.index('drone_tick6:')
end = code.index('drone_move6:', start)
tick = '''drone_tick6:
INC $A9
LDA $A9
CMP #$06
BCC drone_tick_start9
LDA #$00
STA $A9
INC $A8
LDA $A8
AND #$03
STA $A8
drone_tick_start9:
LDX #$00
drone_tick_loop9:
LDA $0305,X
BEQ drone_tick_next9
LDA $0306,X
BEQ drone_tick_move9
DEC $0307,X
BNE drone_tick_move9
LDA $C3
STA $0307,X
JSR commander_try_fire8
drone_tick_move9:
JSR drone_move6
LDA $0306,X
BEQ drone_tick_next9
JSR drone_move6
drone_tick_next9:
TXA
CLC
ADC #$10
TAX
BNE drone_tick_loop9
RTS
'''
code = code[:start] + tick + code[end:]

# Base speed is selected from the level table. The second Commander step keeps
# its 2x relationship exact even after the level-nine 3x cap.
start = code.index('drone_move6:')
end = code.index('drone_render6:', start)
move = '''drone_move6:
LDY $0302,X
STY $AF
TXA
LSR A
CLC
ADC $AF
TAY
LDA $0400,Y
STA $AB
LDA $0500,Y
STA $AC
LDA $0300,X
CMP $AB
BNE drone_step9
LDA $0301,X
CMP $AC
BNE drone_step9
LDA $0302,X
CLC
ADC $0303,X
AND #$07
STA $0302,X
TAY
STY $AF
TXA
LSR A
CLC
ADC $AF
TAY
LDA $0400,Y
STA $AB
LDA $0500,Y
STA $AC
drone_step9:
LDY $C4
LDA omega_speed_cardinal9,Y
STA $AA
LDA $0300,X
CMP $AB
BEQ drone_fraction9
LDA $0301,X
CMP $AC
BEQ drone_fraction9
LDA omega_speed_diagonal9,Y
STA $AA
drone_fraction9:
LDA $0304,X
CLC
ADC $AA
STA $0304,X
BCC drone_move_done9
LDA $0300,X
CMP $AB
BEQ drone_move_y9
BCC drone_right9
DEC $0300,X
JMP drone_move_y9
drone_right9:
INC $0300,X
drone_move_y9:
LDA $0301,X
CMP $AC
BEQ drone_move_done9
BCC drone_down9
DEC $0301,X
RTS
drone_down9:
INC $0301,X
drone_move_done9:
RTS
'''
code = code[:start] + move + code[end:]

# Render all sixteen fixed enemy slots; the six enemy-shot slots begin at OAM
# $54, immediately after them.
start = code.index('drone_render6:')
end = code.index('drone_collision7b:', start)
render = '''drone_render6:
LDX #$00
LDY #$14
drone_render_loop9:
LDA $0305,X
BEQ drone_render_hide9
LDA $0301,X
SEC
SBC #$01
STA $0200,Y
LDA $0306,X
BEQ drone_render_basic9
LDA #$E4
BNE drone_render_base9
drone_render_basic9:
LDA #$E0
drone_render_base9:
CLC
ADC $A8
STA $0201,Y
LDA #$03
STA $0202,Y
LDA $0300,X
STA $0203,Y
JMP drone_render_next9
drone_render_hide9:
LDA #$F8
STA $0200,Y
drone_render_next9:
INY
INY
INY
INY
TXA
CLC
ADC #$10
TAX
BNE drone_render_loop9
JSR enemy_shots_render8
RTS
'''
code = code[:start] + render + code[end:]

# Extend projectile/enemy collision scanning to all sixteen records.
start = code.index('drone_collision7b:')
end = code.index('\nRTS', start) + len('\nRTS')
collision = '''drone_collision7b:
LDY #$00
drone_bullet_loop9:
LDA $0600,Y
BNE drone_bullet_active9
JMP drone_next_bullet9
drone_bullet_active9:
LDA $0609,Y
BEQ drone_bullet_flying9
JMP drone_next_bullet9
drone_bullet_flying9:
STY $B0
LDX #$00
drone_hit_loop9:
LDA $0305,X
BNE drone_hit_live9
JMP drone_hit_next9
drone_hit_live9:
LDY $B0
LDA $0602,Y
CLC
ADC #$03
CMP $0300,X
BCS drone_hit_left_ok9
JMP drone_hit_next9
drone_hit_left_ok9:
LDA $0300,X
CLC
ADC #$08
CMP $0602,Y
BCS drone_hit_right_ge9
JMP drone_hit_next9
drone_hit_right_ge9:
BNE drone_hit_x_ok9
JMP drone_hit_next9
drone_hit_x_ok9:
LDA $0604,Y
CLC
ADC #$03
CMP $0301,X
BCS drone_hit_top_ok9
JMP drone_hit_next9
drone_hit_top_ok9:
LDA $0301,X
CLC
ADC #$08
CMP $0604,Y
BCS drone_hit_bottom_ge9
JMP drone_hit_next9
drone_hit_bottom_ge9:
BNE drone_hit_y_ok9
JMP drone_hit_next9
drone_hit_y_ok9:
LDA $0306,X
STA $B1
LDA #$00
STA $0305,X
LDA $0300,X
STA $0602,Y
LDA $0301,X
STA $0604,Y
LDA #$0F
STA $0600,Y
LDA #$01
STA $0609,Y
LDA #$00
STA $0605,Y
STA $0606,Y
STA $0607,Y
STA $0608,Y
LDA $B1
BEQ drone_score_1000_9
LDX #$06
drone_score_1500_loop9:
LDA #$FA
JSR score_add
DEX
BNE drone_score_1500_loop9
JSR commander_promote8
JMP drone_score_done9
drone_score_1000_9:
LDX #$05
drone_score_1000_loop9:
LDA #$C8
JSR score_add
DEX
BNE drone_score_1000_loop9
drone_score_done9:
JSR omega_hud_request_score_v5a
LDY $B0
JMP drone_next_bullet9
drone_hit_next9:
TXA
CLC
ADC #$10
TAX
BEQ drone_hit_scan_done9
JMP drone_hit_loop9
drone_hit_scan_done9:
LDY $B0
drone_next_bullet9:
TYA
CLC
ADC #$10
TAY
CPY #$40
BEQ drone_collision_done9
JMP drone_bullet_loop9
drone_collision_done9:
RTS'''
code = code[:start] + collision + code[end:]

# Maintain the level's Commander quota whenever a basic drone remains.
start = code.index('commander_promote8:')
end = code.index('commander_try_fire8:', start)
promote = '''commander_promote8:
LDX #$00
LDA #$00
STA $B2
commander_count9:
LDA $0305,X
BEQ commander_count_next9
LDA $0306,X
BEQ commander_count_next9
INC $B2
commander_count_next9:
TXA
CLC
ADC #$10
TAX
BNE commander_count9
LDA $B2
CMP $C2
BCS commander_promote_done9
JSR random
AND #$0F
ASL A
ASL A
ASL A
ASL A
TAX
LDA #$10
STA $B2
commander_scan9:
LDA $0305,X
BEQ commander_scan_next9
LDA $0306,X
BEQ commander_promote_here9
commander_scan_next9:
TXA
CLC
ADC #$10
TAX
DEC $B2
BNE commander_scan9
commander_promote_done9:
RTS
commander_promote_here9:
LDA #$01
STA $0306,X
LDA $C3
STA $0307,X
RTS
'''
code = code[:start] + promote + code[end:]

# Relocate V8's projectile pool, expand it from four to six records and move
# its OAM range after the expanded enemy list.
for suffix in range(10):
    code = code.replace(f'$048{suffix:X}', f'$058{suffix:X}')
code = code.replace('CPY #$40\nBNE commander_find_shot8',
                    'CPY #$60\nBNE commander_find_shot8')
code = code.replace('CPX #$40\nBNE enemy_shot_loop_jump8',
                    'CPX #$60\nBNE enemy_shot_loop_jump8')
code = code.replace('CPX #$40\nBNE enemy_shot_render_loop8',
                    'CPX #$60\nBNE enemy_shot_render_loop8')
code = code.replace('enemy_shots_render8:\nLDX #$00\nLDY #$30',
                    'enemy_shots_render8:\nLDX #$00\nLDY #$54')

code += '''
omega_frame9:
JSR controls
LDA $0677
BEQ omega_frame_alive9
CMP #$01
BNE omega_frame_finish9
JSR death_explosion_tick22
JSR omega_death_tick9
JMP omega_frame_finish9
omega_frame_alive9:
LDA $C7
BEQ omega_frame_active9
JSR omega_wave_delay9
JMP omega_frame_finish9
omega_frame_active9:
JSR shield_tick
JSR physics
JSR bullets
JSR enemy_shots_tick8
JSR omega_player_collision9
LDA $0677
BNE omega_frame_finish9
JSR drone_collision7b
JSR drone_tick6
JSR omega_wave_check9
omega_frame_finish9:
JSR thrust_audio27
JSR pulse_gate24c
JSR shield_phase34
JSR render
RTS

omega_level_config9:
LDA $C0
CMP #$07
BCC omega_count_index9
LDA #$07
omega_count_index9:
SEC
SBC #$01
TAY
LDA omega_level_total9,Y
STA $C1
LDA omega_level_commanders9,Y
STA $C2
LDA $C0
CMP #$05
BCC omega_fire_index9
LDA #$05
omega_fire_index9:
SEC
SBC #$01
TAY
LDA omega_fire_interval9,Y
STA $C3
LDA $C0
CMP #$09
BCC omega_speed_index9
LDA #$09
omega_speed_index9:
SEC
SBC #$01
STA $C4
RTS

omega_level_setup9:
JSR omega_level_config9
LDA #$00
STA $0677
STA $0678
STA $067D
STA $C5
STA $C6
STA $C7
STA $08
STA $8D
STA $10
STA $12
STA $14
STA $15
STA $16
STA $17
LDA $C0
AND #$01
BEQ omega_spawn_left9
LDA #$E0
STA $11
LDA #$24
STA $03
JMP omega_spawn_y9
omega_spawn_left9:
LDA #$18
STA $11
LDA #$0C
STA $03
omega_spawn_y9:
LDA #$18
STA $13
LDX #$3F
LDA #$00
omega_clear_player_shots9:
STA $0600,X
DEX
BPL omega_clear_player_shots9
LDA #$05
STA $07
JSR omega_hud_request_supers_v5a
JSR drone_init6
RTS

omega_player_collision9:
LDA $0677
BEQ omega_player_collision_start9
JMP omega_player_collision_done9
omega_player_collision_start9:
LDX #$00
omega_player_enemy_loop9:
LDA $0305,X
BEQ omega_player_enemy_next9
LDA $11
CLC
ADC #$08
CMP $0300,X
BCC omega_player_enemy_next9
BEQ omega_player_enemy_next9
LDA $0300,X
CLC
ADC #$08
CMP $11
BCC omega_player_enemy_next9
BEQ omega_player_enemy_next9
LDA $13
CLC
ADC #$08
CMP $0301,X
BCC omega_player_enemy_next9
BEQ omega_player_enemy_next9
LDA $0301,X
CLC
ADC #$08
CMP $13
BCC omega_player_enemy_next9
BEQ omega_player_enemy_next9
JMP omega_player_kill9
omega_player_enemy_next9:
TXA
CLC
ADC #$10
TAX
BNE omega_player_enemy_loop9
LDX #$00
omega_player_shot_loop9:
LDA $0580,X
BEQ omega_player_shot_next9
LDA $0589,X
BNE omega_player_shot_next9
LDA $0582,X
CLC
ADC #$04
CMP $11
BCC omega_player_shot_next9
LDA $11
CLC
ADC #$08
CMP $0582,X
BCC omega_player_shot_next9
BEQ omega_player_shot_next9
LDA $0584,X
CLC
ADC #$04
CMP $13
BCC omega_player_shot_next9
LDA $13
CLC
ADC #$08
CMP $0584,X
BCC omega_player_shot_next9
BEQ omega_player_shot_next9
LDA #$00
STA $0580,X
JMP omega_player_kill9
omega_player_shot_next9:
TXA
CLC
ADC #$10
TAX
CPX #$60
BNE omega_player_shot_loop9
omega_player_collision_done9:
RTS

omega_player_kill9:
LDA $0677
BNE omega_player_kill_done9
JSR death_burst_start22
LDA #$0F
JSR sfx_noise_start25
LDA #$01
STA $0677
LDA #$B4
STA $0678
LDA #$00
STA $08
STA $14
STA $15
STA $16
STA $17
LDX #$3F
omega_death_clear_player_shots9:
STA $0600,X
DEX
BPL omega_death_clear_player_shots9
LDX #$5F
omega_death_clear_enemy_shots9:
STA $0580,X
DEX
BPL omega_death_clear_enemy_shots9
LDA $3D
BEQ omega_player_no_life9
DEC $3D
JSR omega_hud_request_lives_v5a
LDA $3D
BNE omega_player_kill_done9
omega_player_no_life9:
LDA #$02
STA $0677
omega_player_kill_done9:
RTS

omega_death_tick9:
LDA $0678
BEQ omega_death_expired9
DEC $0678
BNE omega_death_done9
omega_death_expired9:
LDA $3D
BEQ omega_death_done9
JSR omega_level_setup9
omega_death_done9:
RTS

omega_wave_check9:
LDX #$00
omega_wave_scan9:
LDA $0305,X
BNE omega_wave_active9
TXA
CLC
ADC #$10
TAX
BNE omega_wave_scan9
LDA #$01
STA $C7
LDA #$2C
STA $C5
LDA #$01
STA $C6
LDA #$00
STA $14
STA $15
STA $16
STA $17
LDX #$3F
omega_wave_clear_player_shots9:
STA $0600,X
DEX
BPL omega_wave_clear_player_shots9
LDX #$5F
omega_wave_clear_enemy_shots9:
STA $0580,X
DEX
BPL omega_wave_clear_enemy_shots9
omega_wave_active9:
RTS

omega_wave_delay9:
LDA $C5
BNE omega_wave_delay_low9
LDA $C6
BEQ omega_wave_advance9
DEC $C6
LDA #$FF
STA $C5
RTS
omega_wave_delay_low9:
DEC $C5
LDA $C5
ORA $C6
BNE omega_wave_delay_done9
omega_wave_advance9:
INC $C0
JSR omega_level_setup9
omega_wave_delay_done9:
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]
