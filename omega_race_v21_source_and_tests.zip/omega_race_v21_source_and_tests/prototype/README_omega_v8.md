# Omega Race NES — Version 8 Commander

Baseline: Version 7B's seven independently routed enemies, Player One missile
collision, event-driven scoring, arena, controls, graphics and audio.

- Level 1 starts with one Commander and six basic drones.
- The Commander uses Anthony's supplied four-frame 8x8 animation, switching
  frames every six simulation frames with the basic drones.
- It follows the same personal-route system as a drone at exactly twice the
  basic drone speed.
- Every 120 simulation frames, the Commander aims at Player One and fires only
  when the direct ray reaches the ship without crossing the middle box or an
  arena wall.
- All Commanders share an independent four-projectile pool. Enemy projectiles
  reuse the existing projectile graphic and enemy palette, and reuse the
  15-frame wall-impact explosion on either the inner or outer wall.
- Enemy projectiles intentionally do not damage Player One in this version.
- A destroyed Commander awards 1,500 points. A destroyed basic drone remains
  worth 1,000 points.
- When a Commander is destroyed, one randomly selected surviving basic drone
  is promoted immediately and inherits Commander speed, art and firing.
- Score tiles remain event-driven and are marked dirty only after a kill.
- The future 20-second Shooting Star conversion is not included yet.

Build: `python3 prototype/build_omega_base_v8.py`

Test: `python3 prototype/test_omega_v8.py`

Dependencies: Python 3, Pillow and py65.
