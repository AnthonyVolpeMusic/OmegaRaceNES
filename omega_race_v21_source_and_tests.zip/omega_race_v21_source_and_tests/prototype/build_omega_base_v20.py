"""Build Omega Race Version 20 from confirmed Version 19B."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v19b.py').read_text()

base_v19b = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v19b.py').read_text(),str(P/'patch_omega_base_v19b.py'),'exec'))\\n" + marker)'''
base_v20 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v20.py').read_text(),str(P/'patch_omega_base_v20.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v19b) == 1
recipe = recipe.replace(base_v19b, base_v19b + '\n' + base_v20, 1)
recipe = recipe.replace('omega_race_v19b.nes', 'omega_race_v20.nes')
recipe = recipe.replace('symbols_omega_v19b.json', 'symbols_omega_v20.json')
recipe = recipe.replace('prototype_omega_v19b.asm', 'prototype_omega_v20.asm')
exec(compile(recipe, str(P / 'build_omega_base_v19b.py'), 'exec'))
