"""Build Omega Race Version 11 from the V5A baseline and layered patches."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v5a.py').read_text()
needle = "exec(compile(source, str(P / 'build_v15.py'), 'exec'))"
assert recipe.count(needle) == 1
recipe = recipe.replace(needle, '''
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v6.py').read_text(),str(P/'patch_omega_base_v6.py'),'exec'))\\n" + marker)
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v7a.py').read_text(),str(P/'patch_omega_base_v7a.py'),'exec'))\\n" + marker)
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v7b.py').read_text(),str(P/'patch_omega_base_v7b.py'),'exec'))\\n" + marker)
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v8.py').read_text(),str(P/'patch_omega_base_v8.py'),'exec'))\\n" + marker)
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v9.py').read_text(),str(P/'patch_omega_base_v9.py'),'exec'))\\n" + marker)
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v10.py').read_text(),str(P/'patch_omega_base_v10.py'),'exec'))\\n" + marker)
source = source.replace(marker, "exec(compile((P/'patch_omega_base_v11.py').read_text(),str(P/'patch_omega_base_v11.py'),'exec'))\\n" + marker)
out = "output=P/'omega_race_v5a_event_hud_test.nes'"
source = source.replace(out, "exec(compile((P/'patch_omega_chr_v6.py').read_text(),str(P/'patch_omega_chr_v6.py'),'exec'))\\nexec(compile((P/'patch_omega_chr_v8.py').read_text(),str(P/'patch_omega_chr_v8.py'),'exec'))\\nexec(compile((P/'patch_omega_chr_v11.py').read_text(),str(P/'patch_omega_chr_v11.py'),'exec'))\\noutput=P/'omega_race_v11.nes'")
source = source.replace('symbols_omega_v5a.json', 'symbols_omega_v11.json')
source = source.replace('prototype_omega_v5a.asm', 'prototype_omega_v11.asm')
exec(compile(source, str(P / 'build_v15.py'), 'exec'))
''')
exec(compile(recipe, str(P / 'build_omega_base_v5a.py'), 'exec'))
