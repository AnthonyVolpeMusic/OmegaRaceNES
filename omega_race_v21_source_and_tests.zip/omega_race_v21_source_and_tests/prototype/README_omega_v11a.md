# Omega Race NES — Version 11A revised Shooting Star artwork

Baseline: Version 11's Commander conversion, hybrid Shooting Star pursuit,
clear-line firing, scoring, collision behavior and replacement promotion.

- Replaces all four 8x8 Shooting Star animation frames with Anthony Volpe's
  revised drawings.
- All four frames are supplied individually; no mirrored frame is generated.
- Shooting Star palette mapping is transparent `$08`, red body `$16`, yellow
  details `$27`, and orange highlights `$38`.
- The existing six-frame animation cadence is unchanged.
- Movement, route fallback, firing, scoring, collision and transformation
  behavior are byte-identical to Version 11.

Build: `python3 prototype/build_omega_base_v11a.py`

Test: `python3 prototype/test_omega_v11a.py`

Dependencies: Python 3, Pillow and py65.
