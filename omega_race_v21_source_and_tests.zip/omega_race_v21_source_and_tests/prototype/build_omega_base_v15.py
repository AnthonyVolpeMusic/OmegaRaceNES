"""Build Omega Race Version 15 with the level-clear song."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v14.py').read_text()

base_v14 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v14.py').read_text(),str(P/'patch_omega_base_v14.py'),'exec'))\\n" + marker)'''
base_v15 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v15.py').read_text(),str(P/'patch_omega_base_v15.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v14) == 1
recipe = recipe.replace(base_v14, base_v14 + '\n' + base_v15, 1)

recipe = recipe.replace('omega_race_v14.nes', 'omega_race_v15.nes')
recipe = recipe.replace('symbols_omega_v14.json', 'symbols_omega_v15.json')
recipe = recipe.replace('prototype_omega_v14.asm', 'prototype_omega_v15.asm')
exec(compile(recipe, str(P / 'build_omega_base_v14.py'), 'exec'))
