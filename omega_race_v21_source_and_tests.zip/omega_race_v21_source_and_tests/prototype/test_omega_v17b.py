"""Regression tests for Omega Race Version 17B."""
from pathlib import Path
import json

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
text = base.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v17b.nes')
text = text.replace('symbols_omega_base_v1.json', 'symbols_omega_v17b.json')
text = text.replace('range(400000)', 'range(900000)')
env = {'__file__': str(P / 'test_omega_v17b.py')}
exec(compile(text, 'harness', 'exec'), env)
boot, call = env['boot'], env['call']

rom = (P / 'omega_race_v17b.nes').read_bytes()[16:16 + 32768]
symbols = json.loads((P / 'symbols_omega_v17b.json').read_text())
palette_start = symbols['palette'] - 0x8000
palette = rom[palette_start:palette_start + 32]
assert all(palette[i] == 0x0F for i in (0,4,8,12,16,20,24,28))
assert palette[1:4] == bytes((0x18,0x28,0x38))
assert palette[5:8] == bytes((0x18,0x28,0x16))
print('PASS all universal and mirrored startup palette entries are true black')

mm, cc = boot()
assert mm[0x06] == 0
call(mm, cc, 'render')
assert all(mm[address] == 0xF8 for address in range(0x200,0x300,4))
print('PASS title rendering hides every OAM entry and creates no inherited asteroid sprites')

mm[0x9A] = 3
call(mm, cc, 'omega_start_game17')
assert mm[0x06] == 1 and (mm[0xA7] & 0x08)
call(mm, cc, 'omega_palette_flush12b')
assert not (mm[0xA7] & 0x08)
print('PASS gameplay still restores the normal Level 1 palette')

print('PASS Omega Race Version 17B title cleanup regression suite')
