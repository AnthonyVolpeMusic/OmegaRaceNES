"""Machine-code regression tests for Omega Race Version 12B."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v12a.py').read_text()
text = text.replace('Version 12A.', 'Version 12B.', 1)
text = text.replace('omega_race_v12a.nes', 'omega_race_v12b.nes')
text = text.replace('symbols_omega_v12a.json', 'symbols_omega_v12b.json')
text = text.replace("call(mm, cc, 'omega_hud_flush_v5a')",
                    "call(mm, cc, 'omega_palette_flush12b')")

# V12B deliberately refreshes the palette on a same-level full board rebuild.
start = text.index('# Rebuilding the same level does not waste another NMI palette write.')
text = text[:start]
exec(compile(text, str(P / 'test_omega_v12a.py'), 'exec'))


def run_nmi(mm, cc):
    """Invoke one NMI and run through its RTI return address."""
    cc.pc = 0x7FFF
    cc.sp = 0xFF
    cc.nmi()
    for _ in range(20000):
        cc.step()
        if cc.pc == 0x7FFF:
            return
    raise AssertionError('NMI timeout')


# Active shield blocks enemy contact, a live enemy shot and a land mine. Once
# its sixty ticks expire, the same overlap uses the normal death path.
for hazard in ('enemy', 'shot', 'mine'):
    mm, cc = boot()
    for a in range(0x300, 0x400, 16):
        mm[a + 5] = 0
    for a in range(0x580, 0x5E0, 16):
        mm[a] = 0
    for a in range(0x700, 0x740, 4):
        mm[a] = 0
    if hazard == 'enemy':
        mm[0x300:0x306] = [mm[0x11], mm[0x13], 0, 0, 0, 1]
    elif hazard == 'shot':
        mm[0x580:0x58A] = [0xFF, 0, mm[0x11]+2, 0, mm[0x13]+2, 0, 0, 0, 0, 0]
    else:
        mm[0x700:0x703] = [0xFF, mm[0x11], mm[0x13]]
    mm[0x08] = 60
    call(mm, cc, 'omega_player_collision9')
    assert mm[0x677] == 0 and mm[0x3D] == 3
    for _ in range(60):
        call(mm, cc, 'shield_tick')
    call(mm, cc, 'omega_player_collision9')
    assert mm[0x677] == 1 and mm[0x3D] == 2
print('PASS shield protects Player One from enemies, enemy shots and land mines for all 60 ticks')

# The palette service runs in the very first VBlank even if the main frame is
# not ready and frame pacing would have skipped the usual HUD/OAM path.
mm, cc = boot()
mm[0xC0] = 2
call(mm, cc, 'omega_level_setup9')
assert mm[0xA7] & 0x08 and mm[0xCF] == 1
mm.ppu = []
mm[0x00] = 0
mm[0xA2] = 2
run_nmi(mm, cc)
assert mm.ppu == [0x0C,0x1C,0x2C,0x3C]
assert not (mm[0xA7] & 0x08)
assert mm[0x00] == 0 and mm.dmas == 0
print('PASS Level 2 palette is applied in the first VBlank during level initialization')

# A same-level restart retains the already-applied palette without another
# write, preserving the event behavior from Version 12A.
mm[0xA7] = 0
call(mm, cc, 'omega_level_setup9')
assert not (mm[0xA7] & 0x08) and mm[0xCF] == 1
print('PASS same-level board rebuilds retain the current palette')
