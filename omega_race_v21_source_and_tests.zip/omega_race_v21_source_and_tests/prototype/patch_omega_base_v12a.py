"""Version 12A: faster mine drops and an eight-level tile-palette cycle."""

code = '\n'.join(lines)

# Commander: 180 frames / 3 seconds. Shooting Star: 60 frames / 1 second.
assert code.count('omega_mine_timer_commander12:\nLDA #$F0') == 1
code = code.replace('omega_mine_timer_commander12:\nLDA #$F0',
                    'omega_mine_timer_commander12:\nLDA #$B4', 1)
assert code.count('omega_mine_timer_star12:\nLDA #$78') == 1
code = code.replace('omega_mine_timer_star12:\nLDA #$78',
                    'omega_mine_timer_star12:\nLDA #$3C', 1)

# Request a palette write only when the eight-level palette index changes.
# $CF caches the currently displayed index; reset value zero matches Level 1.
old = '''omega_level_setup9:
JSR omega_level_config9
LDA #$00'''
new = '''omega_level_setup9:
JSR omega_level_config9
JSR omega_palette_request12a
LDA #$00'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Extend the event-driven HUD writer with bit 3 for four background-palette
# bytes. Sprite-palette bytes $3F10-$3F1F are never touched.
old = '''LDA $A7
AND #$04
BEQ omega_hud_flush_clear_v5a
LDA #$22
STA $2006
LDA #$15
STA $2006
LDA $3D
CLC
ADC #$7B
STA $2007
omega_hud_flush_clear_v5a:'''
new = '''LDA $A7
AND #$04
BEQ omega_palette_check12a
LDA #$22
STA $2006
LDA #$15
STA $2006
LDA $3D
CLC
ADC #$7B
STA $2007
omega_palette_check12a:
LDA $A7
AND #$08
BEQ omega_hud_flush_clear_v5a
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDA $CF
ASL A
ASL A
TAX
LDY #$00
omega_palette_write12a:
LDA omega_tile_palettes12a,X
STA $2007
INX
INY
CPY #$04
BNE omega_palette_write12a
omega_hud_flush_clear_v5a:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += '''
omega_palette_request12a:
LDA $C0
SEC
SBC #$01
AND #$07
CMP $CF
BEQ omega_palette_request_done12a
STA $CF
LDA $A7
ORA #$08
STA $A7
omega_palette_request_done12a:
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]
data['omega_tile_palettes12a'] = [
    0x08,0x18,0x28,0x38,
    0x0C,0x1C,0x2C,0x3C,
    0x04,0x13,0x22,0x31,
    0x01,0x12,0x23,0x34,
    0x0B,0x1A,0x29,0x38,
    0x06,0x17,0x28,0x39,
    0x05,0x15,0x25,0x35,
    0x21,0x11,0x01,0x0D,
]
