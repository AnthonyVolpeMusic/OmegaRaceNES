"""Omega Race V4: narrower track, impact shots, and damped ship rebounds."""
from pathlib import Path

P = Path(__file__).parent
exec(compile((P / 'build_omega_base_v1.py').read_text(),
             str(P / 'build_omega_base_v1.py'), 'exec'))

marker = 'asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker) == 1
source = source.replace(
    marker,
    "exec(compile((P/'patch_omega_base_v3.py').read_text(),"
    "str(P/'patch_omega_base_v3.py'),'exec'))\n"
    "exec(compile((P/'patch_omega_base_v4.py').read_text(),"
    "str(P/'patch_omega_base_v4.py'),'exec'))\n" + marker)

# Border CHR must still be installed after inherited starfield generation.
output_marker = "output=P/'omega_race_player_base_v2_palette_test.nes'"
assert source.count(output_marker) == 1
source = source.replace(
    output_marker,
    "exec(compile((P/'patch_omega_chr_v3.py').read_text(),"
    "str(P/'patch_omega_chr_v3.py'),'exec'))\n" + output_marker)
source = source.replace(output_marker,
                        "output=P/'omega_race_v4_narrow_track_test.nes'")
source = source.replace('symbols_omega_base_v1.json', 'symbols_omega_v4.json')
source = source.replace('prototype_omega_base_v1.asm', 'prototype_omega_v4.asm')
exec(compile(source, str(P / 'build_v15.py'), 'exec'))
