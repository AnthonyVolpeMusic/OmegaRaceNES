"""Version 19B machine tests: both restart routes clear old mine records."""
from pathlib import Path

P = Path(__file__).parent
base = (P/'test_omega_v19.py').read_text().split('# The actual first vblank')[0]
base = base.replace('omega_race_v19.nes', 'omega_race_v19b.nes')
base = base.replace('symbols_omega_v19.json', 'symbols_omega_v19b.json')
env = {'__file__': str(P/'test_omega_v19b.py')}
exec(compile(base, 'v19b machine harness', 'exec'), env)
boot, call = env['boot'], env['call']

def add_mines(memory):
    for offset in range(0, 0x40, 4):
        memory[0x700+offset:0x704+offset] = [0xFF, 96, 96, offset]
    assert sum(memory[0x700+i] != 0 for i in range(0,0x40,4)) == 16

# Reproduce the reported route using actual controller reads: Game Over,
# Select, release, then Start from the title with an entire field of mines.
m,c = boot()
call(m,c,'omega_start_game17')
add_mines(m)
call(m,c,'omega_gameover_enter19')
m.pad = 0x20
call(m,c,'controls')
assert m[6] == 0 and m[0x677] == 0
assert m[0x700] == 0xFF
m.pad = 0
call(m,c,'controls')
m.pad = 0x10
call(m,c,'controls')
assert m[6] == 1 and m[0xC0] == 1 and m[0x677] == 4
assert m[0x700:0x740] == [0]*0x40
print('PASS Game Over → Select → title Start clears all 16 land-mine records')

# Game Over Start takes the existing replay route and still clears all mines.
m,c = boot()
call(m,c,'omega_start_game17')
add_mines(m)
call(m,c,'omega_gameover_enter19')
m.pad = 0x10
call(m,c,'controls')
assert m[6] == 1 and m[0xC0] == 1 and m[0x677] == 4
assert m[0x700:0x740] == [0]*0x40
print('PASS Game Over → Start replay still clears all land-mine records')

# Level 2 uses omega_level_setup9 rather than omega_start_game17.  A distant
# mine therefore persists as specified; the routine can still remove any
# mine within eight pixels of the new player spawn.
m,c = boot()
call(m,c,'omega_start_game17')
add_mines(m)
m[0xC7],m[0xD7],m[0xC5],m[0xC6] = 1,0,0,0
call(m,c,'omega_wave_delay9')
assert m[0xC0] == 2 and m[0x677] == 4
assert sum(m[0x700+i] != 0 for i in range(0,0x40,4)) == 16
print('PASS normal wave advance preserves all mines away from the spawn point')
