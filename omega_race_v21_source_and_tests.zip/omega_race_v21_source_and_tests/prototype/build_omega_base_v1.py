"""Omega Race player foundation: V36 ship/controls in an empty Bouncy arena."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v36.py').read_text(),str(P/'build_v36.py'),'exec'))
marker='asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker)==1
source=source.replace(marker,"exec(compile((P/'patch_omega_base_v1.py').read_text(),str(P/'patch_omega_base_v1.py'),'exec'))\n"+marker)
source=source.replace("output=P/'asteroids_nes_v36_controls_cleanup.nes'", "output=P/'omega_race_player_base_v2_palette_test.nes'")
source=source.replace('symbols_v36.json','symbols_omega_base_v1.json').replace('prototype_v36.asm','prototype_omega_base_v1.asm')
exec(compile(source,str(P/'build_v15.py'),'exec'))
