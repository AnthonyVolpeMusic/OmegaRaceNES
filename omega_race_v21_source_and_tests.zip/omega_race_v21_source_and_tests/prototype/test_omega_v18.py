"""Regression tests for Omega Race Version 18."""
from pathlib import Path
import json

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
text = base.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v18.nes')
text = text.replace('symbols_omega_base_v1.json', 'symbols_omega_v18.json')
text = text.replace('range(400000)', 'range(900000)')
env = {'__file__': str(P / 'test_omega_v18.py')}
exec(compile(text, 'harness', 'exec'), env)
boot, call = env['boot'], env['call']

def call_a(mm, cc, name, value):
    cc.a = value
    call(mm, cc, name)

image = (P / 'omega_race_v18.nes').read_bytes()
prg = image[16:16 + 32768]
chr_data = image[16 + 32768:]
symbols = json.loads((P / 'symbols_omega_v18.json').read_text())

def table(name, size):
    start = symbols[name] - 0x8000
    return prg[start:start + size]

def glyph(ch):
    if ch == ' ': return 0
    if ch == ':': return 0x8A
    return 0x61 + ord(ch) - ord('A')

title = b''.join(table(f'title_nt{i}', 256) for i in range(4))
line = 'STARTING LIVES: THREE'
x = (32 - len(line)) // 2
assert title[14 * 32 + x:14 * 32 + x + len(line)] == bytes(glyph(c) for c in line)
colon = chr_data[0x8A * 16:0x8B * 16]
expected_plane = bytes((0x00,0x18,0x18,0x00,0x00,0x18,0x18,0x00))
assert colon == expected_plane + expected_plane
print('PASS STARTING LIVES uses a dedicated, verified colon glyph rather than numeral 3')

words = table('omega_lives_words17', 15)
assert words == bytes(glyph(c) for c in 'THREEFIVE SEVEN')
mm, cc = boot()
choices = []
for _ in range(3):
    mm.pad = 0x20
    call(mm, cc, 'controls')
    choices.append(mm[0x9A])
    mm.pad = 0
    call(mm, cc, 'controls')
assert choices == [5,7,3]
for lives in (3,5,7):
    mm, cc = boot()
    mm[0x9A] = lives
    call(mm, cc, 'omega_start_game17')
    assert mm[0x3D] == lives
print('PASS title selector contains only THREE, FIVE, and SEVEN and transfers each value')

# Two back-to-back effects occupy independent pulse voices rather than
# interrupting one another.
mm, cc = boot()
mm[0xD7] = 0
call_a(mm, cc, 'omega_pulse1_start14', 1)
assert (mm[0xD2], mm[0x82]) == (1,12) and mm[0x06A0] == 0
call_a(mm, cc, 'omega_pulse1_start14', 2)
assert (mm[0xD2], mm[0x82]) == (1,12)
assert (mm[0x06A2], mm[0x06A0]) == (2,12)
assert mm[0x86] & 3 == 3
print('PASS consecutive gameplay effects occupy Pulse 1 and Pulse 2 simultaneously')

# Both renderers produce the same waveform for all nine defined pulse effects.
def capture(effect, voice):
    mm, cc = boot()
    mm[0xD7] = 0
    if voice == 1:
        mm[0x89] = 1  # reserve legacy Pulse 2, forcing Pulse 1
    else:
        mm[0x82] = 1
        mm[0xD3] = 0xFF  # busy Pulse 1, forcing the free second voice
    call_a(mm, cc, 'omega_pulse1_start14', effect)
    remaining = mm[0x82] if voice == 1 else mm[0x06A0]
    assert remaining
    result = []
    while remaining:
        if voice == 1:
            result.append((mm[0x4000],mm[0x4002],mm[0x4003]))
            call(mm, cc, 'omega_pulse1_tick14')
            remaining = mm[0x82]
        else:
            result.append((mm[0x4004],mm[0x4006],mm[0x4007]))
            call(mm, cc, 'omega_pulse2_tick18')
            remaining = mm[0x06A0]
    return result

for effect in range(1,10):
    assert capture(effect,1) == capture(effect,2), effect
print('PASS both pulse voices reproduce all nine effects with identical timing and pitch')

# A legacy shield/stop cue reserves Pulse 2; normal effects safely remain on
# Pulse 1 until that cue has completed.
mm, cc = boot()
mm[0xD7] = 0
call_a(mm, cc, 'pulse2_start26', 7)
assert mm[0x89] and mm[0x87] == 7
call_a(mm, cc, 'omega_pulse1_start14', 1)
call_a(mm, cc, 'omega_pulse1_start14', 2)
assert mm[0x06A0] == 0 and mm[0x82] == 12
print('PASS shield/stop cues safely reserve Pulse 2 without state corruption')

# Higher-priority effects may replace a lower-priority voice, while the other
# active effect continues untouched.
mm, cc = boot()
mm[0xD7] = 0
call_a(mm, cc, 'omega_pulse1_start14', 1)
call_a(mm, cc, 'omega_pulse1_start14', 2)
second_before = (mm[0x06A2],mm[0x06A0])
call_a(mm, cc, 'omega_pulse1_start14', 3)
assert mm[0xD2] == 3 and mm[0xD3] == 4
assert (mm[0x06A2],mm[0x06A0]) == second_before
print('PASS priority replacement affects only the lower-priority selected voice')

# Level-clear music waits for either gameplay voice, then takes exclusive
# ownership of both; Player One death immediately clears both voices.
mm, cc = boot()
mm[0xD7] = 1
mm[0x06A0] = 2
call(mm, cc, 'omega_level_song_tick15')
assert mm[0xD7] == 1
call(mm, cc, 'omega_pulse2_tick18')
call(mm, cc, 'omega_pulse2_tick18')
call(mm, cc, 'omega_level_song_tick15')
assert mm[0xD7] == 0xFF and mm[0x06A0] == 0

mm, cc = boot()
mm[0xD7] = 0
call_a(mm, cc, 'omega_pulse1_start14', 1)
call_a(mm, cc, 'omega_pulse1_start14', 2)
call(mm, cc, 'omega_death_sfx_start14')
assert mm[0x82] == mm[0x06A0] == mm[0x89] == 0
assert mm[0xD6] == 1 and mm[0x86] == 8
print('PASS level-clear music and death retain exclusive audio ownership')

print('PASS Omega Race Version 18 title and dual-pulse regression suite')
