"""Omega Race V20: timed three-screen arcade attract sequence."""
import textwrap

code = '\n'.join(lines)

# Input is read every title frame; the attract gate can consume Start/Select
# without letting that same press enter gameplay or cycle starting lives.
old = '''LDA $06
BNE game_controls
LDA $02
EOR #$FF
AND $01
AND #$20'''
new = '''LDA $06
BNE game_controls
JSR omega_attract_gate20
BCC omega_title_input20
RTS
omega_title_input20:
LDA $02
EOR #$FF
AND $01
AND #$20'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Text/color PPU writes are queued in the main loop and flushed in vblank.
old = '''JSR omega_palette_flush12b
JSR omega_title_flush17
LDA $A2'''
new = '''JSR omega_palette_flush12b
JSR omega_title_flush17
JSR omega_attract_flush20
LDA $A2'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Attract icons use the same 8x8 sprite art and palettes as gameplay.
old = '''render_title:
RTS'''
new = '''render_title:
LDA $06B0
CMP #$03
BNE omega_attract_render_done20
LDX #$00
LDY #$00
omega_attract_render_icon20:
LDA omega_attract_icon_y20,X
STA $0200,Y
LDA omega_attract_icon_tile20,X
STA $0201,Y
LDA omega_attract_icon_palette20,X
STA $0202,Y
LDA #$28
STA $0203,Y
INY
INY
INY
INY
INX
CPX #$04
BNE omega_attract_render_icon20
omega_attract_render_done20:
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Starting a game always leaves the idle/attract state clean.
old = '''omega_start_game17:
LDA #$00
STA $2001'''
new = '''omega_start_game17:
LDA #$00
STA $06B0
STA $06B1
STA $06B2
STA $06BB
STA $06BD
STA $2001'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Returning from Game Over must start a fresh ten-second idle interval too.
old = '''omega_gameover_title19:
JSR audio_reset25a
JSR results_off23'''
new = '''omega_gameover_title19:
JSR audio_reset25a
JSR results_off23
LDA #$00
STA $06B0
STA $06B1
STA $06B2
STA $06BB
STA $06BD'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

attract = '''omega_attract_gate20:
LDA $06B0
BEQ omega_attract_idle20
LDA $01
AND #$30
BEQ omega_attract_no_cancel20
JSR omega_gameover_title19
SEC
RTS
omega_attract_no_cancel20:
JSR omega_attract_tick20
SEC
RTS
omega_attract_idle20:
LDA $01
BEQ omega_attract_idle_count20
LDA #$00
STA $06B1
STA $06B2
CLC
RTS
omega_attract_idle_count20:
INC $06B1
BNE omega_attract_idle_check20
INC $06B2
omega_attract_idle_check20:
LDA $06B2
CMP #$02
BCC omega_attract_idle_return20
LDA $06B1
CMP #$58
BCC omega_attract_idle_return20
JSR omega_attract_story_one20
SEC
RTS
omega_attract_idle_return20:
CLC
RTS

omega_attract_flush20:
LDA $06BB
BEQ omega_attract_flush_color20
LDA #$00
STA $06BB
LDA $06B9
STA $2006
LDA $06BA
STA $2006
LDA $06B8
STA $2007
omega_attract_flush_color20:
LDA $06BD
BEQ omega_attract_flush_done20
LDA #$00
STA $06BD
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDA $06BC
STA $2007
omega_attract_flush_done20:
RTS

omega_attract_blank20:
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$04
LDX #$00
LDA #$00
omega_attract_blank_loop20:
STA $2007
INX
BNE omega_attract_blank_loop20
DEY
BNE omega_attract_blank_loop20
RTS

omega_attract_show20:
JSR render
LDA #$00
STA $2003
LDA #$02
STA $4014
JMP results_on23

omega_attract_story_one20:
JSR results_off23
JSR omega_attract_blank20
LDA #$00
STA $A7
STA $06B3
STA $06B4
STA $06B5
STA $06B6
STA $06B7
STA $06BB
STA $06BD
LDA #$01
STA $06B0
JSR omega_attract_show20
RTS

omega_attract_tick20:
LDA $06B0
CMP #$01
BEQ omega_attract_type20
CMP #$04
BEQ omega_attract_type20
CMP #$05
BNE omega_attract_wait20
JMP omega_attract_flash_tick20
omega_attract_wait20:
JSR omega_attract_countdown20
BCC omega_attract_tick_done20
LDA $06B0
CMP #$02
BNE omega_attract_not_scores20
JMP omega_attract_scores20
omega_attract_not_scores20:
CMP #$03
BNE omega_attract_not_three20
JMP omega_attract_story_three20
omega_attract_not_three20:
JSR omega_gameover_title19
omega_attract_tick_done20:
RTS

omega_attract_countdown20:
LDA $06B1
BNE omega_attract_count_low20
DEC $06B2
omega_attract_count_low20:
DEC $06B1
LDA $06B1
ORA $06B2
BEQ omega_attract_count_done20
CLC
RTS
omega_attract_count_done20:
SEC
RTS

omega_attract_type20:
LDA $06B3
BEQ omega_attract_type_next20
DEC $06B3
BNE omega_attract_type_done20
omega_attract_type_next20:
LDA #$05
STA $06B3
LDA $06B0
CMP #$01
BNE omega_attract_read_three20
LDY $06B6
LDA $06B7
BEQ omega_attract_read_one_a20
LDA omega_attract_story_one_b20,Y
JMP omega_attract_token20
omega_attract_read_one_a20:
LDA omega_attract_story_one_a20,Y
JMP omega_attract_token20
omega_attract_read_three20:
LDY $06B6
LDA omega_attract_story_three_text20,Y
omega_attract_token20:
STA $06BC
INC $06B6
BNE omega_attract_index_ready20
INC $06B7
omega_attract_index_ready20:
LDA $06BC
CMP #$FE
BEQ omega_attract_type_end20
CMP #$FF
BEQ omega_attract_next_line20
STA $06B8
LDX $06B4
LDA $06B0
CMP #$01
BNE omega_attract_address_three20
LDA omega_attract_story_one_lo20,X
STA $06BA
LDA omega_attract_story_one_hi20,X
JMP omega_attract_address_base20
omega_attract_address_three20:
LDA omega_attract_story_three_lo20,X
STA $06BA
LDA omega_attract_story_three_hi20,X
omega_attract_address_base20:
STA $06B9
LDA $06BA
CLC
ADC $06B5
STA $06BA
LDA $06B9
ADC #$00
STA $06B9
INC $06B5
LDA #$01
STA $06BB
omega_attract_type_done20:
RTS
omega_attract_next_line20:
INC $06B4
LDA #$00
STA $06B5
JMP omega_attract_type_next20
omega_attract_type_end20:
LDA $06B0
CMP #$01
BNE omega_attract_reveal20
LDA #$02
STA $06B0
LDA #$2C
STA $06B1
LDA #$01
STA $06B2
RTS

omega_attract_scores20:
JSR results_off23
JSR omega_attract_blank20
LDA #$03
STA $06B0
LDA #$58
STA $06B1
LDA #$02
STA $06B2
LDX #$00
omega_attract_score_rows20:
LDA omega_attract_score_hi20,X
STA $2006
LDA omega_attract_score_lo20,X
STA $2006
TXA
ASL A
ASL A
STA $06B5
ASL A
CLC
ADC $06B5
TAY
LDA #$0C
STA $06B4
omega_attract_score_tiles20:
LDA omega_attract_score_text20,Y
STA $2007
INY
DEC $06B4
BNE omega_attract_score_tiles20
INX
CPX #$04
BNE omega_attract_score_rows20
JSR omega_attract_show20
RTS

omega_attract_story_three20:
JSR results_off23
JSR omega_attract_blank20
LDA #$04
STA $06B0
LDA #$00
STA $06B3
STA $06B4
STA $06B5
STA $06B6
STA $06B7
JSR omega_attract_show20
RTS

omega_attract_reveal20:
JSR results_off23
JSR omega_attract_logo_draw20
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDA #$38
STA $2007
LDA #$05
STA $06B0
LDA #$00
STA $06BE
LDA #$0A
STA $06BF
JSR omega_attract_noise20
JSR omega_attract_show20
RTS

omega_attract_logo_draw20:
LDX #$00
LDY #$00
omega_attract_logo_row20:
LDA omega_attract_logo_hi20,Y
STA $2006
LDA omega_attract_logo_lo20,Y
STA $2006
LDA #$18
STA $06B4
omega_attract_logo_col20:
LDA omega_attract_logo_tiles20,X
STA $2007
INX
DEC $06B4
BNE omega_attract_logo_col20
INY
CPY #$06
BNE omega_attract_logo_row20
LDA #$23
STA $2006
LDA #$C0
STA $2006
LDX #$00
omega_attract_logo_attr20:
LDA omega_attract_logo_attrs20,X
STA $2007
INX
CPX #$40
BNE omega_attract_logo_attr20
RTS

omega_attract_noise20:
LDA #$01
STA $D6
LDA #$3C
STA $84
LDA #$00
STA $85
LDA $86
ORA #$08
STA $86
STA $4015
LDA #$00
STA $400F
JSR omega_death_noise_output14
RTS

omega_attract_flash_tick20:
DEC $06BF
BNE omega_attract_flash_done20
LDA #$0A
STA $06BF
INC $06BE
LDX $06BE
CPX #$06
BEQ omega_attract_flash_end20
LDA omega_attract_flash_colors20,X
STA $06BC
LDA #$01
STA $06BD
omega_attract_flash_done20:
RTS
omega_attract_flash_end20:
LDA #$06
STA $06B0
LDA #$2C
STA $06B1
LDA #$01
STA $06B2
RTS

'''
assert code.count('omega_dispatch17:\n') == 1
code = code.replace('omega_dispatch17:\n', attract + 'omega_dispatch17:\n', 1)
lines = [s.strip() for s in code.splitlines() if s.strip()]

def glyph20(ch):
    if ch == ' ': return 0
    if ch == '.': return 0x8B
    if ch == ',': return 0x8C
    if '0' <= ch <= '9': return 0x7B + ord(ch) - 48
    if 'A' <= ch <= 'Z': return 0x61 + ord(ch) - 65
    raise ValueError(ch)

paragraphs = [
    'IN THE YEAR 2003, THE OMEGA SYSTEM DEVELOPED A METHOD OF TRAINING ITS '
    'WARRIORS TO PROTECT THEIR STAR COLONIES OVER THE CITY OF KOMAR. '
    'ANDROID CONTROLLED FIGHTERS RACED TO ENGAGE AND DESTROY THESE OMEGAN WARRIORS.',
    'POINTS WERE AWARDED FOR THE ABILITY TO NEUTRALIZE THIS DROID FORCE AS FOLLOWS',
]
first_lines = textwrap.wrap(paragraphs[0], 28) + [''] + textwrap.wrap(paragraphs[1], 28)
assert len(first_lines) == 12 and max(map(len, first_lines)) <= 28
third = ('THE OMEGAN METHOD IS SO SUCCESSFUL. IT COMMANDS FEAR AND RESPECT '
         'FROM ALL THROUGHOUT THE GALAXIES. THE METHOD IS CODE NAMED...')
third_lines = textwrap.wrap(third, 28)
assert len(third_lines) == 5

def script(lines):
    out = []
    for n,line in enumerate(lines):
        out += list(map(glyph20,line))
        if n != len(lines)-1: out.append(0xFF)
    return out+[0xFE]

story_one = script(first_lines)
assert 256 < len(story_one) <= 512
data['omega_attract_story_one_a20'] = story_one[:256]
data['omega_attract_story_one_b20'] = story_one[256:]
data['omega_attract_story_three_text20'] = script(third_lines)

def line_addresses(rows, texts, center):
    positions = [0x2000 + row*32 + ((32-len(text))//2 if center else 2)
                 for row,text in zip(rows,texts)]
    return [a&255 for a in positions],[a>>8 for a in positions]

lo,hi = line_addresses(range(6,18), first_lines, False)
data['omega_attract_story_one_lo20'] = lo
data['omega_attract_story_one_hi20'] = hi
lo,hi = line_addresses((5,7,9,11,13), third_lines, True)
data['omega_attract_story_three_lo20'] = lo
data['omega_attract_story_three_hi20'] = hi

scores = ('350 POINTS', '1000 POINTS', '1500 POINTS', '2500 POINTS')
data['omega_attract_score_text20'] = [glyph20(c) for line in scores for c in line.ljust(12)]
score_addrs = [0x2000 + r*32 + 12 for r in (7,12,17,22)]
data['omega_attract_score_lo20'] = [a&255 for a in score_addrs]
data['omega_attract_score_hi20'] = [a>>8 for a in score_addrs]
data['omega_attract_icon_y20'] = [(r*8)-1 for r in (7,12,17,22)]
data['omega_attract_icon_tile20'] = [0xEC,0xE0,0xE4,0xE8]
data['omega_attract_icon_palette20'] = [1,3,1,1]

title = b''.join(bytes(data[f'title_nt{i}']) for i in range(4))
data['omega_attract_logo_tiles20'] = [title[row*32+x] for row in range(6,12) for x in range(4,28)]
assert len(data['omega_attract_logo_tiles20']) == 144
logo_addrs = [0x2000 + row*32 + 4 for row in range(17,23)]
data['omega_attract_logo_lo20'] = [a&255 for a in logo_addrs]
data['omega_attract_logo_hi20'] = [a>>8 for a in logo_addrs]
attrs = bytearray(64)
for y in range(17,23):
    for x in range(4,28):
        idx=(y//4)*8+x//4
        shift=((y//2)%2)*4+((x//2)%2)*2
        attrs[idx] |= 1<<shift
data['omega_attract_logo_attrs20'] = list(attrs)
data['omega_attract_flash_colors20'] = [0x38,0x28,0x18,0x16,0x06,0x0F]

# Earlier title art uses A-Z and numbers only.  Supply punctuation for the
# arcade story in two free background CHR slots, leaving all prior art intact.
omega_story_punctuation20 = {
    0x8B: ['00000000','00000000','00000000','00000000',
           '00000000','00000000','00033000','00033000'],
    0x8C: ['00000000','00000000','00000000','00000000',
           '00000000','00033000','00033000','00030000'],
}
