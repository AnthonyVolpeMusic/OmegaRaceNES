# Omega Race NES — Version 15 level-clear song

Baseline: Version 14.

- Adds the synchronized two-voice level-clear song on Pulse 1 and Pulse 2.
- Each measure lasts 48 frames; the complete four-measure tune lasts 192
  frames (about 3.2 seconds at 60 Hz).
- The tune waits for the final enemy destruction sound—or a simultaneous
  extra-life cue—to finish before taking ownership of both pulse channels.
- The song completes within the existing five-second level intermission.
- Existing gameplay and Version 14 effects remain unchanged.

Build: `python3 prototype/build_omega_base_v15.py`

Test: `python3 prototype/test_omega_v15.py`
