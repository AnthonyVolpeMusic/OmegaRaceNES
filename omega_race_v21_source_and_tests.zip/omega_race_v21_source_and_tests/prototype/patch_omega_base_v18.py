"""Omega Race Version 18: title fixes and dual-pulse gameplay SFX."""

import re

code = '\n'.join(lines)

# SELECT cycles through exactly THREE, FIVE, and SEVEN.
old = '''INC $9A
LDA $9A
CMP #$06
BCC omega_title_lives_ready17
LDA #$01
STA $9A
omega_title_lives_ready17:'''
new = '''LDA $9A
CMP #$03
BEQ omega_title_choose_five18
CMP #$05
BEQ omega_title_choose_seven18
LDA #$03
BNE omega_title_choice_ready18
omega_title_choose_five18:
LDA #$05
BNE omega_title_choice_ready18
omega_title_choose_seven18:
LDA #$07
omega_title_choice_ready18:
STA $9A'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Map actual lives values 3/5/7 to fixed five-character word records 0/5/10.
old = '''LDA $9A
SEC
SBC #$01
ASL A
ASL A
CLC
ADC $9A
SEC
SBC #$01
TAX'''
new = '''LDX #$00
LDA $9A
CMP #$03
BEQ omega_title_word_ready18
LDX #$05
CMP #$05
BEQ omega_title_word_ready18
LDX #$0A
omega_title_word_ready18:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Tick the second Omega pulse voice once per frame alongside Pulse 1.
old = '''sfx_tick25:
JSR omega_pulse1_tick14
LDA $D6'''
new = '''sfx_tick25:
JSR omega_pulse1_tick14
JSR omega_pulse2_tick18
LDA $D6'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Legacy Pulse 2 cues (shield/stop and inherited special effects) may start
# only while the second Omega SFX voice is free.
old = '''pulse2_start26:
PHA
LDA $D7'''
new = '''pulse2_start26:
PHA
LDA $06A0
BEQ pulse2_omega_free18
PLA
RTS
pulse2_omega_free18:
LDA $D7'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''pulse2_tick26:
LDA $D7'''
new = '''pulse2_tick26:
LDA $06A0
BNE pulse2_done26
LDA $D7'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Replace the single-channel starter with a two-channel allocator.  It chooses
# a free pulse voice first, alternates when both are free, and otherwise
# replaces only the lower-priority voice when the incoming effect qualifies.
start = code.index('omega_pulse1_start14:\n')
end = code.index('omega_pulse1_tick14:\n', start)
allocator = '''omega_pulse1_start14:
PHA
LDA $D7
CMP #$FF
BNE omega_dual_song_free18
PLA
RTS
omega_dual_song_free18:
PLA
STA $D4
PHP
PHA
TXA
PHA
TYA
PHA
LDX $D4
LDY omega_sfx_priority14,X
LDA $82
BNE omega_dual_voice1_busy18
LDA $06A0
BNE omega_dual_accept_voice1_18
LDA $89
BNE omega_dual_accept_voice1_18
LDA $06A5
EOR #$01
STA $06A5
BNE omega_dual_accept_voice1_18
JMP omega_dual_accept_voice2_18
omega_dual_voice1_busy18:
LDA $06A0
BNE omega_dual_both_busy18
LDA $89
BNE omega_dual_consider_voice1_18
JMP omega_dual_accept_voice2_18
omega_dual_both_busy18:
LDA $D3
CMP $06A3
BCC omega_dual_consider_voice1_18
BNE omega_dual_consider_voice2_18
LDA $06A5
EOR #$01
STA $06A5
BEQ omega_dual_consider_voice1_18
omega_dual_consider_voice2_18:
TYA
CMP $06A3
BCC omega_dual_reject18
JMP omega_dual_accept_voice2_18
omega_dual_consider_voice1_18:
TYA
CMP $D3
BCC omega_dual_reject18
omega_dual_accept_voice1_18:
STX $D2
STY $D3
LDA omega_sfx_length14,X
STA $82
LDA #$00
STA $83
LDA #$FF
STA $D5
LDA $86
ORA #$01
STA $86
STA $4015
JSR omega_pulse1_output14
JMP omega_dual_done18
omega_dual_accept_voice2_18:
STX $06A2
STY $06A3
LDA omega_sfx_length14,X
STA $06A0
LDA #$00
STA $06A1
LDA #$FF
STA $06A4
LDA #$00
STA $4005
LDA $86
ORA #$02
STA $86
STA $4015
JSR omega_pulse2_output18
JMP omega_dual_done18
omega_dual_reject18:
omega_dual_done18:
PLA
TAY
PLA
TAX
PLA
PLP
RTS
'''
code = code[:start] + allocator + code[end:]

# Derive the Pulse 2 renderer from the proven Pulse 1 renderer, changing only
# its private state and APU register destinations.
out_start = code.index('omega_pulse1_output14:\n')
out_end = code.index('omega_death_sfx_start14:\n', out_start)
voice2_output = code[out_start:out_end]
internal_labels = re.findall(r'^([a-zA-Z_][a-zA-Z0-9_]*):', voice2_output, re.M)
for label in sorted(internal_labels, key=len, reverse=True):
    voice2_output = re.sub(r'\b' + re.escape(label) + r'\b', label.replace('14', '18'), voice2_output)
voice2_output = voice2_output.replace('omega_pulse1_output18', 'omega_pulse2_output18')
for old_state, new_state in (
    ('$D2', '$06A2'), ('$D3', '$06A3'), ('$D4', '$06A6'),
    ('$D5', '$06A4'), ('$82', '$06A0'), ('$83', '$06A1'),
    ('$4000', '$4004'), ('$4002', '$4006'), ('$4003', '$4007'),
):
    voice2_output = re.sub(r'(?<!#)' + re.escape(old_state) + r'\b', new_state, voice2_output)

voice2_tick = '''omega_pulse2_tick18:
LDA $06A0
BEQ omega_pulse2_tick_done18
INC $06A1
DEC $06A0
BEQ omega_pulse2_stop18
JSR omega_pulse2_output18
RTS
omega_pulse2_stop18:
LDA #$00
STA $06A2
STA $06A3
LDA #$B0
STA $4004
LDA $86
AND #$FD
STA $86
STA $4015
omega_pulse2_tick_done18:
RTS
'''
code = code[:out_end] + voice2_tick + voice2_output + code[out_end:]

# Death, audio reset, and level-clear music retain exclusive channel ownership.
old = '''STA $87
STA $88
STA $89
STA $8A
STA $8B
STA $8C
STA $D2'''
new = '''STA $87
STA $88
STA $89
STA $8A
STA $8B
STA $8C
STA $06A0
STA $06A1
STA $06A2
STA $06A3
STA $06A4
STA $D2'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''STA $87
STA $88
STA $89
STA $D2'''
new = '''STA $87
STA $88
STA $89
STA $06A0
STA $06A1
STA $06A2
STA $06A3
STA $06A4
STA $D2'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''STA $82
STA $83
STA $87
STA $89
LDA #$08'''
new = '''STA $82
STA $83
STA $87
STA $89
STA $06A0
STA $06A1
STA $06A2
STA $06A3
STA $06A4
LDA #$08'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# The additional dual-voice reset bytes make this inherited song branch exceed
# the 6502's signed 8-bit branch range; use the equivalent long form.
original = '''LDA $82
BNE omega_level_song_return15
LDA #$FF'''
new = '''LDA $82
ORA $06A0
BEQ omega_level_song_start18
JMP omega_level_song_return15
omega_level_song_start18:
LDA #$FF'''
assert code.count(original) == 1
code = code.replace(original, new, 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]

# The same table label is retained, but now contains only the three requested
# five-character choices.
def omega_glyph18(ch):
    if ch == ' ':
        return 0
    return 0x61 + ord(ch) - ord('A')

data['omega_lives_words17'] = [
    omega_glyph18(ch) for word in ('THREE', 'FIVE ', 'SEVEN') for ch in word
]

# Signals the final CHR stage to install a known-good colon drawing at $8A.
omega_colon_tile18 = [
    [int(c) for c in row] for row in (
        '00000000', '00033000', '00033000', '00000000',
        '00000000', '00033000', '00033000', '00000000',
    )
]
