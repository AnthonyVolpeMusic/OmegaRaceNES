"""Machine-code regression tests for Omega Race Version 10."""
from pathlib import Path

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
text = base.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v10.nes')
text = text.replace('symbols_omega_base_v1.json', 'symbols_omega_v10.json')
text = text.replace('range(400000)', 'range(900000)')
env = {'__file__': str(P / 'test_omega_v10.py')}
exec(compile(text, 'harness', 'exec'), env)
boot, call, S = env['boot'], env['call'], env['S']


mm, cc = boot()
expected_palette = [
    0x08,0x18,0x28,0x38, 0x0F,0x16,0x28,0x08,
    0x0F,0x0F,0x0F,0x0F, 0x0F,0x0F,0x0F,0x0F,
    0x08,0x38,0x18,0x28, 0x08,0x16,0x27,0x38,
    0x08,0x28,0x38,0x18, 0x08,0x00,0x26,0x36,
]
assert any(mm.ppu[i:i+32] == expected_palette for i in range(len(mm.ppu) - 31))
call(mm, cc, 'render')
assert mm[0x216] == 1                 # starting Commander
assert all(mm[a] == 3 for a in range(0x21A, 0x232, 4))  # six basic drones
mm[0x580:0x58A] = [0xFF,0,80,0,80,0,0,0,0,0]
call(mm, cc, 'render')
assert mm[0x256] == 1
print('PASS drone, Commander and Commander-missile palettes match the requested colors')

# 75% retention works as signed 8.8 arithmetic on both axes.
mm, cc = boot()
mm[0x14:0x18] = [0x00,0x01,0x00,0xFF]  # +1.0 X, -1.0 Y
call(mm, cc, 'omega_halve_ship_speed_v4')
assert mm[0x14:0x18] == [0xC0,0x00,0x40,0xFF]
mm[0x14:0x18] = [0x00,0x02,0x00,0xFE]  # +2.0 X, -2.0 Y
call(mm, cc, 'omega_halve_ship_speed_v4')
assert mm[0x14:0x18] == [0x80,0x01,0x80,0xFE]
print('PASS all wall bounces retain 75% of signed ship velocity')

# 39,999 + 1 grants the first and only first bonus life at 40,000.
mm, cc = boot()
mm[0x30:0x33] = [0x3F,0x9C,0x00]
mm[0x33:0x39] = [9,9,9,9,3,0]
cc.a = 1
call(mm, cc, 'score_add')
assert mm[0x30:0x33] == [0x40,0x9C,0x00]
assert mm[0x3D] == 4 and mm[0xCA] == 1
assert mm[0xA7] & 0x04
mm[0xA7] = 0
cc.a = 0xFA
call(mm, cc, 'score_add')
assert mm[0x3D] == 4 and mm[0xCA] == 1 and not (mm[0xA7] & 0x04)
print('PASS exactly one extra life is granted at 40,000')

# 99,999 + 1 grants the second and final bonus; later scores cannot create
# another life even if they cross far beyond both thresholds.
mm, cc = boot()
mm[0xCA] = 1
mm[0x30:0x33] = [0x9F,0x86,0x01]
mm[0x33:0x39] = [9,9,9,9,9,0]
cc.a = 1
call(mm, cc, 'score_add')
assert mm[0x30:0x33] == [0xA0,0x86,0x01]
assert mm[0x3D] == 4 and mm[0xCA] == 3
mm[0xA7] = 0
cc.a = 0xFA
call(mm, cc, 'score_add')
assert mm[0x3D] == 4 and mm[0xCA] == 3 and not (mm[0xA7] & 0x04)
print('PASS exactly one additional extra life is granted at 100,000, then never again')

# Run the maximum level under the real frame loop to retain Version 9 timing.
mm, cc = boot()
mm[0xC0] = 7
call(mm, cc, 'omega_level_setup9')
mm.ppu = []
mm.pad = 0
cc.pc = S['main']
cc.sp = 255
deadline = cc.processorCycles
for _ in range(240):
    end = deadline + 29781
    while cc.processorCycles < end:
        if cc.processorCycles >= deadline:
            cc.nmi()
            deadline += 29781
        cc.step()
assert 238 <= mm.dmas <= 240 and len(mm.ppu) <= 8
print('PASS Version 10 palette and scoring changes retain maximum-wave frame stability')
