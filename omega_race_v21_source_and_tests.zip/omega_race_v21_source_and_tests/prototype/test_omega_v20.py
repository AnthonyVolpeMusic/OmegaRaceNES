"""Machine checks for Omega Race V20's complete attract sequence."""
from pathlib import Path
import json

P = Path(__file__).parent
source = (P/'test_omega_v19.py').read_text().split('# The actual first vblank')[0]
source = source.replace('omega_race_v19.nes','omega_race_v20.nes')
source = source.replace('symbols_omega_v19.json','symbols_omega_v20.json')
env = {'__file__': str(P/'test_omega_v20.py')}
exec(compile(source,'v20 machine harness','exec'), env)
boot,call = env['boot'],env['call']
base_glyph = env['glyph']
def glyph(ch):
    if ch=='.': return 0x8B
    if ch==',': return 0x8C
    return base_glyph(ch)
symbols = json.loads((P/'symbols_omega_v20.json').read_text())
rom = (P/'omega_race_v20.nes').read_bytes()
chrdata = rom[32784:]

def nmi(m,c):
    m[0] = 1
    c.pc,c.sp = 0x7fff,255
    c.nmi()
    for _ in range(20000):
        c.step()
        if c.pc == 0x7fff: return
    raise AssertionError('NMI failed to return')

def text_at(m,row,col,string):
    got = [m.name.get(0x2000+row*32+col+i) for i in range(len(string))]
    assert got == list(map(glyph,string)),(row,col,string,got)

def tick(m,c,count):
    for _ in range(count):
        call(m,c,'omega_attract_tick20')
        nmi(m,c)

m,c=boot()
assert m[0x06B0] == 0 and any(m.name[0x2000+6*32+x] for x in range(4,28))
for _ in range(599): call(m,c,'omega_attract_gate20')
assert m[0x06B0] == 0
call(m,c,'omega_attract_gate20')
assert m[0x06B0] == 1 and m.name[0x2000+6*32+4] == 0
call(m,c,'omega_attract_tick20')
nmi(m,c)
text_at(m,6,2,'I')
tick(m,c,4)
nmi(m,c)
assert m.name[0x20C3] == 0
call(m,c,'omega_attract_tick20')
nmi(m,c)
text_at(m,6,2,'IN')
print('PASS original title idles for 600 frames, then screen one types at five-frame intervals')

for _ in range(1600):
    if m[0x06B0] == 2: break
    call(m,c,'omega_attract_tick20')
    nmi(m,c)
assert m[0x06B0] == 2
nmi(m,c)
assert m.name[0x2000+17*32+2+21] == glyph('S')
story_one_lines=(
    'IN THE YEAR 2003, THE OMEGA',
    'SYSTEM DEVELOPED A METHOD OF',
    'TRAINING ITS WARRIORS TO',
    'PROTECT THEIR STAR COLONIES',
    'OVER THE CITY OF KOMAR.',
    'ANDROID CONTROLLED FIGHTERS',
    'RACED TO ENGAGE AND DESTROY',
    'THESE OMEGAN WARRIORS.',
    '',
    'POINTS WERE AWARDED FOR THE',
    'ABILITY TO NEUTRALIZE THIS',
    'DROID FORCE AS FOLLOWS',
)
for row,line in enumerate(story_one_lines,6):
    if line: text_at(m,row,2,line)
tick(m,c,299)
assert m[0x06B0] == 2
tick(m,c,1)
assert m[0x06B0] == 3
for row,score in ((7,'350 POINTS'),(12,'1000 POINTS'),(17,'1500 POINTS'),(22,'2500 POINTS')):
    text_at(m,row,12,score)
call(m,c,'render')
assert [m[0x201+4*i] for i in range(4)] == [0xEC,0xE0,0xE4,0xE8]
assert [m[0x202+4*i] for i in range(4)] == [1,3,1,1]
tick(m,c,599)
assert m[0x06B0] == 3
tick(m,c,1)
assert m[0x06B0] == 4
print('PASS story holds five seconds and four correct enemy scores remain ten seconds')

for _ in range(800):
    if m[0x06B0] == 5: break
    call(m,c,'omega_attract_tick20')
    nmi(m,c)
assert m[0x06B0] == 5
nmi(m,c)
for row,line in zip((5,7,9,11,13),(
    'THE OMEGAN METHOD IS SO',
    'SUCCESSFUL. IT COMMANDS FEAR',
    'AND RESPECT FROM ALL',
    'THROUGHOUT THE GALAXIES. THE',
    'METHOD IS CODE NAMED...',
)):
    text_at(m,row,(32-len(line))//2,line)
logo_tiles = rom[16+symbols['title_nt0']-0x8000:16+symbols['title_nt0']-0x8000+256]
assert m.name[0x2000+17*32+4] == logo_tiles[6*32+4]
assert m.name[0x3f00] == 0x38 and m[0xD6] == 1
assert m[0x84] == 60 and m[0x86]&8
for frame in range(1,61):
    call(m,c,'sfx_tick25')
    call(m,c,'omega_attract_tick20')
    nmi(m,c)
    if frame % 10 == 0 and frame <= 50:
        assert m.name[0x3f00] == [0x28,0x18,0x16,0x06,0x0f][frame//10-1]
assert m[0x06B0] == 6 and m[0xD6] == 0 and not m[0x86]&8
tick(m,c,299)
assert m[0x06B0] == 6
tick(m,c,1)
assert m[0x06B0] == 0 and m.name[0x3f00] == 0x0f
assert m.name[0x2000+6*32+4] == logo_tiles[6*32+4]
print('PASS final story, logo reveal, six-color one-second explosion and five-second return')

# Start and Select each cancel an attract screen without triggering their
# normal title action on the same held keypress.
for mode,pad in ((1,0x20),(3,0x10),(5,0x10)):
    m,c=boot()
    if mode==1: call(m,c,'omega_attract_story_one20')
    if mode==3: call(m,c,'omega_attract_scores20')
    if mode==5:
        call(m,c,'omega_attract_story_three20')
        call(m,c,'omega_attract_reveal20')
    initial=m[0x9A]
    m.pad=pad
    call(m,c,'controls')
    assert m[0x06B0]==0 and m[6]==0 and m[0x9A]==initial
    assert m.name[0x3f00]==0x0f and m[0xD6]==0
    call(m,c,'controls')
    assert m[6]==0 and m[0x9A]==initial
    m.pad=0
    call(m,c,'controls')
    m.pad=0x10
    call(m,c,'controls')
    assert m[6]==1 and m[0x06B0]==0 and m[0x3D]==initial
print('PASS Start/Select cancel all attract stages without also starting or changing lives')

for index in (0x8B,0x8C):
    assert any(chrdata[index*16:index*16+16])
print('PASS punctuation tiles are installed in the background pattern table')
