"""Version 12B: working shields and immediate, reliable level palettes."""

code = '\n'.join(lines)

# Shield energy and animation already worked, but the Omega-specific player
# collision pass introduced in V9 never honored the active shield timer.
old = '''omega_player_collision9:
LDA $0677
BEQ omega_player_collision_start9
JMP omega_player_collision_done9
omega_player_collision_start9:'''
new = '''omega_player_collision9:
LDA $08
BEQ omega_player_collision_state12b
RTS
omega_player_collision_state12b:
LDA $0677
BEQ omega_player_collision_start9
JMP omega_player_collision_done9
omega_player_collision_start9:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Service pending palette changes at the start of the first VBlank, even when
# the normal frame/OAM handshake is waiting for lengthy level initialization.
old = '''INC $A0
LDA $A2'''
new = '''INC $A0
JSR omega_palette_flush12b
LDA $A2'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Palette writes no longer live inside the frame-gated HUD writer.
old = '''omega_palette_check12a:
LDA $A7
AND #$08
BEQ omega_hud_flush_clear_v5a
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDA $CF
ASL A
ASL A
TAX
LDY #$00
omega_palette_write12a:
LDA omega_tile_palettes12a,X
STA $2007
INX
INY
CPY #$04
BNE omega_palette_write12a
omega_hud_flush_clear_v5a:'''
new = '''omega_palette_check12a:
omega_hud_flush_clear_v5a:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += '''
omega_palette_flush12b:
LDA $A7
AND #$08
BEQ omega_palette_flush_done12b
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDA $CF
ASL A
ASL A
TAX
LDY #$00
omega_palette_write12b:
LDA omega_tile_palettes12a,X
STA $2007
INX
INY
CPY #$04
BNE omega_palette_write12b
LDA $A7
AND #$F7
STA $A7
LDA #$00
STA $2005
STA $2005
omega_palette_flush_done12b:
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]
