"""Full V4 regression suite with V4A top-boundary expectations."""
from pathlib import Path

P = Path(__file__).parent
source = (P / 'test_omega_v4.py').read_text()
source = source.replace('omega_race_v4_narrow_track_test.nes',
                        'omega_race_v4a_top_border_test.nes')
source = source.replace('symbols_omega_v4.json', 'symbols_omega_v4a.json')
source = source.replace('(100,12,1,0xff,[0x80,0x00,0x80,0x00])',
                        '(100,10,1,0xff,[0x80,0x00,0x80,0x00])')
source = source.replace('(100,16,0,0xff)', '(100,10,0,0xff)')
source = source.replace('mm[0x13]=12;mm[0x16]=0;mm[0x17]=0xff',
                        'mm[0x13]=10;mm[0x16]=0;mm[0x17]=0xff')
source = source.replace('assert mm[0x13]==12 and mm[0x17]==0',
                        'assert mm[0x13]==10 and mm[0x17]==0')
source = source.replace('top-wall origin remains four pixels closer',
                        'top-wall origin is two pixels farther north in V4A')
exec(compile(source, str(P / 'test_omega_v4.py'), 'exec'))
