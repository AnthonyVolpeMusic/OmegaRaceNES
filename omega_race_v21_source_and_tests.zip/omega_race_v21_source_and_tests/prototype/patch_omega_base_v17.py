"""Omega Race Version 17 title screen and selectable starting lives."""

from PIL import Image

code = '\n'.join(lines)

# Replace the direct-to-game startup with the new title screen.  Gameplay is
# still initialized behind it, but remains frozen until Start is pressed.
old = '''JSR omega_load_playfield_v3
LDA #$01
STA $06
STA $8E'''
new = '''JSR load_title
LDA #$00
STA $06
LDA #$01
STA $8E
LDA #$03
STA $9A'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Keep title mode completely static apart from input and presentation.
old = '''JSR omega_frame9
LDA #$01
STA $00'''
new = '''JSR omega_dispatch17
LDA #$01
STA $00'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# SELECT cycles one through five starting lives.  START builds a fresh Level 1
# playfield and transfers the selected value into the gameplay lives counter.
start = code.index('LDA $06\nBNE game_controls\n')
end = code.index('game_controls:\n', start)
title_controls = '''LDA $06
BNE game_controls
LDA $02
EOR #$FF
AND $01
AND #$20
BEQ omega_title_start_check17
INC $9A
LDA $9A
CMP #$06
BCC omega_title_lives_ready17
LDA #$01
STA $9A
omega_title_lives_ready17:
LDA $A7
ORA #$80
STA $A7
omega_title_start_check17:
LDA $02
EOR #$FF
AND $01
AND #$10
BEQ title_controls_done
JSR omega_start_game17
title_controls_done:
RTS
'''
code = code[:start] + title_controls + code[end:]

# Flush the selected word during vblank.  This precedes the normal HUD flush;
# it is active only while the title screen owns the nametable.
old = '''JSR omega_palette_flush12b
LDA $A2'''
new = '''JSR omega_palette_flush12b
JSR omega_title_flush17
LDA $A2'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Add title dispatch/start/field-update routines before the normal game frame.
insert = '''omega_dispatch17:
LDA $06
BNE omega_dispatch_game17
JSR controls
JMP render
omega_dispatch_game17:
JMP omega_frame9

omega_start_game17:
LDA #$00
STA $2001
STA $30
STA $31
STA $32
STA $33
STA $34
STA $35
STA $36
STA $37
STA $38
STA $CA
LDA #$01
STA $C0
LDA $9A
STA $3D
JSR omega_load_playfield_v3
JSR omega_level_setup9
LDA #$07
STA $A7
LDA #$01
STA $06
LDA #$1E
STA $2001
RTS

omega_title_flush17:
LDA $06
BNE omega_title_flush_done17
LDA $A7
AND #$80
BEQ omega_title_flush_done17
LDA #$21
STA $2006
LDA #$D5
STA $2006
LDA $9A
SEC
SBC #$01
ASL A
ASL A
CLC
ADC $9A
SEC
SBC #$01
TAX
LDY #$00
omega_title_word_loop17:
LDA omega_lives_words17,X
STA $2007
INX
INY
CPY #$05
BNE omega_title_word_loop17
LDA $A7
AND #$7F
STA $A7
omega_title_flush_done17:
RTS

'''
assert code.count('omega_frame9:\n') == 1
code = code.replace('omega_frame9:\n', insert + 'omega_frame9:\n', 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]

# Title background palette 1: transparent/dark, orange, yellow, red.
data['palette'][4:8] = [0x08, 0x18, 0x28, 0x16]

def glyph(ch):
    if ch == ' ':
        return 0
    if ch == ':':
        return 0x8A
    if '0' <= ch <= '9':
        return 0x7B + ord(ch) - ord('0')
    return 0x61 + ord(ch) - ord('A')

title = bytearray(1024)

def set_palette(tx, ty, palette_index):
    i = 960 + (ty // 4) * 8 + (tx // 4)
    shift = ((ty // 2) % 2) * 4 + ((tx // 2) % 2) * 2
    title[i] = (title[i] & ~(3 << shift)) | (palette_index << shift)

def centered_text(row, text):
    x = (32 - len(text)) // 2
    for ch in text:
        title[row * 32 + x] = glyph(ch)
        x += 1

# Convert the supplied 192x48 logo into deduplicated NES tiles.  The near-black
# source color is transparency/background; brown, yellow, and red are indices
# 1, 2, and 3 of title background palette 1.
logo_path = P.parent / 'upload' / '01-Omega-Race-Logo.png'
if not logo_path.is_file():
    logo_path = P.parent.parent / 'upload' / '01-Omega-Race-Logo.png'
im = Image.open(logo_path).convert('RGB')
assert im.size == (192, 48)
source_to_index = {
    (2, 1, 0): 0,
    (135, 65, 0): 1,
    (241, 231, 0): 2,
    (245, 22, 0): 3,
}
unique = {}
omega_logo_tiles17 = []
for ty in range(6):
    for tx in range(24):
        pixels = tuple(
            source_to_index[im.getpixel((tx * 8 + x, ty * 8 + y))]
            for y in range(8) for x in range(8)
        )
        if all(pixel == 0 for pixel in pixels):
            tile_index = 0
        else:
            tile_index = unique.get(pixels)
            if tile_index is None:
                tile_index = len(omega_logo_tiles17) + 1
                assert tile_index < 0x61
                unique[pixels] = tile_index
                omega_logo_tiles17.append(pixels)
        screen_x, screen_y = 4 + tx, 3 + ty
        title[screen_y * 32 + screen_x] = tile_index
        set_palette(screen_x, screen_y, 1)

assert len(omega_logo_tiles17) == 70
centered_text(12, 'PRESS SELECT TO CHOOSE')
centered_text(14, 'STARTING LIVES: THREE')
centered_text(19, 'PRESS START TO BEGIN')

data['title_nt0'] = title[:256]
data['title_nt1'] = title[256:512]
data['title_nt2'] = title[512:768]
data['title_nt3'] = title[768:]
data['omega_lives_words17'] = [
    glyph(ch) for word in ('ONE  ', 'TWO  ', 'THREE', 'FOUR ', 'FIVE ')
    for ch in word
]
