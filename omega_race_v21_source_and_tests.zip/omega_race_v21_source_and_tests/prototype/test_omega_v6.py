"""Machine-code tests for Version 6, including V5A differential checks."""
import json
from pathlib import Path
P=Path(__file__).parent
base=(P/'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
def harness(rom,symbols):
    text=base.replace('omega_race_player_base_v2_palette_test.nes',rom)
    text=text.replace('symbols_omega_base_v1.json',symbols)
    text=text.replace('range(400000)','range(600000)')
    env={'__file__':str(P/'test_omega_v6.py')}
    exec(compile(text,'harness','exec'),env)
    return env
new=harness('omega_race_v6_drone_test.nes','symbols_omega_v6.json')
old=harness('omega_race_v5a_event_hud_test.nes','symbols_omega_v5a.json')
boot,call=new['boot'],new['call']
mm,cc=boot()
assert mm[0x11]==224 and mm[0x13]==24 and mm[7]==5 and mm[0x3d]==3
om,oc=old['boot']()
assert mm.ppu==om.ppu
assert new['CHR'][:4096]==old['CHR'][:4096]
assert new['CHR'][4096:4096+0xe0*16]==old['CHR'][4096:4096+0xe0*16]
print('PASS unchanged HUD, palettes, borders, ship, projectile and impact graphics')

# Independently transcribed supplied emoji artwork; compare all 256 pixels.
art=[
 ['⬛⬛🟧🟧🟨⬜⬛⬛','⬛⬜🟧🟧🟧🟧🟧⬛','🟨🟧🟧🟧🟧🟧🟧🟧','🟧🟧🟧⬛⬛🟧🟧🟨','🟧🟧🟧⬛⬛🟧🟧⬜','⬜🟧🟧🟧🟧🟧🟧🟧','⬛🟨🟧🟧🟧🟧🟧⬛','⬛⬛🟧🟧⬜🟨⬛⬛'],
 ['⬛⬛⬜🟧🟧🟨⬛⬛','⬛🟨🟧🟧🟧🟧⬜⬛','🟧🟧🟧🟨🟨🟧🟧🟧','🟧🟧🟨⬛⬛🟨🟧🟧','⬜🟧🟨⬛⬛🟨🟧🟨','🟨🟧🟧🟨🟨🟧🟧⬜','⬛🟧🟧🟧🟧🟧🟧⬛','⬛⬛🟧⬜🟨🟧⬛⬛'],
 ['⬛⬛🟨⬜🟧🟧⬛⬛','⬛🟧🟧🟧🟧🟧🟨⬛','🟧🟧🟧⬜⬜🟧🟧⬜','⬜🟧⬜⬛⬛⬜🟧🟧','🟨🟧⬜⬛⬛⬜🟧🟧','🟧🟧🟧⬜⬜🟧🟧🟨','⬛🟧🟧🟧🟧🟧⬜⬛','⬛⬛⬜🟨🟧🟧⬛⬛'],
 ['⬛⬛🟧🟨⬜🟧⬛⬛','⬛🟧🟧🟧🟧🟧🟧⬛','⬜🟧🟧🟨🟨🟧🟧🟨','🟨🟧🟨⬛⬛🟨🟧⬜','🟧🟧🟨⬛⬛🟨🟧🟧','🟧🟧🟧🟨🟨🟧🟧🟧','⬛⬜🟧🟧🟧🟧🟨⬛','⬛⬛🟨🟧🟧⬜⬛⬛']]
for f,rows in enumerate(art):
    at=(0x1e0+f)*16
    for y,row in enumerate(rows):
        for x,ch in enumerate(row):
            actual=((new['CHR'][at+y]>>(7-x))&1)|(((new['CHR'][at+8+y]>>(7-x))&1)<<1)
            assert actual=={'⬛':0,'🟧':1,'🟨':2,'⬜':3}[ch],(f,x,y)
print('PASS all four supplied drawings match ROM pixels exactly')

mm,cc=boot()
for frame in range(49):
    call(mm,cc,'render')
    for a in range(0x214,0x224,4):
        assert mm[a+1]==0xe0+(frame//6)%4 and mm[a+2]==3
    call(mm,cc,'drone_tick6')
print('PASS 1-2-3-4 loop, exactly six simulation frames per drawing')

# Both travel directions complete several laps without touching any wall.
mm,cc=boot();seen=[set() for _ in range(4)];travel=[0]*4
for tick in range(6000):
    before=[tuple(mm[a:a+2]) for a in range(0x300,0x340,16)]
    call(mm,cc,'drone_tick6')
    for i,a in enumerate(range(0x300,0x340,16)):
        x,y=mm[a:a+2];seen[i].add(mm[a+2])
        assert 1<x<247 and 9<y<224
        assert not (x+7>=72 and x<=183 and y+7>=80 and y<=159),(tick,i,x,y)
        dx,dy=x-before[i][0],y-before[i][1]
        assert abs(dx)<=1 and abs(dy)<=1
        travel[i]+=(dx*dx+dy*dy)**0.5
    assert mm[7]==5 and mm[0x3d]==3 and mm[0x33:0x39]==[0]*6
assert all(s==set(range(8)) for s in seen)
assert all(2980<t<3020 for t in travel),travel
print('PASS 100 seconds, full laps in both directions, wall clearance and uniform speed')

# Existing player movement, shots and controls are byte-identical in outcome.
for heading in range(48):
    a,ca=boot();b,cb=old['boot']()
    for m in (a,b):m[1]=0x88;m[3]=heading
    call(a,ca,'game_controls');old['call'](b,cb,'game_controls')
    for routine in ('physics','bullets'):
        call(a,ca,routine);old['call'](b,cb,routine)
    assert a[0:0xa8]==b[0:0xa8]
    assert a[0x600:0x800]==b[0x600:0x800]
print('PASS differential V5A controls/physics/projectiles across all 48 headings')

def nmi(m,c,ready=1):
    m.ppu=[];m[0]=ready;m[0xa2]=0;c.pc=0x7fff;c.sp=255;c.nmi()
    start=c.processorCycles
    for _ in range(20000):
        c.step()
        if c.pc==0x7fff:break
    else:raise AssertionError('NMI timeout')
    assert c.processorCycles-start+514<2200
mm,cc=boot();nmi(mm,cc);assert not mm.ppu
mm[1]=0x40;mm[2]=0;call(mm,cc,'game_controls');nmi(mm,cc)
assert mm.ppu==[0x7f];nmi(mm,cc);assert not mm.ppu
print('PASS event-driven HUD and vblank budget remain intact')

# Run actual main/NMI handshake with thrust and firing for three seconds.
mm,cc=boot();mm.ppu=[];mm.pad=0x88;cc.pc=new['S']['main'];cc.sp=255
deadline=cc.processorCycles
for frame in range(180):
    end=deadline+29781
    while cc.processorCycles<end:
        if cc.processorCycles>=deadline:cc.nmi();deadline+=29781
        cc.step()
assert not mm.ppu and 178<=mm.dmas<=180
assert mm[7]==5 and mm[0x3d]==3 and mm[0x33:0x39]==[0]*6
assert all(mm[a]!=0xf8 for a in range(0x214,0x224,4))
print('PASS real main/NMI execution with ship, four drones and shots; no damage or scoring')
