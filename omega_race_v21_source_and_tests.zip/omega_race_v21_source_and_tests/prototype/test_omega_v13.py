"""Machine-code regression tests for Omega Race Version 13."""
import json
from pathlib import Path
from py65.devices.mpu6502 import MPU

P = Path(__file__).parent
S = json.loads((P / 'symbols_omega_v13.json').read_text())
IMAGE = (P / 'omega_race_v13.nes').read_bytes()
ROM = IMAGE[16:32784]


class Memory(list):
    def __init__(self):
        super().__init__([0] * 65536)
        self.ppu = []
        self.dmas = 0
        self.pad = 0
        self.index = 0

    def __getitem__(self, key):
        if key == 0x2002:
            return 0x80
        if key == 0x4016:
            value = (self.pad >> (7-self.index)) & 1 if self.index < 8 else 1
            self.index += 1
            return value
        return super().__getitem__(key)

    def __setitem__(self, key, value):
        if key == 0x4016:
            self.index = 0
        if key == 0x2007:
            self.ppu.append(value)
        if key == 0x4014:
            self.dmas += 1
        super().__setitem__(key, value)


def boot():
    mm = Memory()
    mm[0x8000:] = ROM
    cc = MPU(memory=mm, pc=S['reset'])
    for _ in range(900000):
        cc.step()
        if cc.pc == S['main']:
            return mm, cc
    raise AssertionError('boot timeout')


def call(mm, cc, name):
    cc.pc = S[name]
    cc.sp = 255
    cc.stPushWord(0x7FFE)
    for _ in range(300000):
        cc.step()
        if cc.pc == 0x7FFF:
            return
    raise AssertionError(name + ' timeout')


def active_enemies(mm):
    return sum(mm[a + 5] != 0 for a in range(0x300, 0x400, 16))


# Initial and rebuilt boards contain three supers, and the static HUD digit is
# already 3 before the first event-driven counter write.
mm, cc = boot()
assert mm[0x07] == 3 and mm[0x0677] == 4 and mm[0x0678] == 120
assert IMAGE[32784 + (0x100 + 0x7E) * 16:]  # numeric glyph remains in CHR
assert mm[S['omega_nt1_v3'] + 14 * 32 + 19 - 256] == 0x7E
mm[0x07] = 0
call(mm, cc, 'omega_level_setup9')
assert mm[0x07] == 3
print('PASS every board setup grants exactly three supers and shows 3 in the static HUD')

# The board remains completely motionless for 120 frames. The flash phase is
# ten visible frames followed by ten hidden frames, repeated six times.
mm, cc = boot()
enemy_before = list(mm[0x300:0x400])
shot_before = list(mm[0x580:0x5E0])
mine_before = list(mm[0x700:0x740])
visibility = []
for frame in range(120):
    call(mm, cc, 'omega_frame9')
    visibility.append(mm[0x200] != 0xF8)
    assert mm[0x0677] == 4
    assert list(mm[0x300:0x400]) == enemy_before
    assert list(mm[0x580:0x5E0]) == shot_before
    assert list(mm[0x700:0x740]) == mine_before
assert visibility == ([True] * 10 + [False] * 10) * 6
assert mm[0x0678] == 0
call(mm, cc, 'omega_frame9')
assert mm[0x0677] == 0
print('PASS initial life freezes for 120 frames with an exact 10-on/10-off ship flash')

# Death leaves both projectile pools intact and lets the world keep moving.
mm, cc = boot()
mm[0x0677] = 0
mm[0x600:0x60B] = [0xFF,0,80,0,100,0,0,0,0,0,0]
mm[0x580:0x58A] = [0xFF,0,120,0,120,0,0,0,0,0]
enemy_x = mm[0x300]
call(mm, cc, 'omega_player_kill9')
assert mm[0x0677] == 1 and mm[0x3D] == 2 and mm[0x0678] == 0
assert mm[0x600] and mm[0x580]
call(mm, cc, 'omega_frame9')
assert mm[0x600] and mm[0x580]
assert mm[0x300] != enemy_x or mm[0x304] != 0
print('PASS death preserves projectiles while enemies and the arena continue running')

# The restart countdown cannot begin while any Player One shot record remains.
mm[0x600] = 0xFF
for _ in range(200):
    call(mm, cc, 'omega_death_tick9')
assert mm[0x0678] == 0 and mm[0x0677] == 1
mm[0x600] = 0
call(mm, cc, 'omega_death_tick9')
assert mm[0x0678] == 120 and mm[0x0677] == 1
for expected in range(119, 0, -1):
    call(mm, cc, 'omega_death_tick9')
    assert mm[0x0678] == expected
call(mm, cc, 'omega_death_tick9')
assert mm[0x0677] == 4 and mm[0x0678] == 120 and mm[0x07] == 3
print('PASS restart waits for all Player One shots, then delays exactly 120 frames')

# Zero lives still permits the final shots to finish; only then does state 2
# freeze the arena for the future Game Over screen.
mm, cc = boot()
mm[0x0677] = 0
mm[0x3D] = 1
mm[0x600] = 0xFF
call(mm, cc, 'omega_player_kill9')
assert mm[0x3D] == 0 and mm[0x0677] == 1 and mm[0x600]
for _ in range(120):
    call(mm, cc, 'omega_death_tick9')
assert mm[0x0677] == 1
mm[0x600] = 0
call(mm, cc, 'omega_death_tick9')
assert mm[0x0677] == 2
frozen = (list(mm[0x300:0x400]), list(mm[0x580:0x5E0]), list(mm[0x700:0x740]))
for _ in range(60):
    call(mm, cc, 'omega_frame9')
assert frozen == (list(mm[0x300:0x400]), list(mm[0x580:0x5E0]), list(mm[0x700:0x740]))
print('PASS last-life action continues through final shots and then freezes in place')

# Level advancement also enters the identical frozen spawn flash.
mm, cc = boot()
mm[0x0677] = 0
mm[0xC7], mm[0xC5], mm[0xC6] = 1, 1, 0
call(mm, cc, 'omega_wave_delay9')
assert mm[0xC0] == 2 and mm[0x0677] == 4 and mm[0x0678] == 120
assert active_enemies(mm) == 8 and mm[0x07] == 3
print('PASS new levels use the same two-second frozen spawn flash')

# The new state dispatch remains inside the real main/NMI frame budget at the
# maximum formation, enemy-shot cap and persistent-mine cap.
mm, cc = boot()
mm[0xC0] = 7
call(mm, cc, 'omega_level_setup9')
for i, address in enumerate(range(0x700, 0x740, 4)):
    mm[address:address+3] = [0xFF, 12 + i * 14, 208]
for i, address in enumerate(range(0x580, 0x5E0, 16)):
    mm[address:address+10] = [0xFF,0,16+i*24,0,80,0,0,0,0,0]
mm.ppu = []
mm.pad = 0
cc.pc = S['main']
cc.sp = 255
deadline = cc.processorCycles
for _ in range(360):
    end = deadline + 29781
    while cc.processorCycles < end:
        if cc.processorCycles >= deadline:
            cc.nmi()
            deadline += 29781
        cc.step()
assert 350 <= mm.dmas <= 360
assert sum(mm[a] != 0 for a in range(0x580, 0x5E0, 16)) <= 6
assert sum(mm[a] != 0 for a in range(0x700, 0x740, 4)) <= 16
print('PASS revised spawn/death states remain stable at maximum gameplay load')
