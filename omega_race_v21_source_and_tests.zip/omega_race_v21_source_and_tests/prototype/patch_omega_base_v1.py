"""Runtime-minimal Omega Race base.

The ROM boots directly into an empty Bouncy arena. Only Player One, four shots,
controls, physics, OAM rendering and their existing sound effects are ticked.
"""
code='\n'.join(lines)

# Omega Race V2 colour pass.  Palette 0 is Player One: the former white
# ship pixels are now pale yellow ($38), while the central coloured pixels
# are dark gold ($18).  Palette 2 is reserved for Player One's shots: the
# four central pixels are hot yellow ($28) and the eight surrounding pixels
# are pale yellow ($38).  Palette 3 is the project-wide default enemy/tile
# gold palette.
assert data['palette'][16:20] == [0x0f, 0x30, 0x24, 0x16]
data['palette'][0:4] = [0x08, 0x18, 0x28, 0x38]
data['palette'][16:20] = [0x08, 0x38, 0x18, 0x28]
data['palette'][24:28] = [0x08, 0x28, 0x38, 0x18]
data['palette'][28:32] = [0x08, 0x18, 0x28, 0x38]

# The inherited startup loader becomes a complete gameplay-pool clear. This
# also clears the title asteroids before the first visible frame.
old='''load_asteroids:
LDA asteroid_init0,X
STA $0300,X
LDA asteroid_init1,X
STA $0400,X
LDA asteroid_init2,X
STA $0500,X
INX
BNE load_asteroids
JSR load_title'''
new='''load_asteroids:
LDA #$00
STA $0300,X
STA $0400,X
STA $0500,X
STA $0600,X
STA $0700,X
INX
BNE load_asteroids
LDA #$01
STA $06
STA $8E'''
assert code.count(old)==1
code=code.replace(old,new,1)

# One simulation step and one presentation per hardware refresh. No enemy,
# wave, score, pickup, collision, death, title, or adaptive-load dispatchers.
a=code.index('main:\n');b=code.index('nmi:\n',a)
minimal='''main:
LDA $00
BNE main
JSR sfx_tick25
JSR pulse2_tick26
LDA #$00
STA $8C
JSR controls
JSR shield_tick
JSR physics
JSR bullets
JSR thrust_audio27
JSR pulse_gate24c
JSR shield_phase34
JSR render
LDA #$01
STA $00
JMP main
'''
code=code[:a]+minimal+code[b:]

# Vblank publishes OAM only. The playfield was cleared before rendering was
# enabled, so no HUD, title, results, counter, or game-over tile writes occur.
a=code.index('nmi_active31:\n');b=code.index('nmi_done:\n',a)
nmi_active='''nmi_active31:
LDA #$00
STA $2003
LDA #$02
STA $4014
LDA #$00
STA $2005
STA $2005
STA $00
'''
code=code[:a]+nmi_active+code[b:]

# Ship plus four shots are the only render clients. All 64 OAM entries are
# hidden first by the inherited renderer, preventing stale sprite artifacts.
assert code.count('JSR render_ufo\nJSR render_asteroids\nRTS')==1
code=code.replace('JSR render_ufo\nJSR render_asteroids\nRTS','RTS',1)

# Projectiles use the dedicated shot palette (sprite palette 2).  Their
# existing 4x4 pixel drawing already has four centre pixels at colour index
# 1 and eight outer pixels at colour index 2, which maps exactly to
# $28-centre / $38-outer with the palette above.
old='''LDA #$00
STA $0202,Y
LDA $0602,X'''
new='''LDA #$02
STA $0202,Y
LDA $0602,X'''
assert code.count(old) == 1
code=code.replace(old,new,1)

lines=[s.strip() for s in code.splitlines() if s.strip()]
