"""Omega Race V4B ship and projectile speed adjustments."""

code = '\n'.join(lines)

def omega_vector_v4b(scale, fn):
    return [round(scale * fn(h * math.tau / 48)) & 0xFFFF for h in range(48)]

# V4A acceleration used a magnitude of 12/256 pixels per frame per update.
# 7.2/256 is exactly 60% before symmetric per-heading integer rounding.
# Projectile launch magnitude similarly changes from 768/256 to 537.6/256.
for prefix, scale in (('a', 7.2), ('b', 537.6)):
    for axis, fn in (('x', lambda a: math.sin(a)),
                     ('y', lambda a: -math.cos(a))):
        vals = omega_vector_v4b(scale, fn)
        data[prefix + axis + 'lo'] = [v & 0xFF for v in vals]
        data[prefix + axis + 'hi'] = [v >> 8 for v in vals]

# Replace the component speed clamps.  V4A capped each axis at +/-2.0
# pixels/frame; V4B caps at +/-1.2, represented as $0133 and $FECD in 8.8
# fixed point.  The same exact clamp is applied independently to X and Y.
old_x = '''LDA $15
ADC axhi,X
STA $15
BPL positive20
CMP #$FE
BCS capped20
LDA #$FE
STA $15
LDA #$00
STA $14
JMP capped20
positive20:
CMP #$02
BCC capped20
LDA #$02
STA $15
LDA #$00
STA $14
capped20:'''
new_x = '''LDA $15
ADC axhi,X
STA $15
BMI omega_cap_x_negative_v4b
CMP #$01
BCC omega_cap_x_done_v4b
BNE omega_cap_x_positive_v4b
LDA $14
CMP #$34
BCC omega_cap_x_done_v4b
omega_cap_x_positive_v4b:
LDA #$33
STA $14
LDA #$01
STA $15
JMP omega_cap_x_done_v4b
omega_cap_x_negative_v4b:
CMP #$FE
BCC omega_cap_x_low_v4b
BNE omega_cap_x_done_v4b
LDA $14
CMP #$CD
BCS omega_cap_x_done_v4b
omega_cap_x_low_v4b:
LDA #$CD
STA $14
LDA #$FE
STA $15
omega_cap_x_done_v4b:'''
assert code.count(old_x) == 1
code = code.replace(old_x, new_x, 1)

old_y = '''LDA $17
ADC ayhi,X
STA $17
BPL positive22
CMP #$FE
BCS capped22
LDA #$FE
STA $17
LDA #$00
STA $16
JMP capped22
positive22:
CMP #$02
BCC capped22
LDA #$02
STA $17
LDA #$00
STA $16
capped22:'''
new_y = '''LDA $17
ADC ayhi,X
STA $17
BMI omega_cap_y_negative_v4b
CMP #$01
BCC omega_cap_y_done_v4b
BNE omega_cap_y_positive_v4b
LDA $16
CMP #$34
BCC omega_cap_y_done_v4b
omega_cap_y_positive_v4b:
LDA #$33
STA $16
LDA #$01
STA $17
JMP omega_cap_y_done_v4b
omega_cap_y_negative_v4b:
CMP #$FE
BCC omega_cap_y_low_v4b
BNE omega_cap_y_done_v4b
LDA $16
CMP #$CD
BCS omega_cap_y_done_v4b
omega_cap_y_low_v4b:
LDA #$CD
STA $16
LDA #$FE
STA $17
omega_cap_y_done_v4b:'''
assert code.count(old_y) == 1
code = code.replace(old_y, new_y, 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]
