"""Omega Race 19B: clear all mines on every fresh game start."""

code = '\n'.join(lines)

# Both title Start and Game Over replay call omega_start_game17.  The latter
# already clears the pools, while title Start previously inherited all mines
# from the preceding game.  Clear only the 16 four-byte mine records here;
# omega_level_setup9 still preserves them on ordinary level transitions.
old = '''omega_start_game17:
LDA #$00
STA $2001
STA $30'''
new = '''omega_start_game17:
LDA #$00
STA $2001
LDX #$3F
omega_new_game_clear_mines19b:
STA $0700,X
DEX
BPL omega_new_game_clear_mines19b
STA $30'''
assert code.count(old) == 1
code = code.replace(old, new, 1)
lines = [s.strip() for s in code.splitlines() if s.strip()]
