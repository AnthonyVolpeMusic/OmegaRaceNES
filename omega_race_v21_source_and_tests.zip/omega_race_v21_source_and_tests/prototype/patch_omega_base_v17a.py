"""Omega Race Version 17A: true-black title-screen background."""

code = '\n'.join(lines)

# Keep the pending Level 1 gameplay palette request queued while the title is
# active.  START changes $06 to gameplay mode, so the next vblank restores the
# normal level palette before active play begins.
old = '''omega_palette_flush12b:
LDA $A7'''
new = '''omega_palette_flush12b:
LDA $06
BNE omega_palette_game17a
RTS
omega_palette_game17a:
LDA $A7'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Start requests both the gameplay palette and all three HUD fields.  Version
# 17's $07 assignment inadvertently discarded the palette-request bit.
old = '''JSR omega_level_setup9
LDA #$07
STA $A7'''
new = '''JSR omega_level_setup9
LDA #$0F
STA $A7'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]

# $0F is NES black.  The level palette table remains unchanged, so gameplay
# returns to Level 1's established $08/$18/$28/$38 scheme after START.
data['palette'][0] = 0x0F
data['palette'][4] = 0x0F
