"""Full V4B regression suite plus Version 5 center-HUD checks."""
import os
from pathlib import Path

os.environ['OMEGA_DYNAMIC_HUD']='1'
P = Path(__file__).parent
source = (P / 'test_omega_v4b.py').read_text()
source = source.replace('omega_race_v4b_speed_test.nes',
                        'omega_race_v5_center_hud_test.nes')
source = source.replace('symbols_omega_v4b.json', 'symbols_omega_v5.json')
exec(compile(source, str(P / 'test_omega_v4b.py'), 'exec'))

def glyphs(text):
    result=[]
    for ch in text:
        if ch==' ': result.append(0)
        elif ch==':': result.append(0x8a)
        elif '0'<=ch<='9': result.append(0x7b+ord(ch)-ord('0'))
        else: result.append(0x61+ord(ch)-ord('A'))
    return result

# Verify exact centered labels in the loaded nametable.
mm,cc=boot();nt=mm.ppu[4128:5152]
assert nt[12*32+10:12*32+22]==glyphs('SCORE:000000')
assert nt[14*32+10:14*32+22]==glyphs('  SUPERS:5  ')
assert nt[16*32+10:16*32+22]==glyphs('LIVES LEFT:3')
print('PASS requested three-line HUD is centered inside the 14x10 box')

# Change all live values, execute one real NMI, and verify the eight published
# glyphs in score/supers/lives order.
mm[0x33:0x39]=[1,2,3,4,5,6];mm[0x07]=4;mm[0x3d]=2
mm.ppu=[];mm[0]=1;mm[0xa2]=0;cc.pc=0x7fff;cc.sp=255;cc.nmi()
for _ in range(20000):
    cc.step()
    if cc.pc==0x7fff: break
assert mm.ppu==[0x7c,0x7d,0x7e,0x7f,0x80,0x81,0x7f,0x7d]
assert mm.dmas>=1 and mm[0]==0
print('PASS score, supers, and lives values update dynamically during vblank')

# Labels remain static: only eight value glyphs are sent by each active NMI.
mm.ppu=[];mm[0]=1;mm[0xa2]=0;cc.pc=0x7fff;cc.sp=255;cc.nmi()
for _ in range(20000):
    cc.step()
    if cc.pc==0x7fff: break
assert len(mm.ppu)==8
print('PASS vblank updates only the eight changing HUD digits')
