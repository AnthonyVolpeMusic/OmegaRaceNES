"""Version 13A: retain the two-second continuation after the final life."""

code = '\n'.join(lines)

old = '''LDA $3D
BNE omega_death_life_wait13
LDA #$02
STA $0677
RTS
omega_death_life_wait13:
LDA $0678
BNE omega_death_count13
LDA #$78
STA $0678
RTS
omega_death_count13:
DEC $0678
BNE omega_death_done9
JSR omega_level_setup9
omega_death_done9:
RTS'''
new = '''LDA $0678
BNE omega_death_count13
LDA #$78
STA $0678
RTS
omega_death_count13:
DEC $0678
BNE omega_death_done9
LDA $3D
BEQ omega_death_final_freeze13a
JSR omega_level_setup9
RTS
omega_death_final_freeze13a:
LDA #$02
STA $0677
omega_death_done9:
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]
