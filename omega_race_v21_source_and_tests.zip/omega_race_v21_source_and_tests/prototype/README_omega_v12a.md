# Omega Race NES — Version 12A mine timing and level palettes

Baseline: Version 12's persistent, shootable land mines and Version 11B's
Shooting Star behavior and artwork.

- Commanders now drop a mine every 180 active frames (three seconds).
- Shooting Stars now drop a mine every 60 active frames (one second).
- The sixteen-mine cap, persistence, collision and 350-point reward remain
  unchanged.
- Background/tile palette 0 follows an eight-level cycle:
  1. `$08,$18,$28,$38`
  2. `$0C,$1C,$2C,$3C`
  3. `$04,$13,$22,$31`
  4. `$01,$12,$23,$34`
  5. `$0B,$1A,$29,$38`
  6. `$06,$17,$28,$39`
  7. `$05,$15,$25,$35`
  8. `$21,$11,$01,$0D`
- Level 9 returns to palette 1, repeating the cycle every eight levels.
- Palette changes are queued for VBlank and write only `$3F00-$3F03`; sprite
  palette entries remain unchanged.
- Same-level respawns retain the current palette without a redundant PPU write.

Build: `python3 prototype/build_omega_base_v12a.py`

Test: `python3 prototype/test_omega_v12a.py`

Dependencies: Python 3, Pillow and py65.
