# Omega Race NES — Version 10 palette, bounce and extra-life tuning

Baseline: Version 9's Player One collisions, death/restart loop, level
progression, mirrored formations, Commander firing, speed scaling and
six-missile enemy cap.

- Exactly two score-based extra lives are available: one at 40,000 points and
  one at 100,000 points. Neither can be awarded more than once.
- Player One now retains 75% of signed velocity after bouncing from any outer
  or middle-box boundary, replacing the previous 50% reduction.
- Basic drone sprite palette: transparent `$08`, dark `$00`, medium `$26`,
  light `$36`.
- Commander sprite palette: transparent `$08`, dark `$16`, medium `$27`,
  light `$38`.
- Commander-fired missiles use the Commander palette. Player One and Player
  One projectile palettes are unchanged.
- Lives continue to update only when a loss or earned life occurs.

Build: `python3 prototype/build_omega_base_v10.py`

Test: `python3 prototype/test_omega_v10.py`

Dependencies: Python 3, Pillow and py65.
