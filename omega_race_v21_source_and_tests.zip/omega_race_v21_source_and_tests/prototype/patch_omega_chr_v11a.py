"""Version 11A: revised four-frame Shooting Star artwork."""

# Commander palette indices: 0 transparent ($08), 1 red ($16),
# 2 yellow ($27), 3 orange/light highlight ($38).
shooting_star_frames_v11a = [
    [
        '20032001',
        '00011000',
        '00111100',
        '00211300',
        '03111120',
        '01122110',
        '11111111',
        '12311231',
    ],
    [
        '30013003',
        '00012000',
        '00211100',
        '00311100',
        '01111130',
        '01122120',
        '21111111',
        '23112311',
    ],
    [
        '10011002',
        '00023000',
        '00311200',
        '00111100',
        '01111110',
        '02122130',
        '31111112',
        '31123112',
    ],
    [
        '20021003',
        '00031000',
        '00111300',
        '00111200',
        '02111110',
        '03122110',
        '11111113',
        '11231123',
    ],
]

for frame, rows in enumerate(shooting_star_frames_v11a):
    assert len(rows) == 8 and all(len(row) == 8 for row in rows)
    tile(0x1E8 + frame, [[int(value) for value in row] for row in rows])
