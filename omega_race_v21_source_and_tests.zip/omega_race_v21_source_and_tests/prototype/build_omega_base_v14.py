"""Build Omega Race Version 14 with its first dedicated sound-effects pass."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v13a.py').read_text()

base_v13a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v13a.py').read_text(),str(P/'patch_omega_base_v13a.py'),'exec'))\\n" + marker)'''
base_v14 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v14.py').read_text(),str(P/'patch_omega_base_v14.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v13a) == 1
recipe = recipe.replace(base_v13a, base_v13a + '\n' + base_v14, 1)

recipe = recipe.replace('omega_race_v13a.nes', 'omega_race_v14.nes')
recipe = recipe.replace('symbols_omega_v13a.json', 'symbols_omega_v14.json')
recipe = recipe.replace('prototype_omega_v13a.asm', 'prototype_omega_v14.asm')
exec(compile(recipe, str(P / 'build_omega_base_v13a.py'), 'exec'))
