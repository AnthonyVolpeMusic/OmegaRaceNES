# Omega Race NES — Version 16 adaptive triangle music

Baseline: Version 15A.

- Normal triangle loop: G2, F2, E-flat2, C2.
- Each normal note sounds for six frames and begins with a 24-frame rest.
- Every enemy kill shortens the rest by two frames, down to six frames.
- The tempo resets at every level/board setup; land mines do not affect it.
- While any Shooting Star is onscreen, the loop immediately changes to
  G2, C3, G2, C2 with six-frame notes and no rests.
- When the last Shooting Star is destroyed, the normal loop immediately
  returns at the rest length earned from the current level's kill count.
- Triangle music stops during death, spawn flashing, wave clear, and whenever
  no enemies remain. Version 15A's level-clear song and all effects are retained.

Build: `python3 prototype/build_omega_base_v16.py`

Test: `python3 prototype/test_omega_v16.py`
