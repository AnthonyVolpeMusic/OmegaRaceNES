"""Build Omega Race Version 20A from the reproducible Version 20 chain."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v20.py').read_text()

base_v20 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v20.py').read_text(),str(P/'patch_omega_base_v20.py'),'exec'))\\n" + marker)'''
base_v20a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v20a.py').read_text(),str(P/'patch_omega_base_v20a.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v20) == 1
recipe = recipe.replace(base_v20, base_v20 + '\n' + base_v20a, 1)
recipe = recipe.replace('omega_race_v20.nes', 'omega_race_v20a.nes')
recipe = recipe.replace('symbols_omega_v20.json', 'symbols_omega_v20a.json')
recipe = recipe.replace('prototype_omega_v20.asm', 'prototype_omega_v20a.asm')
exec(compile(recipe, str(P / 'build_omega_base_v20.py'), 'exec'))
