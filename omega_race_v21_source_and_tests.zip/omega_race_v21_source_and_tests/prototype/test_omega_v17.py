"""Machine-code and asset regression tests for Omega Race Version 17."""
from pathlib import Path
import json

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
text = base.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v17.nes')
text = text.replace('symbols_omega_base_v1.json', 'symbols_omega_v17.json')
text = text.replace('range(400000)', 'range(900000)')
env = {'__file__': str(P / 'test_omega_v17.py')}
exec(compile(text, 'harness', 'exec'), env)
boot, call = env['boot'], env['call']

rom_file = (P / 'omega_race_v17.nes').read_bytes()
prg = rom_file[16:16 + 32768]
chr_data = rom_file[16 + 32768:]
symbols = json.loads((P / 'symbols_omega_v17.json').read_text())

def table(name, size):
    start = symbols[name] - 0x8000
    return prg[start:start + size]

title = b''.join(table(f'title_nt{i}', 256) for i in range(4))

# Logo is exactly 24x6 tiles at tile coordinate (4,3), and its 70 unique
# nonblank tiles stay below the alphabet's fixed $61 starting index.
logo_map = [title[y * 32 + x] for y in range(3, 9) for x in range(4, 28)]
assert len(logo_map) == 144
assert max(logo_map) == 70
assert set(logo_map) == set(range(71))
assert any(chr_data[i * 16:(i + 1) * 16] != bytes(16) for i in range(1, 71))
print('PASS 192x48 logo occupies 24x6 tiles and uses 70 safe unique patterns')

def glyph(ch):
    if ch == ' ': return 0
    if ch == ':': return 0x8A
    return 0x61 + ord(ch) - ord('A')

for row, message in (
    (12, 'PRESS SELECT TO CHOOSE'),
    (14, 'STARTING LIVES: THREE'),
    (19, 'PRESS START TO BEGIN'),
):
    x = (32 - len(message)) // 2
    expected = bytes(glyph(ch) for ch in message)
    assert title[row * 32 + x:row * 32 + x + len(message)] == expected
print('PASS all three requested title lines are centered at the intended rows')

# Cold boot stops at the title and defaults to three starting lives.
mm, cc = boot()
assert mm[0x06] == 0 and mm[0x9A] == 3
state = bytes(mm[0x677:0x680])
for _ in range(120):
    call(mm, cc, 'omega_dispatch17')
assert mm[0x06] == 0 and bytes(mm[0x677:0x680]) == state
print('PASS title mode defaults to three lives and freezes all gameplay state')

# Every selectable value 1..5 transfers intact to a fresh Level 1 game.
for lives in range(1, 6):
    mm, cc = boot()
    mm[0x9A] = lives
    call(mm, cc, 'omega_start_game17')
    assert mm[0x06] == 1 and mm[0x3D] == lives and mm[0xC0] == 1
    assert mm[0x07] == 3 and mm[0x677] == 4
print('PASS Start begins fresh Level 1 with the selected 1-5 lives and three supers')

words = table('omega_lives_words17', 25)
assert words == bytes(glyph(ch) for ch in 'ONE  TWO  THREEFOUR FIVE ')
print('PASS SELECT word table contains ONE through FIVE in fixed five-tile fields')

print('PASS Omega Race Version 17 title-screen regression suite')
