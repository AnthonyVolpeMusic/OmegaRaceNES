"""Version 7A: seven southwest drones clockwise at half V6 speed."""

code = '\n'.join(lines)

# Keep the established upper-right position and explicitly face west.
old = 'LDA #$E0\nSTA $11\nLDA #$18\nSTA $13'
new = old + '\nLDA #$24\nSTA $03'
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Spawn in a loose southwest cluster rather than directly on four nodes.
old = '''LDA drone_spawn_nodes6,Y
TAY
LDA $0380,Y
STA $0300,X
LDA $0388,Y
STA $0301,X'''
new = '''LDA drone_spawn_x7a,Y
STA $0300,X
LDA drone_spawn_y7a,Y
STA $0301,X'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Seven 16-byte records replace V6's four-record loop limit.
for label in ('drone_spawn6', 'drone_tick_loop6', 'drone_render_loop6'):
    old = 'ADC #$10\nTAX\nCPX #$40\nBNE ' + label
    new = 'ADC #$10\nTAX\nCPX #$70\nBNE ' + label
    assert code.count(old) == 1
    code = code.replace(old, new, 1)

# Half the V6 movement rate, retaining diagonal compensation.
assert code.count('LDA #$80\nSTA $AA') == 1
assert code.count('LDA #$5B\nSTA $AA') == 1
code = code.replace('LDA #$80\nSTA $AA', 'LDA #$40\nSTA $AA', 1)
code = code.replace('LDA #$5B\nSTA $AA', 'LDA #$2D\nSTA $AA', 1)

data['drone_spawn_x7a'] = [40, 48, 58, 68, 35, 55, 70]
data['drone_spawn_y7a'] = [166, 178, 188, 193, 150, 171, 184]
data['drone_directions6'] = [1] * 7

# Seven independently varied racing lines.  Each route keeps the same clockwise
# eight-node topology, but its destinations drift gradually within the safe
# corridor instead of using V6's single shared centerline.
base_nodes = list(zip(data['drone_nodes_x6'], data['drone_nodes_y6']))
inward = [(1, 1), (-1, 1), (-1, 1), (-1, -1),
          (-1, -1), (1, -1), (1, -1), (1, 1)]
route_offsets = [
    [-14, -12, -10,   0,  10,  12,  14,  10],
    [ 13,  15,  12,   9, -10, -13, -15, -11],
    [-10,  11,  15,  12,   0, -12, -14, -13],
    [ 15,  10, -11, -15, -12,   9,  13,  14],
    [-15, -10,  12,  14,  11, -11, -13,   9],
    [  9,  14,  13,  -9, -14, -12,  10,  15],
    [ 12,  -9, -14, -13,  10,  15,  11, -10],
]
routes = []
for profile in route_offsets:
    route = []
    for (x, y), (ix, iy), offset in zip(base_nodes, inward, profile):
        route.append((x + ix * offset, y + iy * offset))
    routes.append(route)
data['drone_route_x7a'] = [x for route in routes for x, _ in route]
data['drone_route_y7a'] = [y for route in routes for _, y in route]

# Load all 56 personal X/Y destinations once when the wave begins.
old = '''DEX
BPL drone_nodes_load6
LDX #$00'''
new = '''DEX
BPL drone_nodes_load6
LDX #$37
drone_routes_load7a:
LDA drone_route_x7a,X
STA $0400,X
LDA drone_route_y7a,X
STA $0440,X
DEX
BPL drone_routes_load7a
LDX #$00'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Nearest-node acquisition now compares the spawn against that drone's own
# route. X remains the 16-byte record offset; X/2 is its 8-node route offset.
start = code.index('drone_assign6:')
end = code.index('drone_tick6:', start)
assign = '''drone_assign6:
LDA #$FF
STA $AE
LDY #$00
drone_nearest6:
STY $AF
TXA
LSR A
CLC
ADC $AF
TAY
LDA $0300,X
SEC
SBC $0400,Y
BCS drone_abs_x6
EOR #$FF
CLC
ADC #$01
drone_abs_x6:
STA $AA
LDA $0301,X
SEC
SBC $0440,Y
BCS drone_abs_y6
EOR #$FF
CLC
ADC #$01
drone_abs_y6:
CMP $AA
BCS drone_distance6
LDA $AA
drone_distance6:
CMP $AE
BCS drone_nearest_next6
STA $AE
LDA $AF
STA $0302,X
drone_nearest_next6:
LDY $AF
INY
CPY #$08
BNE drone_nearest6
RTS
'''
code = code[:start] + assign + code[end:]

# Resolve every target through the current drone's personal route table.
old = '''LDY $0302,X
LDA $0380,Y
STA $AB
LDA $0388,Y
STA $AC'''
new = '''LDY $0302,X
STY $AF
TXA
LSR A
CLC
ADC $AF
TAY
LDA $0400,Y
STA $AB
LDA $0440,Y
STA $AC'''
assert code.count(old) == 1
code = code.replace(old, new, 1)
old = '''TAY
LDA $0380,Y
STA $AB
LDA $0388,Y
STA $AC'''
new = '''TAY
STY $AF
TXA
LSR A
CLC
ADC $AF
TAY
LDA $0400,Y
STA $AB
LDA $0440,Y
STA $AC'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

lines = [s.strip() for s in code.splitlines() if s.strip()]
