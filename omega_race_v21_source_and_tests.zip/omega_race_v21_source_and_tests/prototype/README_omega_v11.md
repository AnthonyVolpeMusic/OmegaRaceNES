# Omega Race NES — Version 11 Shooting Star

Baseline: Version 10's level progression, collisions, independently routed
enemies, Commander firing, tuned palettes, 75% wall-bounce velocity retention
and score-based extra lives.

- Every Commander converts in place into its final Shooting Star form after
  exactly 1,200 active gameplay frames (20 seconds at 60 Hz).
- Shooting Stars use four supplied 8x8 animation drawings, changing on the
  existing six-frame animation cadence. Drawing four is Drawing two mirrored
  horizontally.
- Shooting Star colors reuse the Commander sprite palette: transparent `$08`,
  red body `$16`, yellow propeller `$27`; `$38` remains available.
- A Shooting Star directly pursues Player One whenever it has a clear route.
  If the middle box blocks that route, it follows its inherited personal track
  until pursuit becomes clear again.
- Outer-wall and expanded middle-box safety checks restore the last valid
  position and return the Shooting Star to route recovery, preventing repeated
  wall grinding.
- Shooting Stars fire every 30 active frames (0.5 seconds), but only with a
  clear line to Player One. They share the existing six-projectile enemy cap.
- Destroying a Shooting Star awards 2,500 points and, when a basic drone
  survives, promotes one drone to Commander with a fresh 20-second timer.
- A converted Shooting Star continues to occupy its Commander quota slot;
  conversion alone does not promote another drone.
- Direct Shooting Star contact and its flying projectiles use the existing
  Player One death/restart system.

Build: `python3 prototype/build_omega_base_v11.py`

Test: `python3 prototype/test_omega_v11.py`

Dependencies: Python 3, Pillow and py65.
