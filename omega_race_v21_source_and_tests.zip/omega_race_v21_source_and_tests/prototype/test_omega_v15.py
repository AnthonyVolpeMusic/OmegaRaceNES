"""Machine-code regression tests for Omega Race Version 15."""
from pathlib import Path

P = Path(__file__).parent
text = (P / 'test_omega_v14.py').read_text()
text = text.replace('Version 14', 'Version 15')
text = text.replace('omega_race_v14.nes', 'omega_race_v15.nes')
text = text.replace('symbols_omega_v14.json', 'symbols_omega_v15.json')
text = text.replace('prototype_omega_v14.asm', 'prototype_omega_v15.asm')
exec(compile(text, str(P / 'test_omega_v14.py'), 'exec'))


voice1_notes = [
    (0x07E,3),(0x077,3),(0x07E,3),(0x077,3),(0x06A,12),(0x09F,24),
    (0x07E,3),(0x077,3),(0x07E,3),(0x077,3),(0x06A,12),(0x09F,24),
    (0x07E,3),(0x077,3),(0x07E,3),(0x077,3),(0x06A,12),(0x09F,24),
    (0x07E,3),(0x077,3),(0x07E,3),(0x077,3),(0x08E,36),
]
voice2_notes = [
    (0x23A,6),(0x2A6,6),(0x280,12),(0x356,24),
    (0x23A,6),(0x2A6,6),(0x280,12),(0x356,24),
    (0x23A,6),(0x2A6,6),(0x280,12),(0x356,24),
    (0x3F8,6),(0x3BF,6),(0x356,36),
]


def expand(notes):
    return [period for period, duration in notes for _ in range(duration)]


# Emulate the final enemy's 16-frame destruction effect and arm the wave song.
# The song begins on the exact frame after that effect finishes.
mm, cc = boot()
for address in range(0x300, 0x400, 0x10):
    mm[address + 5] = 0
call(mm, cc, 'omega_pulse1_start14', a=3)
call(mm, cc, 'omega_wave_check9')
assert mm[0xC7] == 1 and mm[0xD7] == 1 and mm[0x82] == 16
for remaining in range(15, 0, -1):
    call(mm, cc, 'sfx_tick25')
    call(mm, cc, 'pulse2_tick26')
    assert mm[0xD7] == 1 and mm[0x82] == remaining
call(mm, cc, 'sfx_tick25')
call(mm, cc, 'pulse2_tick26')
assert mm[0xD7] == 0xFF and mm[0x82] == 0 and mm[0xD8] == 1
print('PASS level-clear song waits for the full final-enemy destruction cue')


# Capture all 192 sounding frames and compare both pulse channels against the
# expanded score, including every sixteenth/eighth/quarter/half/three-quarter.
voice1 = [mm[0x4002] | ((mm[0x4003] & 7) << 8)]
voice2 = [mm[0x4006] | ((mm[0x4007] & 7) << 8)]
for _ in range(191):
    call(mm, cc, 'sfx_tick25')
    call(mm, cc, 'pulse2_tick26')
    assert mm[0xD7] == 0xFF
    voice1.append(mm[0x4002] | ((mm[0x4003] & 7) << 8))
    voice2.append(mm[0x4006] | ((mm[0x4007] & 7) << 8))
assert voice1 == expand(voice1_notes)
assert voice2 == expand(voice2_notes)
assert mm[0xD8] == 192 and mm[0xD9] == 23 and mm[0xDB] == 15
assert (mm[0x4000] & 15) == 15 and (mm[0x4004] & 15) == 15
print('PASS both voices match the complete four-measure 192-frame score')


# The stop occurs on the following frame, allowing the last notes their entire
# durations. Both pulse enable bits and both channel volumes are then cleared.
call(mm, cc, 'sfx_tick25')
call(mm, cc, 'pulse2_tick26')
assert mm[0xD7] == 0 and not (mm[0x86] & 3)
assert (mm[0x4000] & 15) == 0 and (mm[0x4004] & 15) == 0
print('PASS song ends cleanly only after all 192 sounding frames')


# A simultaneous 36-frame extra-life cue has higher priority than the final
# destruction sound. The tune waits for that complete cue as well.
mm, cc = boot()
call(mm, cc, 'omega_pulse1_start14', a=9)
mm[0xD7] = 1
for remaining in range(35, 0, -1):
    call(mm, cc, 'sfx_tick25')
    assert mm[0xD7] == 1 and mm[0x82] == remaining
call(mm, cc, 'sfx_tick25')
assert mm[0xD7] == 0xFF and mm[0xD8] == 1
print('PASS an earned extra-life cue finishes before the level-clear song begins')


# While active, the tune owns both pulse channels. Fire, shield, and stop-super
# start requests cannot replace either voice or alter their sequencer state.
state = (mm[0xD7], mm[0xD8], mm[0xD9], mm[0xDA], mm[0xDB], mm[0xDC],
         mm[0x4000], mm[0x4002], mm[0x4003],
         mm[0x4004], mm[0x4006], mm[0x4007])
call(mm, cc, 'omega_pulse1_start14', a=1)
call(mm, cc, 'pulse2_start26', a=7)
call(mm, cc, 'pulse2_start26', a=9)
assert state == (mm[0xD7], mm[0xD8], mm[0xD9], mm[0xDA], mm[0xDB], mm[0xDC],
                 mm[0x4000], mm[0x4002], mm[0x4003],
                 mm[0x4004], mm[0x4006], mm[0x4007])
print('PASS gameplay sound requests cannot interrupt either song voice')


# The tune, including its destruction-sound lead-in, fits inside the unchanged
# 300-frame intermission and leaves the final portion silent before Level 2.
mm, cc = boot()
for address in range(0x300, 0x400, 0x10):
    mm[address + 5] = 0
call(mm, cc, 'omega_pulse1_start14', a=3)
call(mm, cc, 'omega_wave_check9')
active_frames = 0
silent_tail = 0
for frame in range(300):
    call(mm, cc, 'sfx_tick25')
    call(mm, cc, 'pulse2_tick26')
    if mm[0xD7] == 0xFF:
        active_frames += 1
    elif frame >= 208:
        silent_tail += 1
    call(mm, cc, 'omega_wave_delay9')
assert active_frames == 192 and silent_tail == 92
assert mm[0xC0] == 2 and mm[0xC7] == 0 and mm[0xD7] == 0
print('PASS 192-frame song fits inside the existing 300-frame level intermission')

print('PASS Omega Race Version 15 level-clear song regression suite')
