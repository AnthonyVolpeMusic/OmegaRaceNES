# Omega Race NES — Version 6 drone movement test

Baseline: V5A remains unchanged and is included for differential testing.

- Four harmless basic drones; two clockwise and two counterclockwise.
- Exact user-supplied four-frame 8x8 artwork at sprite tiles $E0-$E3,
  palette 3: transparent / $18 / $28 / $38.
- Animation advances every six simulation frames, looping 1-2-3-4.
- Approximately 0.5 pixels/frame; diagonal steps compensated with 91/256
  per-axis increments rather than 128/256, avoiding corner speed-ups.
- A shared eight-node octagon is derived algorithmically from arena geometry
  at build time and loaded into RAM at startup. Each drone independently finds
  its nearest node at startup and then follows its own direction/target.
- Test spawns are on the loop at four separated nodes. Arbitrary off-loop
  spawn steering or player pursuit is not implemented in this motion-only test.
- No drone shooting, damage, destruction, or scoring. Passing through each
  other, the player, and projectiles is intentional for this build.
- V5A player physics, sounds, palette, borders and event-driven HUD retained.

Build from this directory's parent: `python3 prototype/build_omega_base_v6.py`
Test: `python3 prototype/test_omega_v6.py`
Dependencies: Python 3, Pillow, py65. Original upload assets are included.
The existing build chain also regenerates intermediate Asteroids/base outputs.

RAM: $0300-$033F four 16-byte drone records (x,y,target,direction,fraction);
$0380-$038F shared node coordinates; $A8/$A9 animation; $AA-$AE scratch.
No new gameplay or HUD state is stored in NMI scratch.

Tests cover exact CHR pixels, animation timing, 100 simulated seconds of
full laps and wall clearance, 48-heading V5A differential checks, HUD events,
vblank time budget, and actual main/NMI execution with thrust and firing.
The optional preview script renders a diagnostic still, not a PPU emulation.
