"""Regression tests for Omega Race Version 17A."""
from pathlib import Path
import json

P = Path(__file__).parent
base = (P / 'test_omega_base_v1.py').read_text().split('m,c=boot()')[0]
text = base.replace('omega_race_player_base_v2_palette_test.nes', 'omega_race_v17a.nes')
text = text.replace('symbols_omega_base_v1.json', 'symbols_omega_v17a.json')
text = text.replace('range(400000)', 'range(900000)')
env = {'__file__': str(P / 'test_omega_v17a.py')}
exec(compile(text, 'harness', 'exec'), env)
boot, call = env['boot'], env['call']

rom = (P / 'omega_race_v17a.nes').read_bytes()[16:16 + 32768]
symbols = json.loads((P / 'symbols_omega_v17a.json').read_text())
palette_start = symbols['palette'] - 0x8000
palette = rom[palette_start:palette_start + 32]
assert palette[0] == 0x0F and palette[4] == 0x0F
assert palette[1:4] == bytes((0x18, 0x28, 0x38))
assert palette[5:8] == bytes((0x18, 0x28, 0x16))
print('PASS title palettes use true black while preserving logo colors')

mm, cc = boot()
assert mm[0x06] == 0
mm[0xA7] = 0x08
call(mm, cc, 'omega_palette_flush12b')
assert mm[0xA7] & 0x08
print('PASS title mode cannot consume the queued gameplay palette request')

mm[0x9A] = 3
call(mm, cc, 'omega_start_game17')
assert mm[0x06] == 1 and (mm[0xA7] & 0x08)
call(mm, cc, 'omega_palette_flush12b')
assert not (mm[0xA7] & 0x08)
print('PASS starting gameplay restores the established level palette')

print('PASS Omega Race Version 17A black-title regression suite')
