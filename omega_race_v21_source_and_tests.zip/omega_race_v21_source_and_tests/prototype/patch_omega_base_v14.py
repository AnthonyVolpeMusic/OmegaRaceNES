"""Version 14: Omega Race-specific sound-effects pass."""

code = '\n'.join(lines)

# Replace the inherited Pulse 1 shot sequencer with the Omega effect engine.
# Preserve the inherited generic noise path for thrust and unused legacy code;
# Player One's dedicated death sequence takes it over only while $D6 is set.
start = code.index('sfx_tick25:')
end = code.index('sfx_noise_tick25:', start)
code = code[:start] + '''sfx_tick25:
JSR omega_pulse1_tick14
LDA $D6
BEQ sfx_noise_tick25
JMP omega_death_noise_tick14
''' + code[end:]

# All Player One shots, including the rainbow super, use effect 1.
start = code.index('sfx_shot_start25:')
end = code.index('sfx_asteroid_start25:', start)
code = code[:start] + '''sfx_shot_start25:
LDA #$01
JMP omega_pulse1_start14
''' + code[end:]

# Clear the new engine state whenever the inherited audio reset runs.
old = '''STA $8B
STA $8C
STA $4015'''
new = '''STA $8B
STA $8C
STA $D2
STA $D3
STA $D4
STA $D5
STA $D6
STA $4015'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Enemy projectile launch: Commander and Shooting Star share effect 2.
old = '''LDA ufo_yhi,X
STA $0588,Y
commander_fire_done8:'''
new = '''LDA ufo_yhi,X
STA $0588,Y
LDA #$02
JSR omega_pulse1_start14
commander_fire_done8:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Choose the destruction effect from the saved enemy type: basic drone 3,
# Commander 4, Shooting Star 5.
old = '''STA $0607,Y
STA $0608,Y
LDA $B1
BEQ drone_score_1000_9'''
new = '''STA $0607,Y
STA $0608,Y
LDA $B1
BEQ omega_drone_sfx14
CMP #$02
BEQ omega_star_sfx14
LDA #$04
BNE omega_enemy_sfx_start14
omega_star_sfx14:
LDA #$05
BNE omega_enemy_sfx_start14
omega_drone_sfx14:
LDA #$03
omega_enemy_sfx_start14:
JSR omega_pulse1_start14
LDA $B1
BEQ drone_score_1000_9'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Mine destruction uses the nine-frame C3/F3/C2 effect 7.
old = '''STA $0607,Y
STA $0608,Y
LDA #$FA
JSR score_add'''
new = '''STA $0607,Y
STA $0608,Y
LDA #$07
JSR omega_pulse1_start14
LDA #$FA
JSR score_add'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Player projectile wall impact uses effect 8 before its explosion animation.
old = '''omega_shot_explode_v4:
LDA #$0F
STA $0600,X'''
new = '''omega_shot_explode_v4:
LDA #$08
JSR omega_pulse1_start14
LDA #$0F
STA $0600,X'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Player ship impacts—outer and center box—share effect 6. Clear the collision
# flag between the two checks so one impact cannot trigger twice.
old = '''LDA $98
BEQ omega_ship_outer_done_v4
JSR omega_halve_ship_speed_v4
omega_ship_outer_done_v4:
JSR omega_ship_box_v4
LDX $9B
RTS'''
new = '''LDA $98
BEQ omega_ship_outer_done_v4
JSR omega_halve_ship_speed_v4
LDA #$06
JSR omega_pulse1_start14
omega_ship_outer_done_v4:
LDA #$00
STA $98
JSR omega_ship_box_v4
LDA $98
BEQ omega_ship_sound_done14
LDA #$06
JSR omega_pulse1_start14
omega_ship_sound_done14:
LDX $9B
RTS'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Extra life effect 9 replaces the inherited Pulse 2 cue.
old = '''score_extra_life10:
LDA #$06
JSR pulse2_start26
INC $3D'''
new = '''score_extra_life10:
LDA #$09
JSR omega_pulse1_start14
INC $3D'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Player One death immediately silences all channels and starts its exclusive
# 76-frame noise sequence.
old = '''omega_player_kill9:
LDA $0677
BNE omega_player_kill_done9
JSR death_burst_start22
LDA #$0F
JSR sfx_noise_start25'''
new = '''omega_player_kill9:
LDA $0677
BNE omega_player_kill_done9
JSR death_burst_start22
JSR omega_death_sfx_start14'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

code += '''
omega_pulse1_start14:
STA $D4
PHP
PHA
TXA
PHA
TYA
PHA
LDX $D4
LDY omega_sfx_priority14,X
LDA $82
BEQ omega_pulse1_accept14
CPY $D3
BCC omega_pulse1_reject14
omega_pulse1_accept14:
STX $D2
STY $D3
LDA omega_sfx_length14,X
STA $82
LDA #$00
STA $83
LDA #$FF
STA $D5
LDA $86
ORA #$01
STA $86
STA $4015
JSR omega_pulse1_output14
omega_pulse1_reject14:
PLA
TAY
PLA
TAX
PLA
PLP
RTS

omega_pulse1_tick14:
LDA $82
BEQ omega_pulse1_tick_done14
INC $83
DEC $82
BEQ omega_pulse1_stop14
JSR omega_pulse1_output14
RTS
omega_pulse1_stop14:
LDA #$00
STA $D2
STA $D3
LDA #$B0
STA $4000
LDA $86
AND #$FE
STA $86
STA $4015
omega_pulse1_tick_done14:
RTS

omega_pulse1_output14:
LDA $D2
CMP #$01
BEQ omega_port_player14
CMP #$02
BEQ omega_port_enemy14
CMP #$08
BEQ omega_port_wall14
CMP #$03
BEQ omega_alt_drone14
CMP #$04
BEQ omega_alt_commander14
CMP #$05
BEQ omega_alt_star14
CMP #$06
BEQ omega_alt_bounce14
CMP #$07
BEQ omega_pulse1_mine_jump14
JMP omega_extra_life_sfx14
omega_pulse1_mine_jump14:
JMP omega_mine_sfx14

omega_port_player14:
LDA #$00
BEQ omega_port_ready14
omega_port_enemy14:
LDA #$0C
BNE omega_port_ready14
omega_port_wall14:
LDA #$18
omega_port_ready14:
CLC
ADC $83
TAX
LDA omega_port_low14,X
STA $4002
LDA omega_port_high14,X
JSR omega_pulse1_high14
LDA $D2
CMP #$08
BEQ omega_port_wall_volume14
LDX $83
LDA omega_fade12_14,X
JMP omega_pulse1_volume14
omega_port_wall_volume14:
LDX $83
LDA omega_fade10_14,X
JMP omega_pulse1_volume14

omega_alt_drone14:
LDA #$89
LDY #$03
LDX #$74
STX $D4
LDX #$04
JMP omega_alt_choose14
omega_alt_commander14:
LDA #$D5
LDY #$00
LDX #$AB
STX $D4
LDX #$01
JMP omega_alt_choose14
omega_alt_star14:
LDA #$D5
LDY #$00
LDX #$7E
STX $D4
LDX #$00
JMP omega_alt_choose14
omega_alt_bounce14:
LDA #$56
LDY #$03
LDX #$89
STX $D4
LDX #$03
omega_alt_choose14:
PHA
LDA $83
LSR A
AND #$01
BEQ omega_alt_first14
PLA
LDA $D4
STA $4002
TXA
JSR omega_pulse1_high14
JMP omega_alt_volume14
omega_alt_first14:
PLA
STA $4002
TYA
JSR omega_pulse1_high14
omega_alt_volume14:
LDA $82
SEC
SBC #$01
JMP omega_pulse1_volume14

omega_mine_sfx14:
LDA $83
CMP #$03
BCC omega_mine_c3_14
CMP #$06
BCC omega_mine_f3_14
LDA #$AD
LDY #$06
BNE omega_mine_note14
omega_mine_f3_14:
LDA #$80
LDY #$02
BNE omega_mine_note14
omega_mine_c3_14:
LDA #$56
LDY #$03
omega_mine_note14:
STA $4002
TYA
JSR omega_pulse1_high14
LDA #$0F
JMP omega_pulse1_volume14

omega_extra_life_sfx14:
LDA #$3A
STA $4002
LDA #$02
JSR omega_pulse1_high14
LDA $83
CMP #$06
BCC omega_extra_on14
CMP #$0C
BCC omega_extra_off14
CMP #$12
BCC omega_extra_on14
CMP #$18
BCC omega_extra_off14
CMP #$1E
BCC omega_extra_on14
omega_extra_off14:
LDA #$00
BEQ omega_pulse1_volume14
omega_extra_on14:
LDA #$0F

omega_pulse1_volume14:
ORA #$B0
STA $4000
RTS

omega_pulse1_high14:
CMP $D5
BEQ omega_pulse1_high_done14
STA $D5
STA $4003
omega_pulse1_high_done14:
RTS

omega_death_sfx_start14:
LDA #$00
STA $82
STA $83
STA $87
STA $88
STA $89
STA $D2
STA $D3
LDA #$01
STA $D6
LDA #$4C
STA $84
LDA #$00
STA $85
STA $4015
LDA #$08
STA $86
STA $4015
LDA #$00
STA $400F
JMP omega_death_noise_output14

omega_death_noise_tick14:
INC $85
DEC $84
BEQ omega_death_noise_stop14
JMP omega_death_noise_output14
omega_death_noise_stop14:
LDA #$00
STA $D6
LDA #$30
STA $400C
LDA $86
AND #$F7
STA $86
STA $4015
RTS

omega_death_noise_output14:
LDA $85
CMP #$10
BCS omega_death_noise_tail14
AND #$07
CMP #$04
BCS omega_death_noise_silent14
LDA #$3F
STA $400C
LDA #$0C
STA $400E
RTS
omega_death_noise_silent14:
LDA #$30
STA $400C
RTS
omega_death_noise_tail14:
SEC
SBC #$10
CMP #$38
BCS omega_death_noise_tail_silent14
LSR A
LSR A
EOR #$0F
ORA #$30
STA $400C
LDA #$0B
STA $400E
RTS
omega_death_noise_tail_silent14:
LDA #$30
STA $400C
LDA #$0B
STA $400E
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]

data['omega_sfx_length14'] = [0,12,12,16,16,16,16,9,10,36]
data['omega_sfx_priority14'] = [0,1,1,4,4,4,2,3,2,5]
data['omega_port_low14'] = [
    0xBD,0xCE,0xE0,0xF1,0x02,0x14,0x25,0x37,0x48,0x59,0x6B,0x7C,
    0x8E,0xB5,0xDC,0x03,0x2A,0x51,0x77,0x9E,0xC5,0xEC,0x13,0x3A,
    0x3A,0x2A,0x1A,0x0A,0xFA,0xEB,0xDB,0xCB,0xBB,0xAB,
]
data['omega_port_high14'] = [
    0,0,0,0,1,1,1,1,1,1,1,1,
    0,0,0,1,1,1,1,1,1,1,2,2,
    2,2,2,2,1,1,1,1,1,1,
]
data['omega_fade12_14'] = [15,14,12,11,10,8,7,5,4,3,1,0]
data['omega_fade10_14'] = [15,13,12,10,8,7,5,3,2,0]
