"""Omega Race V21: B+neutral shield, B+directions brake/turbo."""
import math

code = '\n'.join(lines)
old = '''special_has_power:
LDA $01
AND #$04
BNE special_stop
LDA $01
AND #$08
BNE special_stop
LDA $08'''
new = '''special_has_power:
LDA $01
AND #$08
BNE special_turbo21
LDA $01
AND #$07
BNE special_stop
LDA $08'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''STA $17
RTS
special_rainbow:'''
new = '''STA $17
RTS
special_turbo21:
DEC $07
JSR omega_hud_request_supers_v5a
LDX $03
LDA omega_turbo_xlo21,X
STA $14
LDA omega_turbo_xhi21,X
STA $15
LDA omega_turbo_ylo21,X
STA $16
LDA omega_turbo_yhi21,X
STA $17
LDA #$0A
JSR omega_pulse1_start14
RTS
special_rainbow:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''CMP #$07
BEQ omega_pulse1_mine_jump14
JMP omega_extra_life_sfx14
omega_pulse1_mine_jump14:'''
new = '''CMP #$07
BEQ omega_pulse1_mine_jump14
CMP #$0A
BEQ omega_turbo_pulse1_jump21
JMP omega_extra_life_sfx14
omega_turbo_pulse1_jump21:
JMP omega_turbo_pulse1_output21
omega_pulse1_mine_jump14:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

old = '''CMP #$07
BEQ omega_pulse1_mine_jump18
JMP omega_extra_life_sfx18
omega_pulse1_mine_jump18:'''
new = '''CMP #$07
BEQ omega_pulse1_mine_jump18
CMP #$0A
BEQ omega_turbo_pulse2_jump21
JMP omega_extra_life_sfx18
omega_turbo_pulse2_jump21:
JMP omega_turbo_pulse2_output21
omega_pulse1_mine_jump18:'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

audio = '''omega_turbo_pulse1_output21:
LDX $83
LDA omega_turbo_low21,X
STA $4002
LDA omega_turbo_high21,X
JSR omega_pulse1_high14
LDA #$0F
JMP omega_pulse1_volume14
omega_turbo_pulse2_output21:
LDX $06A1
LDA omega_turbo_low21,X
STA $4006
LDA omega_turbo_high21,X
JSR omega_pulse1_high18
LDA #$0F
JMP omega_pulse1_volume18
'''
assert code.count('omega_dispatch17:\n') == 1
code = code.replace('omega_dispatch17:\n',audio + 'omega_dispatch17:\n',1)
lines = [line.strip() for line in code.splitlines() if line.strip()]

# The current engine caps each axis at +/-$0133 in 8.8 pixels/frame.
# Scale the facing vector until its largest axis reaches that same cap.
velocity = []
for heading in range(48):
    angle = 2 * math.pi * heading / 48
    x, y = math.sin(angle), -math.cos(angle)
    limit = max(abs(x), abs(y))
    velocity.append((round(0x133*x/limit), round(0x133*y/limit)))
for axis, tag in ((0,'x'),(1,'y')):
    values = [v[axis] & 0xFFFF for v in velocity]
    data[f'omega_turbo_{tag}lo21'] = [v & 0xFF for v in values]
    data[f'omega_turbo_{tag}hi21'] = [v >> 8 for v in values]

# A 15-frame equal-semitone portamento from C5 to C2. The dual effect
# engine chooses either pulse channel without interrupting higher cues.
periods = [round(1789773 / (16 * (523.25 * 2**(-3*frame/14)))) - 1
           for frame in range(15)]
assert periods[0] == 0xD5 and periods[-1] == 0x6AD
data['omega_turbo_low21'] = [n & 0xFF for n in periods]
data['omega_turbo_high21'] = [n >> 8 for n in periods]
assert len(data['omega_sfx_length14']) == 10
data['omega_sfx_length14'].append(15)
data['omega_sfx_priority14'].append(3)
