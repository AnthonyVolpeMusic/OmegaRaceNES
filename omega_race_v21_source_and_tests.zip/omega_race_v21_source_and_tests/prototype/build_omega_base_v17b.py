"""Build Omega Race Version 17B title-screen cleanup."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v17a.py').read_text()

base_v17a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v17a.py').read_text(),str(P/'patch_omega_base_v17a.py'),'exec'))\\n" + marker)'''
base_v17b = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v17b.py').read_text(),str(P/'patch_omega_base_v17b.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v17a) == 1
recipe = recipe.replace(base_v17a, base_v17a + '\n' + base_v17b, 1)

recipe = recipe.replace('omega_race_v17a.nes', 'omega_race_v17b.nes')
recipe = recipe.replace('symbols_omega_v17a.json', 'symbols_omega_v17b.json')
recipe = recipe.replace('prototype_omega_v17a.asm', 'prototype_omega_v17b.asm')
exec(compile(recipe, str(P / 'build_omega_base_v17a.py'), 'exec'))
