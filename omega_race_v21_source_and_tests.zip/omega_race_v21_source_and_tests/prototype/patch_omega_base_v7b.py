"""Version 7B: projectile/drone collision, 1000-point awards, reused impacts."""

code = '\n'.join(lines)

# Resolve projectile hits after projectile movement/wall checks and before the
# drones advance. Wall impacts are already marked as explosions and are skipped.
old = 'JSR bullets\nJSR drone_tick6'
new = 'JSR bullets\nJSR drone_collision7b\nJSR drone_tick6'
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Byte 5 in every 16-byte drone record is its live flag.
old = '''LDA #$00
STA $0304,X
JSR drone_assign6'''
new = '''LDA #$00
STA $0304,X
LDA #$01
STA $0305,X
JSR drone_assign6'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Dead drones neither advance nor consume movement work.
old = '''drone_tick_loop6:
JSR drone_move6
TXA'''
new = '''drone_tick_loop6:
LDA $0305,X
BEQ drone_tick_next7b
JSR drone_move6
drone_tick_next7b:
TXA'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Hide inactive drone OAM entries while retaining the seven fixed sprite slots.
start = code.index('drone_render6:')
end = code.index('\nRTS', start) + len('\nRTS')
render = '''drone_render6:
LDX #$00
LDY #$14
drone_render_loop6:
LDA $0305,X
BEQ drone_render_hide7b
LDA $0301,X
SEC
SBC #$01
STA $0200,Y
LDA $A8
CLC
ADC #$E0
STA $0201,Y
LDA #$03
STA $0202,Y
LDA $0300,X
STA $0203,Y
JMP drone_render_next7b
drone_render_hide7b:
LDA #$F8
STA $0200,Y
drone_render_next7b:
INY
INY
INY
INY
TXA
CLC
ADC #$10
TAX
CPX #$70
BNE drone_render_loop6
RTS'''
code = code[:start] + render + code[end:]

code += '''
drone_collision7b:
LDY #$00
drone_bullet_loop7b:
LDA $0600,Y
BNE drone_bullet_active7b
JMP drone_next_bullet7b
drone_bullet_active7b:
LDA $0609,Y
BEQ drone_bullet_flying7b
JMP drone_next_bullet7b
drone_bullet_flying7b:
STY $B0
LDX #$00
drone_hit_loop7b:
LDA $0305,X
BEQ drone_hit_next7b
LDY $B0
LDA $0602,Y
CLC
ADC #$03
CMP $0300,X
BCC drone_hit_next7b
LDA $0300,X
CLC
ADC #$08
CMP $0602,Y
BCC drone_hit_next7b
BEQ drone_hit_next7b
LDA $0604,Y
CLC
ADC #$03
CMP $0301,X
BCC drone_hit_next7b
LDA $0301,X
CLC
ADC #$08
CMP $0604,Y
BCC drone_hit_next7b
BEQ drone_hit_next7b
LDA #$00
STA $0305,X
LDA $0300,X
STA $0602,Y
LDA $0301,X
STA $0604,Y
LDA #$0F
STA $0600,Y
LDA #$01
STA $0609,Y
LDA #$00
STA $0605,Y
STA $0606,Y
STA $0607,Y
STA $0608,Y
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
JSR omega_hud_request_score_v5a
LDY $B0
JMP drone_next_bullet7b
drone_hit_next7b:
TXA
CLC
ADC #$10
TAX
CPX #$70
BEQ drone_hit_done7b
JMP drone_hit_loop7b
drone_hit_done7b:
LDY $B0
drone_next_bullet7b:
TYA
CLC
ADC #$10
TAY
CPY #$40
BEQ drone_collision_done7b
JMP drone_bullet_loop7b
drone_collision_done7b:
RTS
'''

lines = [s.strip() for s in code.splitlines() if s.strip()]
