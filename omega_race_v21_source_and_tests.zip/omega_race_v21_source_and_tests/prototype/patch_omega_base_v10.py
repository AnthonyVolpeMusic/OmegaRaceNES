"""Version 10: two fixed extra lives, 75% bounce retention and enemy palettes."""

code = '\n'.join(lines)

# Sprite palettes: P1 and P1 shots remain unchanged. Palette 1 becomes the
# Commander scheme; palette 3 becomes the basic-drone scheme.
data['palette'] = [
    0x08,0x18,0x28,0x38, 0x0F,0x16,0x28,0x08,
    0x0F,0x0F,0x0F,0x0F, 0x0F,0x0F,0x0F,0x0F,
    0x08,0x38,0x18,0x28, 0x08,0x16,0x27,0x38,
    0x08,0x28,0x38,0x18, 0x08,0x00,0x26,0x36,
]

# Commanders use sprite palette 1; basic drones use palette 3.
old = '''STA $0201,Y
LDA #$03
STA $0202,Y
LDA $0300,X'''
new = '''STA $0201,Y
LDA $0306,X
BEQ drone_palette_basic10
LDA #$01
BNE drone_palette_store10
drone_palette_basic10:
LDA #$03
drone_palette_store10:
STA $0202,Y
LDA $0300,X'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Commander-fired shots share the Commander colors.
old = '''LDA #$03
STA $0202,Y
LDA $0582,X'''
new = '''LDA #$01
STA $0202,Y
LDA $0582,X'''
assert code.count(old) == 1
code = code.replace(old, new, 1)

# Replace the inherited repeating 10,000-point life thresholds with exactly
# two one-time binary score checks: 40,000 ($009C40) and 100,000 ($0186A0).
start = code.index('score_threshold35:')
end = code.index('score_decimal_add:', start)
thresholds = '''score_threshold35:
LDA $CA
AND #$01
BNE score_check_100k10
LDA $32
CMP #$00
BCC score_check_100k10
BNE score_award_40k10
LDA $31
CMP #$9C
BCC score_check_100k10
BNE score_award_40k10
LDA $30
CMP #$40
BCC score_check_100k10
score_award_40k10:
LDA $CA
ORA #$01
STA $CA
JSR score_extra_life10
score_check_100k10:
LDA $CA
AND #$02
BNE score_check_done
LDA $32
CMP #$01
BCC score_check_done
BNE score_award_100k10
LDA $31
CMP #$86
BCC score_check_done
BNE score_award_100k10
LDA $30
CMP #$A0
BCC score_check_done
score_award_100k10:
LDA $CA
ORA #$02
STA $CA
JSR score_extra_life10
score_check_done:
RTS
score_extra_life10:
LDA #$06
JSR pulse2_start26
INC $3D
JSR omega_hud_request_lives_v5a
RTS
'''
code = code[:start] + thresholds + code[end:]

# Retain 75% of signed 8.8 velocity after each wall bounce. This is original
# velocity minus its arithmetic quarter, avoiding overflow at high speeds.
start = code.index('omega_halve_ship_speed_v4:')
end = code.index('omega_shot_box_v4:', start)
retain = '''omega_halve_ship_speed_v4:
LDA $14
STA $CB
LDA $15
STA $CC
LDA $CC
CMP #$80
ROR A
STA $CC
ROR $CB
LDA $CC
CMP #$80
ROR A
STA $CC
ROR $CB
LDA $14
SEC
SBC $CB
STA $14
LDA $15
SBC $CC
STA $15
LDA $16
STA $CD
LDA $17
STA $CE
LDA $CE
CMP #$80
ROR A
STA $CE
ROR $CD
LDA $CE
CMP #$80
ROR A
STA $CE
ROR $CD
LDA $16
SEC
SBC $CD
STA $16
LDA $17
SBC $CE
STA $17
RTS
'''
code = code[:start] + retain + code[end:]

lines = [s.strip() for s in code.splitlines() if s.strip()]
