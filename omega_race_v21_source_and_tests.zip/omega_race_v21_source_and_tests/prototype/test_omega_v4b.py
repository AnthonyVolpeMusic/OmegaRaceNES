"""Full V4A regression suite plus V4B handling/speed checks."""
import math
from pathlib import Path

P = Path(__file__).parent
source = (P / 'test_omega_v4a.py').read_text()
source = source.replace('omega_race_v4a_top_border_test.nes',
                        'omega_race_v4b_speed_test.nes')
source = source.replace('symbols_omega_v4a.json', 'symbols_omega_v4b.json')
exec(compile(source, str(P / 'test_omega_v4a.py'), 'exec'))

def signed16(lo, hi):
    value = lo | (hi << 8)
    return value - 0x10000 if value & 0x8000 else value

# Verify all 48 acceleration headings against the 60%-scaled vector, including
# diagonals and negative quadrants.
for heading in range(48):
    mm,cc=boot();mm[1]=0x08;mm[3]=heading
    call(mm,cc,'game_controls')
    expect_x=round(7.2*math.sin(heading*math.tau/48))
    expect_y=round(7.2*-math.cos(heading*math.tau/48))
    assert signed16(mm[0x14],mm[0x15])==expect_x
    assert signed16(mm[0x16],mm[0x17])==expect_y
print('PASS all 48 thrust headings use 60% acceleration')

# Exact +/-1.2 component caps on both axes ($0133 and $FECD).
for heading,initial,axis,expected in (
    (12,0x0130,0x14,0x0133), (36,0xFED0,0x14,0xFECD),
    (24,0x0130,0x16,0x0133), (0, 0xFED0,0x16,0xFECD),
):
    mm,cc=boot();mm[1]=0x08;mm[3]=heading
    mm[axis]=initial&0xff;mm[axis+1]=initial>>8
    call(mm,cc,'game_controls')
    assert (mm[axis]|(mm[axis+1]<<8))==expected
print('PASS Player One component top speed is exactly +/-1.2 pixels/frame')

# Verify every projectile direction against the 70%-scaled launch vector.
# Start the ship stationary so these values isolate projectile speed itself.
for heading in range(48):
    mm,cc=boot();mm[1]=0x80;mm[2]=0;mm[3]=heading
    call(mm,cc,'game_controls')
    expect_x=round(537.6*math.sin(heading*math.tau/48))
    expect_y=round(537.6*-math.cos(heading*math.tau/48))
    assert signed16(mm[0x605],mm[0x606])==expect_x
    assert signed16(mm[0x607],mm[0x608])==expect_y
print('PASS all 48 projectile headings use 70% launch speed')

# Ship momentum is still added to the reduced launch vector.
mm,cc=boot();mm[0x14:0x18]=[0x80,0x00,0x40,0xff]
mm[1]=0x80;mm[2]=0;mm[3]=12;call(mm,cc,'game_controls')
assert signed16(mm[0x605],mm[0x606])==round(537.6)+0x80
assert signed16(mm[0x607],mm[0x608])==-0xC0
print('PASS projectiles retain inherited ship momentum')
