"""Build Omega Race Version 17A with a black title background."""
from pathlib import Path

P = Path(__file__).parent
recipe = (P / 'build_omega_base_v17.py').read_text()

base_v17 = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v17.py').read_text(),str(P/'patch_omega_base_v17.py'),'exec'))\\n" + marker)'''
base_v17a = r'''source = source.replace(marker, "exec(compile((P/'patch_omega_base_v17a.py').read_text(),str(P/'patch_omega_base_v17a.py'),'exec'))\\n" + marker)'''
assert recipe.count(base_v17) == 1
recipe = recipe.replace(base_v17, base_v17 + '\n' + base_v17a, 1)

recipe = recipe.replace('omega_race_v17.nes', 'omega_race_v17a.nes')
recipe = recipe.replace('symbols_omega_v17.json', 'symbols_omega_v17a.json')
recipe = recipe.replace('prototype_omega_v17.asm', 'prototype_omega_v17a.asm')
exec(compile(recipe, str(P / 'build_omega_base_v17.py'), 'exec'))
