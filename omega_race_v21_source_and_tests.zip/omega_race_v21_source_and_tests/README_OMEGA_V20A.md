# Omega Race NES — Version 20A attract-screen correction

Version 20A builds on Version 20. On the third attract screen, the text and Omega Race logo remain on the active background screen throughout the six-color flash. Each palette write now restores the PPU background address to nametable 0. The sentence reads `SUCCESSFUL, IT COMMANDS FEAR` with a comma.

The existing title screen, attract timings, points, inputs, audio, and gameplay remain as in Version 20.

ROM: `prototype/omega_race_v20a.nes`.

From `prototype/`, with Python, Pillow and `py65` installed:

```sh
python build_omega_base_v20a.py
python test_omega_v20a.py
```

The test checks the selected background screen after every frame of the flash, as well as the visible text and logo tile data, colors, one-second sound, and existing attract transitions.
