# Omega Race Version 17A

Version 17A branches from the confirmed Version 17 title-screen build.

- Changes the title-screen universal background from `$08` to true NES black
  (`$0F`).
- Preserves the logo colors and all title-screen text and controls.
- Keeps the normal Level 1 `$08/$18/$28/$38` playfield palette unchanged and
  restores it when Start begins gameplay.

Build and test from `prototype`:

```sh
python3 build_omega_base_v17a.py
python3 test_omega_v17a.py
```
