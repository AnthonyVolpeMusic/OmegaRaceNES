# Omega Race NES — Version 19

The Game Over screen appears after the final ship dies, all of its projectiles have disappeared, and the existing two-second continuation ends. It clears the playfield, shows the final six-digit score and rank, and displays the Start and Select instructions. Start begins a new game at level one with the currently selected starting-life count; Select returns to the black title screen.

The rank uses the integer final score divided by the starting lives (three, five, or seven). A score on a boundary receives the higher rank. Thresholds and names:

| Points per starting life | Rank |
| ---: | --- |
| 0 | JANITOR |
| 1,000 | CONCESSIONS CLERK |
| 2,000 | HOT DOG VENDOR |
| 3,000 | PIT CREW |
| 4,000 | PACE CAR |
| 6,000 | LEAD FOOT |
| 8,000 | TOUGH CUSTOMER |
| 10,000 | ROAD WARRIOR |
| 12,500 | INTIMIDATOR |
| 15,000 | FRONT ROW JOE |
| 20,000 | ROCKET MAN |
| 25,000 | IRON MAN |
| 30,000 | OMEGA RACER |

The title-screen colon now remains visible: the idle title screen no longer writes the initial supers count on top of `STARTING LIVES:`. Gameplay HUD updates continue as before.

## Build and test

From `prototype/`, with Python and `py65` installed:

```sh
python build_omega_base_v19.py
python test_omega_v19.py
```

The builder produces `omega_race_v19.nes`, `prototype_omega_v19.asm` and `symbols_omega_v19.json`. The test runs the assembled ROM on a 6502 emulator and verifies the title colon after NMI, rank boundaries for all starting-life settings, Game Over copy and score, final death transition, and Start/Select behavior.
