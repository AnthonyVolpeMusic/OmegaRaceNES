# Omega Race NES — Version 19A

Built from the confirmed Version 19 Game Over ROM. All existing gameplay, Game Over rankings, and sound effects remain intact.

- Wave-clear music explicitly silences Pulse 1 and Pulse 2 and clears their note timers at the end of the song. If the preceding destruction sound delays the music, the next wave waits until the music finishes before repopulating.
- The full title layout moves down exactly three 8-pixel rows (24 pixels): logo rows 6–11, selector instructions row 15, lives line row 17, Start prompt row 22. The dynamic THREE/FIVE/SEVEN text now updates on row 17.
- Title logo palette: background `$0F` black; source transitional/brown pixels `$07`; yellow pixels `$28`; red pixels `$16`. The title colon remains protected from HUD writes.

The ROM is `prototype/omega_race_v19a.nes`. From `prototype/`, build with `python build_omega_base_v19a.py` and test with `python test_omega_v19a.py`; Python requires `py65` and Pillow. The source package includes the original logo image used by the builder, prior version sources, the new patch, assembled source and symbols, and regression tests.
