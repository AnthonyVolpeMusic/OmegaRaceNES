# Omega Race NES — Version 20 attract screens

The confirmed Version 19B startup screen remains the first screen. After ten seconds without controller input, the following arcade-inspired attract loop begins:

1. The 12-row opening story types one character every five frames (including spaces and punctuation), then remains visible for five seconds. The cut-off final word is completed as `FOLLOWS`.
2. The score screen stays for ten seconds and uses the game's own 8×8 sprites: land mine 350, drone 1000, commander 1500, shooting star 2500. The arcade's 500-point double land mine is excluded.
3. The five centered closing-story lines type at the same rate. The existing Omega Race logo appears in the lower part of the screen as the background changes white → yellow → orange → red → dark red → black, ten frames per color. A noise-channel explosion lasts 60 frames. The finished screen holds for five seconds, then the original startup screen returns.

Start or Select during any attract screen returns immediately to the original startup screen. That keypress is consumed; release and press Start again to play. Any controller input on the startup screen restarts the ten-second idle timer. The currently selected starting-life setting is retained through the attract loop.

ROM: `prototype/omega_race_v20.nes`.

From `prototype/`, with Python, Pillow and `py65` installed:

```sh
python build_omega_base_v20.py
python test_omega_v20.py
```

The build creates the ROM, expanded source listing and labels. The ROM-level tests check the text, exact stage timings, sprite/point mapping, six background colors, one-second noise, Start/Select cancellation, and a fresh game afterward. The Version 19B mine transitions and Version 19A title/audio tests also pass against this ROM.
