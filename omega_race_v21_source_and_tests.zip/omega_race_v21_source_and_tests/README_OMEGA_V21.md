# Omega Race NES — Version 21

Version 21 builds on the confirmed Version 20A beta.

The B button now selects one of three actions when first pressed:

| Input | Action |
| --- | --- |
| B with no direction | Activate the one-second shield. |
| B with Down, Left, or Right | Stop the ship immediately. |
| B with Up | Turbo: set velocity immediately to the maximum allowed by the existing per-axis speed cap, in the direction the ship faces. |

Each action uses one Super and updates the Super display on use. Up takes priority if several directions are held with B. If no Supers remain, ordinary movement continues. Turbo plays a fifteen-frame sound on either available pulse channel, gliding from C5 to C2 before falling silent. Each press triggers once; a held B button does not repeatedly use Supers.

ROM: `prototype/omega_race_v21.nes`.

From `prototype/`, with Python, Pillow, and `py65` installed:

```sh
python build_omega_base_v21.py
python test_omega_v21.py
```

The ROM-level checks exercise controller combinations, cardinal and diagonal velocities, Super use, both pulse channels, sound duration and endpoints, plus the attract sequence inherited from V20A.
